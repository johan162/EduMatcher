"""
pm-clearing v2 — SQLite-backed trade clearing process.

Architecture
------------
One subscriber thread receives ``trade.executed`` messages from the engine and
appends them to an in-memory buffer.  A separate timer thread flushes the
buffer to SQLite every ``FLUSH_INTERVAL_SEC`` seconds even when the buffer is
partially filled.  The buffer is also flushed immediately when it reaches
``FLUSH_SIZE`` trades.

The flush transaction atomically writes:
1. raw trade rows  (INSERT OR IGNORE into trade_events)
2. current position snapshots  (UPSERT into gateway_symbol_positions)
3. incremental daily deltas    (UPSERT into gateway_daily_summary)

On startup the process prunes trade_events rows older than 90 days and logs
the count of deleted rows.

Timestamp semantics
-------------------
Session/gateway lifecycle rows written by this process (EOD markers and
gateway connect/disconnect events) are stamped with local ``now_ns()`` at
ingest time.  They represent clearing-observed timing, not exchange-event
timestamps.
"""

from __future__ import annotations

import argparse
import copy
import errno
import json
import logging
import signal
import sys
import threading
import time
from collections import OrderedDict
from datetime import timezone, tzinfo
from pathlib import Path
from typing import Any

import zmq
from rich.console import Console
from rich.table import Table

from edumatcher.clearing.ledger import Ledger, trade_date
from edumatcher.clearing.store import (
    TradeEventRow,
    close_latest_gateway_session,
    fetch_all_positions,
    flush_batch,
    open_writer_connection,
    prune_old_events,
    record_gateway_connect,
    record_session_event,
)
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler
from edumatcher.messaging.bus import make_subscriber
from edumatcher.models.clock import now_ns  # used in _flush
from edumatcher.models.generated import system as _gen_system
from edumatcher.models.generated.session import SessionState, TOPIC_SESSION_STATE
from edumatcher.models.feed_schema import (
    TradeExecutedPayload,
)
from edumatcher.models.message import decode
from edumatcher.models.price import to_ticks
from edumatcher.models.trade import Trade
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.system import (
    PREFIX_GATEWAY_AUTH,
    PREFIX_GATEWAY_BYE,
    TOPIC_EOD,
    TOPIC_GATEWAY_CONNECT,
    TOPIC_GATEWAY_DISCONNECT,
)

FLUSH_SIZE: int = 100
FLUSH_INTERVAL_SEC: float = 5.0
_TIMER_POLL_SEC: float = 0.5
_RETENTION_DAYS: int = 90
_DEBUG_SUMMARY_INTERVAL_SEC: float = 5.0
# The documented trade.executed contract (docs/user-guide/09-messages.md) is:
#   timestamp = Unix epoch SECONDS (float);  price = display float.
# Clearing parses to the declared units rather than guessing (finding CL-M6).
# These magnitude bounds are only a defensive guard: an out-of-contract producer
# sending milliseconds or nanoseconds is detected, warned about, and converted
# best-effort — instead of silently projecting a ms value to the year ~55,000.
_SECONDS_MAX: int = 100_000_000_000  # ~ year 5138 in epoch seconds
_MILLIS_MAX: int = _SECONDS_MAX * 1000

_CLIENT_NAME = "pm-clearing"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

console = Console()
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Trade → TradeEventRow conversion
# ---------------------------------------------------------------------------


def _to_trade_event_row(
    trade: Trade, ingest_ts_ns: int, tz: tzinfo = timezone.utc
) -> TradeEventRow:
    """Convert a Trade model to the DB row type, deriving trade_date from ts_ns."""
    return TradeEventRow(
        id=trade.id,
        ts_ns=trade.timestamp,
        trade_date=trade_date(trade.timestamp, tz),
        symbol=trade.symbol,
        quantity=trade.quantity,
        price=trade.price,
        tick_decimals=trade.tick_decimals,
        buy_order_id=trade.buy_order_id or None,
        sell_order_id=trade.sell_order_id or None,
        buy_gateway_id=trade.buy_gateway_id,
        sell_gateway_id=trade.sell_gateway_id,
        aggressor_side=trade.aggressor_side or None,
        ingest_ts_ns=ingest_ts_ns,
    )


def _parse_tick_decimals(payload: dict[str, Any]) -> int:
    raw = payload.get("tick_decimals", 2)
    try:
        parsed = int(raw)
    except (TypeError, ValueError):
        return 2
    return parsed if 0 <= parsed <= 8 else 2


def _to_timestamp_ns(raw: Any) -> int:
    """
    Convert a ``trade.executed`` timestamp to integer nanoseconds.

    The declared contract is Unix epoch **seconds** (float), so that is the
    primary interpretation.  A value whose magnitude is implausible for seconds
    (already milliseconds or nanoseconds) is converted best-effort with a loud
    warning rather than silently mis-scaled (finding CL-M6).
    """
    try:
        val = float(raw)
    except (TypeError, ValueError):
        return 0
    if val < _SECONDS_MAX:
        return int(round(val * 1_000_000_000))
    if val < _MILLIS_MAX:
        log.warning(
            "trade timestamp looks like milliseconds, not the documented"
            " seconds — converting best-effort"
        )
        return int(round(val * 1_000_000))
    log.warning(
        "trade timestamp looks like nanoseconds, not the documented"
        " seconds — converting best-effort"
    )
    return int(val)


def _trade_from_payload(payload: dict[str, Any]) -> Trade:
    typed = TradeExecutedPayload.from_dict(payload)

    normalized = typed.to_dict()
    tick_decimals = _parse_tick_decimals(normalized)
    scale = 10**tick_decimals

    # trade.executed.price is a DISPLAY value by contract; convert to ticks
    # unconditionally rather than treating an integer as if it were already ticks
    # (finding CL-M6).
    price_raw = typed.price
    normalized["price"] = int(round(float(price_raw) * scale))

    normalized["timestamp"] = _to_timestamp_ns(typed.timestamp)
    normalized["tick_decimals"] = tick_decimals
    return Trade.from_dict(normalized)


# ---------------------------------------------------------------------------
# Main process class
# ---------------------------------------------------------------------------


class ClearingProcess:
    """
    Buffered clearing process — subscribe, buffer, and flush to SQLite.

    Parameters
    ----------
    pub_addr:
        ZMQ PUB address to subscribe to.
    db_path:
        Path to the SQLite clearing database.
    flush_size:
        Maximum number of buffered trades before an immediate flush.
    flush_interval_sec:
        Maximum seconds between flushes when buffer is non-empty.
    print_every:
        Print a P&L summary table to the console every N trades (0 = never).
    retention_days:
        Trade events older than this many days are pruned on startup.
    """

    def __init__(
        self,
        pub_addr: str,
        db_path: Path,
        *,
        flush_size: int = FLUSH_SIZE,
        flush_interval_sec: float = FLUSH_INTERVAL_SEC,
        print_every: int = 100,
        retention_days: int = _RETENTION_DAYS,
        session_tz: tzinfo = timezone.utc,
        sql_trace: bool = False,
    ) -> None:
        self._pub_addr = pub_addr
        self._db_path = Path(db_path)
        self._flush_size = flush_size
        self._flush_interval_sec = flush_interval_sec
        self._print_every = print_every
        self._retention_days = retention_days
        self._sql_trace = bool(sql_trace)
        # Exchange session timezone used to bucket trades into a trading day
        # (finding CL-M3); defaults to UTC.
        self._tz = session_tz

        self._buffer: list[Trade] = []
        self._ledger = Ledger(tz=session_tz)
        self._trade_count = 0

        # Idempotency, decided ONCE for both the ledger and the archive
        # (finding CL-M1).  A trade is keyed by (id, ts_ns) — the same key the
        # archive dedups on — so a duplicate delivery (retransmit / replay) is
        # dropped before it can double-count a position.  Bounded LRU of recent
        # keys; the archive's UNIQUE(id, ts_ns) constraint is the durable
        # backstop for anything evicted.
        self._seen_keys: OrderedDict[tuple[str, int], None] = OrderedDict()
        self._seen_cap = 200_000
        self._dup_count = 0

        # Gap detection (finding CL-H1).  trade.executed carries no sequence
        # number, but the suffix of the durable trade id is a per-run monotonic
        # counter, so a forward jump in it means the lossy PUB/SUB transport
        # dropped one or more trades. A run-prefix change is a restart, not a
        # gap.
        self._last_seq: tuple[int, int] | None = None
        self._gap_count = 0

        self._running = False
        self._lock = threading.RLock()
        self._last_flush_mono = time.monotonic()

        # Track the latest connect_at_ns per gateway so we can match the
        # corresponding row when a disconnect message arrives.
        self._gw_connect_ts: dict[str, int] = {}
        self._debug_counts: OrderedDict[str, int] = OrderedDict()
        self._debug_last_summary = time.monotonic()

        self._conn = open_writer_connection(self._db_path, sql_trace=self._sql_trace)
        log.info("opened clearing DB connection path=%s", self._db_path.resolve())
        if self._sql_trace:
            log.info("SQLite SQL trace enabled for clearing writer connection")

        # Warm start: rebuild the ledger from durable position state before any
        # trades arrive, so a restart accumulates onto the persisted positions
        # rather than overwriting them from flat (finding CL-C4).
        self._hydrate_ledger()

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        self._debug_counts[key] = self._debug_counts.get(key, 0) + amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in self._debug_counts.items()
        )
        log.debug("clearing flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def _hydrate_ledger(self) -> None:
        """Restore in-memory positions from ``gateway_symbol_positions``."""
        try:
            rows = fetch_all_positions(self._conn)
            self._ledger.restore(rows)
            if rows:
                log.info(
                    "warm start: restored %d position(s) from the database", len(rows)
                )
            log.debug("warm start restored positions=%d", len(rows))
        except Exception as exc:
            log.warning("warm-start hydration failed: %s", exc)

    def run(self) -> None:
        """Start the clearing process; blocks until stop() is called."""
        pruned = prune_old_events(self._conn, retention_days=self._retention_days)
        log.info(
            "starting clearing runtime db=%s flush_size=%d flush_interval=%ss retention_days=%d",
            self._db_path,
            self._flush_size,
            self._flush_interval_sec,
            self._retention_days,
        )
        if pruned:
            log.info(
                "pruned %d trade_events rows older than %d days",
                pruned,
                self._retention_days,
            )

        log.info(
            "clearing db=%s flush policy: size=%d interval=%ss",
            self._db_path,
            self._flush_size,
            self._flush_interval_sec,
        )
        log.info("pm-clearing waiting for pm-engine events")

        # Signal handlers may only be installed from the main thread.
        # When run() is called from a test thread, skip graceful-signal setup.
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, lambda *_: self.stop())
            signal.signal(signal.SIGTERM, lambda *_: self.stop())

        self._running = True
        log.debug("clearing receive/timer loops enabled")

        timer = threading.Thread(
            target=self._timer_loop, daemon=True, name="clearing-timer"
        )
        timer.start()

        sub = make_subscriber(
            self._pub_addr,
            TOPIC_TRADE_EXECUTED,
            TOPIC_EOD,
            # Session-phase transitions — recorded as PHASE rows in
            # session_events (finding CL-M7) so operators can bucket activity by
            # session phase and the advertised PHASE filter is real.
            TOPIC_SESSION_STATE,
            # The engine broadcasts gateway lifecycle on PUB as
            # ``system.gateway_auth.{id}`` (models/message.py make_gateway_auth_msg,
            # engine/main.py _handle_gateway_connect).  ``system.gateway_connect``
            # / ``system.gateway_disconnect`` are gateway→engine PULL topics that
            # never reach this subscriber (finding CL-C3), so subscribe to the
            # auth-broadcast prefix as the real "gateway connected" signal.
            PREFIX_GATEWAY_AUTH,
            # Disconnect broadcast — the PUB counterpart to gateway_auth
            # (engine/main.py _handle_gateway_disconnect → make_gateway_bye_msg).
            PREFIX_GATEWAY_BYE,
            # Kept for the test harness's readiness/ordering probe and any
            # direct-injection clients; harmless in production where it is silent.
            TOPIC_GATEWAY_CONNECT,
            TOPIC_GATEWAY_DISCONNECT,
        )
        try:
            self._receive_loop(sub)
        finally:
            sub.close()
            self._force_flush()
            self._flush_debug_summary(force=True)
            self._conn.close()
            log.info("clearing DB connection closed")
            log.info("shutdown complete")

    def stop(self) -> None:
        """Signal the receive loop to exit cleanly."""
        log.info("stop requested")
        self._running = False

    def flush_now(self) -> int:
        """
        Flush the current buffer immediately.  Returns the number of trades flushed.
        Thread-safe; may be called from tests.
        """
        with self._lock:
            return self._flush()

    # ------------------------------------------------------------------
    # Receive loop
    # ------------------------------------------------------------------

    def _receive_loop(self, sub: zmq.Socket) -> None:  # type: ignore[type-arg]
        poller = zmq.Poller()
        poller.register(sub, zmq.POLLIN)

        while self._running:
            try:
                socks = dict(poller.poll(timeout=300))
            except zmq.ZMQError as exc:
                if exc.errno != errno.EINTR:
                    raise
                break

            if sub not in socks:
                continue

            frames = sub.recv_multipart()
            try:
                topic, payload = decode(frames)
            except Exception as exc:
                log.warning("failed to decode frame: %s", exc)
                continue

            self._dbg_count("messages_received")

            if topic == TOPIC_TRADE_EXECUTED:
                try:
                    trade = _trade_from_payload(payload)
                except Exception as exc:
                    log.warning("failed to parse trade: %s", exc)
                    continue

                with self._lock:
                    # Count every observed trade message (used for progress /
                    # print cadence), then dedup before buffering so a replay
                    # is neither re-applied to the ledger nor re-archived.
                    self._trade_count += 1
                    if self._is_duplicate(trade):
                        self._dup_count += 1
                        self._dbg_count("duplicates")
                    else:
                        self._check_sequence_gap(trade)
                        self._buffer.append(trade)
                        self._dbg_count("trades_buffered")
                        if len(self._buffer) >= self._flush_size:
                            self._flush()

                # CL-L6: read _trade_count outside the lock intentionally.
                # Worst-case effect is a skipped or duplicated print cadence,
                # never a data-integrity issue.
                if self._print_every > 0 and self._trade_count % self._print_every == 0:
                    self._print_pnl_table()

            elif topic == TOPIC_EOD:
                self._dbg_count("eod_topics")
                self._handle_eod(payload)

            elif topic == TOPIC_SESSION_STATE:
                self._dbg_count("phase_topics")
                self._handle_session_state(payload)

            elif topic.startswith(PREFIX_GATEWAY_AUTH):
                self._dbg_count("gateway_auth_topics")
                self._handle_gateway_auth(payload)

            elif topic.startswith(PREFIX_GATEWAY_BYE):
                self._dbg_count("gateway_bye_topics")
                self._handle_gateway_bye(payload)

            elif topic == TOPIC_GATEWAY_CONNECT:
                self._dbg_count("gateway_connect_topics")
                self._handle_gateway_connect(payload)

            elif topic == TOPIC_GATEWAY_DISCONNECT:
                self._dbg_count("gateway_disconnect_topics")
                self._handle_gateway_disconnect(payload)

    # ------------------------------------------------------------------
    # Timer loop
    # ------------------------------------------------------------------

    def _timer_loop(self) -> None:
        while self._running:
            time.sleep(_TIMER_POLL_SEC)
            with self._lock:
                elapsed = time.monotonic() - self._last_flush_mono
                if elapsed >= self._flush_interval_sec and self._buffer:
                    self._dbg_count("timer_flushes")
                    self._flush()

    # ------------------------------------------------------------------
    # Flush (must be called with self._lock held)
    # ------------------------------------------------------------------

    def _is_duplicate(self, trade: Trade) -> bool:
        """
        Return True if this (id, ts_ns) has already been seen (must be called
        with ``self._lock`` held).  First sightings are recorded in a bounded
        LRU; the oldest key is evicted once the cap is reached.
        """
        key = (trade.id, trade.timestamp)
        if key in self._seen_keys:
            self._seen_keys.move_to_end(key)
            return True
        self._seen_keys[key] = None
        if len(self._seen_keys) > self._seen_cap:
            self._seen_keys.popitem(last=False)
        return False

    def _check_sequence_gap(self, trade: Trade) -> None:
        """
        Detect a dropped-trade gap from the engine's durable trade id suffix and
        record a durable ``GAP`` alarm in ``session_events`` (must be called
        with ``self._lock`` held).

        Legacy or synthetic ids disable sequencing rather than false-alarm. A
        run-prefix change resets the tracker without alarming.
        """
        try:
            run_text, seq_text = trade.id.split("-", 1)
            current = (int(run_text), int(seq_text))
        except (TypeError, ValueError):
            self._last_seq = None
            return

        last = self._last_seq
        self._last_seq = current
        if last is None:
            return
        last_run, last_seq = last
        run_seq, seq = current
        if run_seq != last_run or seq <= last_seq:
            return
        if seq > last_seq + 1:
            missing = seq - last_seq - 1
            self._gap_count += 1
            try:
                record_session_event(
                    self._conn,
                    event_type="GAP",
                    ts_ns=trade.timestamp,
                    trade_date=trade_date(trade.timestamp, self._tz),
                    payload_json=json.dumps(
                        {
                            "run_seq": run_seq,
                            "last_seq": last_seq,
                            "next_seq": seq,
                            "missing_trades": missing,
                        }
                    ),
                )
                log.warning(
                    "trade feed gap — %d trade(s) missing between id %s and %s",
                    missing,
                    last_seq,
                    seq,
                )
            except Exception as exc:
                log.warning("failed to record feed gap: %s", exc)

    def _flush(self) -> int:
        """Flush the buffer to SQLite. Returns the number of trades written."""
        if not self._buffer:
            return 0

        self._dbg_count("flush_calls")

        updated_ts = now_ns()

        trade_rows = [
            _to_trade_event_row(t, updated_ts, self._tz) for t in self._buffer
        ]

        for trade in self._buffer:
            self._ledger.apply_trade(
                symbol=trade.symbol,
                buy_gateway_id=trade.buy_gateway_id,
                sell_gateway_id=trade.sell_gateway_id,
                price=trade.price,
                tick_decimals=trade.tick_decimals,
                quantity=trade.quantity,
                ts_ns=trade.timestamp,
                ingest_ts_ns=updated_ts,
            )

        position_rows, daily_rows = self._ledger.get_flush_rows(
            updated_ts_ns=updated_ts
        )

        flush_batch(self._conn, trade_rows, position_rows, daily_rows)

        count = len(self._buffer)
        self._buffer.clear()
        self._ledger.clear_batch()
        self._last_flush_mono = time.monotonic()

        self._dbg_count("flushed_trades", count)
        self._dbg_count("position_rows_written", len(position_rows))
        self._dbg_count("daily_rows_written", len(daily_rows))

        return count

    def _force_flush(self) -> None:
        """Flush remaining buffer on shutdown (called without lock)."""
        with self._lock:
            self._flush()

    # ------------------------------------------------------------------
    # Secondary event handlers
    # ------------------------------------------------------------------

    def _handle_eod(self, payload: dict[str, Any]) -> None:
        """
        Handle system.eod — engine end-of-day shutdown event.

        Actions:
        1. Force-flush any buffered trades immediately.
        2. Perform a final mark-to-market pass using EOD last-traded prices
           from the payload and write updated positions to the DB.
        3. Write an EOD sentinel row to session_events so pm-clearing-cli
           can report exact session close times.
        """
        try:
            ts_ns = now_ns()
            eod_trade_date = trade_date(ts_ns, self._tz)

            # Parse EOD marks before acquiring the lock.
            #
            # The engine sends ``book.snapshot()`` dicts (models/message.py
            # make_eod_msg, engine/order_book.py snapshot): the keys are
            # ``last_price`` (a DISPLAY float) and ``bids`` / ``asks`` (lists of
            # {price, qty, count} with display-float prices) — NOT the old
            # ``last_trade_price`` / ``best_bid`` / ``best_ask`` this handler used
            # to look for (finding CL-C2, which left eod_marks permanently empty).
            # Everything downstream stores marks in integer ticks, so convert at
            # this ingress boundary via to_ticks (CL-M4: keeps mark and avg_cost
            # in the same unit).
            eod_marks: dict[str, int] = {}
            eod_payload = _gen_system.Eod.from_dict(payload)
            for book in eod_payload.books:
                sym = book.symbol
                if not sym:
                    continue
                last_price = book.last_price
                bids = book.bids
                asks = book.asks
                if last_price is not None:
                    eod_marks[sym] = to_ticks(last_price, sym)
                elif bids and asks:
                    # `EodBookLevel.price` is required, so no None guard: the
                    # dataclass this replaced made it optional and the only
                    # producer, OrderBook.snapshot(), has never omitted it.
                    eod_marks[sym] = (
                        to_ticks(bids[0].price, sym) + to_ticks(asks[0].price, sym)
                    ) // 2

            with self._lock:
                # 1. Flush all buffered trades first.
                self._flush()

                # 2. EOD mark-to-market: update mark_price from EOD snapshot.
                if eod_marks:
                    marked_keys: set[tuple[str, str]] = set()
                    for pos in self._ledger.all_positions():
                        mark = eod_marks.get(pos.symbol)
                        if mark is not None:
                            pos.mark_price = mark
                            pos.unrealized_pnl = pos.net_qty * (
                                float(mark) - pos.avg_cost
                            )
                            marked_keys.add((pos.gateway_id, pos.symbol))
                    # Flush only the re-marked position snapshots (CL-M9); the
                    # mark pass runs outside the batch-delta accumulator, so pass
                    # the touched keys explicitly.
                    if marked_keys:
                        position_rows, _ = self._ledger.get_flush_rows(
                            updated_ts_ns=ts_ns, position_keys=marked_keys
                        )
                        flush_batch(self._conn, [], position_rows, [])
                        log.debug(
                            "EOD mark-to-market applied position_rows=%d",
                            len(position_rows),
                        )
                    self._ledger.clear_batch()

                # 3. Write EOD sentinel row.
                record_session_event(
                    self._conn,
                    event_type="EOD",
                    ts_ns=ts_ns,
                    trade_date=eod_trade_date,
                    payload_json=json.dumps(
                        {
                            "eod_marks": eod_marks,
                            "symbols_count": len(eod_marks),
                        }
                    ),
                )

                # CL-L7: also prune retention-window raw rows on EOD so a
                # long-running process does not only prune at startup.
                pruned = prune_old_events(
                    self._conn, retention_days=self._retention_days
                )
            log.info(
                "EOD received — %d symbol mark(s) applied, session_events row written for %s",
                len(eod_marks),
                eod_trade_date,
            )
            if pruned:
                log.info(
                    "EOD prune removed %d trade_events row(s) older than %d days",
                    pruned,
                    self._retention_days,
                )
        except Exception as exc:
            log.warning("error handling system.eod: %s", exc)

    def _handle_session_state(self, payload: dict[str, Any]) -> None:
        """
        Handle session.state — record a PHASE row in session_events (CL-M7).

        The engine broadcasts session-phase transitions on PUB
        (``{state, prev_state}``).  Recording them makes the advertised
        ``event_type='PHASE'`` filter real and lets operators align trade
        activity with the session phase it occurred in.
        """
        try:
            typed = SessionState.from_dict(payload)
            state = typed.state.upper()
            if not state:
                return
            ts_ns = now_ns()
            with self._lock:
                record_session_event(
                    self._conn,
                    event_type="PHASE",
                    ts_ns=ts_ns,
                    trade_date=trade_date(ts_ns, self._tz),
                    payload_json=json.dumps(
                        {
                            "state": state,
                            "prev_state": typed.prev_state,
                        }
                    ),
                )
        except Exception as exc:
            log.warning("error handling session.state: %s", exc)

    def _handle_gateway_auth(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_auth.{id} — the engine's PUB broadcast emitted when
        a gateway completes (or is refused) the connect handshake.

        An *accepted* auth is the observable "gateway connected" event on the
        public feed, so record it exactly as a connect.  A refused auth carries
        ``accepted=False`` and is ignored (no session opened).
        """
        typed = _gen_system.GatewayAuth.from_dict(payload)
        if not typed.accepted:
            return
        self._handle_gateway_connect(typed.to_dict())

    def _handle_gateway_bye(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_bye.{id} — the engine's PUB broadcast emitted when
        a gateway disconnects.  Record it exactly as a disconnect (the inbound
        system.gateway_disconnect topic is PULL-only and never reaches here).
        """
        typed = _gen_system.GatewayBye.from_dict(payload)
        self._handle_gateway_disconnect(typed.to_dict())

    def _handle_gateway_connect(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_connect — record connect timestamp in DB.
        """
        try:
            gateway_id = str(payload.get("gateway_id", "")).upper()
            if not gateway_id:
                return
            ts_ns = now_ns()
            self._gw_connect_ts[gateway_id] = ts_ns
            with self._lock:
                record_gateway_connect(
                    self._conn,
                    gateway_id=gateway_id,
                    connected_at_ns=ts_ns,
                )
            log.info("gateway connected gateway_id=%s", gateway_id)
        except Exception as exc:
            log.warning("error handling gateway_connect: %s", exc)

    def _handle_gateway_disconnect(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_disconnect — update disconnect timestamp and reason.
        Also force-flush buffered trades for that gateway before the engine
        cancels its resting orders.
        """
        try:
            gateway_id = str(payload.get("gateway_id", "")).upper()
            if not gateway_id:
                return

            ts_ns = now_ns()
            reason = payload.get("reason") or payload.get("disconnect_reason")
            # Drop the in-memory connect timestamp (housekeeping only); the DB
            # is the source of truth for matching the open session (CL-M5).
            self._gw_connect_ts.pop(gateway_id, None)

            with self._lock:
                # Force flush so any buffered fills for this gateway are persisted
                # before the engine-side order cancellations arrive.
                self._flush()
                # Close the latest open session in SQL (MAX open connected_at_ns)
                # rather than relying on the in-memory dict — so a clearing
                # restart does not orphan a session opened before the restart.
                close_latest_gateway_session(
                    self._conn,
                    gateway_id=gateway_id,
                    disconnected_at_ns=ts_ns,
                    reason=str(reason) if reason else None,
                )
            log.info(
                "gateway disconnected gateway_id=%s reason=%s",
                gateway_id,
                reason,
            )
        except Exception as exc:
            log.warning("error handling gateway_disconnect: %s", exc)

    # ------------------------------------------------------------------
    # Console P&L table
    # ------------------------------------------------------------------

    def _print_pnl_table(self) -> None:
        # CL-M2: this runs on the receive thread while the timer thread mutates
        # _positions inside _flush.  Snapshot the positions under the lock (each
        # a shallow copy, so field values are captured atomically) before
        # iterating/printing — otherwise the read can tear a row or raise
        # "dictionary changed size during iteration" and kill the receive loop.
        with self._lock:
            positions = [copy.copy(p) for p in self._ledger.all_positions()]
        if not positions:
            return

        t = Table(title="[bold]P&L Summary[/bold]", show_lines=True)
        t.add_column("Gateway", style="cyan")
        t.add_column("Symbol", style="bold")
        t.add_column("Net Qty", justify="right")
        t.add_column("Avg Cost", justify="right")
        t.add_column("Mark", justify="right")
        t.add_column("Realized", justify="right")
        t.add_column("Unrealized", justify="right")
        t.add_column("Total P&L", justify="right")

        for pos in sorted(positions, key=lambda p: (p.gateway_id, p.symbol)):
            scale = float(10**pos.tick_decimals)
            real = pos.realized_pnl / scale
            unreal = pos.unrealized_pnl / scale
            total = real + unreal
            colour = "green" if total >= 0 else "red"
            mark = (
                f"{(pos.mark_price / scale):.{pos.tick_decimals}f}"
                if pos.mark_price is not None
                else "—"
            )
            avg_cost = (
                f"{(pos.avg_cost / scale):.{pos.tick_decimals}f}"
                if pos.avg_cost
                else "—"
            )
            t.add_row(
                pos.gateway_id,
                pos.symbol,
                f"{pos.net_qty:+d}",
                avg_cost,
                mark,
                f"[{colour}]{real:+.2f}[/{colour}]",
                f"[{colour}]{unreal:+.2f}[/{colour}]",
                f"[bold {colour}]{total:+.2f}[/bold {colour}]",
            )

        console.print(t)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def _resolve_timezone(name: str) -> tzinfo | None:
    """
    Resolve a timezone name to a ``tzinfo``, or ``None`` if it is unknown.

    ``UTC`` maps to the builtin ``timezone.utc`` (no tzdata dependency); any
    other name is looked up via ``zoneinfo`` and falls back to ``None`` when the
    IANA database is missing or the name is invalid.
    """
    if name.upper() == "UTC":
        return timezone.utc
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    except Exception:
        return None


def _enable_sql_trace_logging() -> None:
    """Install a dedicated handler for verbose SQLite statement tracing."""
    sql_logger = logging.getLogger("edumatcher.clearing.sql")
    sql_logger.setLevel(logging.DEBUG)
    sql_logger.propagate = False
    if sql_logger.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")
    )
    sql_logger.addHandler(handler)


def _build_parser() -> argparse.ArgumentParser:
    from edumatcher.cli_version import add_version_argument

    parser = argparse.ArgumentParser(
        prog="pm-clearing",
        description="EduMatcher clearing process — SQLite-backed trade P&L tracker",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    add_version_argument(parser, "pm-clearing")

    parser.add_argument(
        "--datapath",
        metavar="PATH",
        default=None,
        help="Data directory or explicit .db file path",
    )
    parser.add_argument(
        "--db-name",
        metavar="NAME",
        default="clearing.db",
        help="SQLite filename within data directory (default: clearing.db)",
    )
    parser.add_argument(
        "--flush-size",
        type=int,
        default=FLUSH_SIZE,
        metavar="N",
        help=f"Max buffered trades before flush (1..100, default: {FLUSH_SIZE})",
    )
    parser.add_argument(
        "--flush-interval",
        type=float,
        default=FLUSH_INTERVAL_SEC,
        metavar="SEC",
        help=f"Max seconds between flushes (>=0.1, default: {FLUSH_INTERVAL_SEC})",
    )
    parser.add_argument(
        "--print-every",
        type=int,
        default=100,
        metavar="N",
        help="Print P&L summary every N trades (0 = never, default: 100)",
    )
    parser.add_argument(
        "--retention-days",
        type=int,
        default=_RETENTION_DAYS,
        metavar="N",
        help=(
            f"Delete trade_events rows older than N days on startup"
            f" (default: {_RETENTION_DAYS}; 0 = disable pruning)"
        ),
    )
    parser.add_argument(
        "--timezone",
        metavar="TZ",
        default="UTC",
        help=(
            "Exchange session timezone used to bucket trades into a trading day"
            " (IANA name, e.g. America/New_York; default: UTC)"
        ),
    )
    parser.add_argument(
        "--sql-trace",
        action="store_true",
        help="Log executed SQLite statements from the clearing writer connection",
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Reduce log output to warnings/errors",
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    if args.log_level:
        level_name = str(args.log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif args.verbose >= 2:
        level = logging.DEBUG
    elif args.verbose == 1:
        level = logging.INFO
    elif args.quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        instance=None,
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


def main() -> None:
    from edumatcher.config import DATA_DIR, ENGINE_PUB_ADDR, resolve_data_path

    parser = _build_parser()
    args = parser.parse_args()

    level = _configure_logging(args)
    if args.sql_trace:
        _enable_sql_trace_logging()
    log.info("starting pm-clearing with log level %s", logging.getLevelName(level))

    if not (1 <= args.flush_size <= 100):
        parser.error("--flush-size must be 1..100")
    if args.flush_interval < 0.1:
        parser.error("--flush-interval must be >= 0.1")
    if args.retention_days < 0:
        parser.error("--retention-days must be >= 0")

    session_tz = _resolve_timezone(args.timezone)
    if session_tz is None:
        parser.error(f"--timezone: unknown timezone {args.timezone!r}")

    if args.datapath is not None:
        dp = resolve_data_path(args.datapath)
        db_path = dp if dp.suffix == ".db" else dp / args.db_name
    else:
        db_path = DATA_DIR / args.db_name

    try:
        process = ClearingProcess(
            pub_addr=ENGINE_PUB_ADDR,
            db_path=db_path,
            flush_size=args.flush_size,
            flush_interval_sec=args.flush_interval,
            print_every=args.print_every,
            retention_days=args.retention_days,
            session_tz=session_tz,
            sql_trace=args.sql_trace,
        )
    except Exception as exc:
        log.error("fatal startup error: %s", exc)
        raise SystemExit(1) from exc

    process.run()


if __name__ == "__main__":
    main()
