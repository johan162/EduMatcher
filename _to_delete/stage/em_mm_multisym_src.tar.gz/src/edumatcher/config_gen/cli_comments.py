"""Static comment-block generator for pm-config-gen --comment-default-config-fields."""

from __future__ import annotations


def build_default_engine_field_comment_lines(config: dict[str, object]) -> list[str]:
    """Build comprehensive comment block for optional engine configuration fields.

    Mimics the sample YAML format with three sections:
    - Overview & top-level settings
    - Complete recognized configuration shape (all optional fields with examples)
    - Field notes and accepted values (detailed field documentation)
    """
    lines: list[str] = []

    # =========================================================================
    # Section 1: Header and overview
    # =========================================================================
    lines.extend(
        [
            "=============================================================================",
            "Complete Recognized Configuration Shape",
            "=============================================================================",
            "",
            "The following commented example lists optional top-level entries and nested",
            "fields recognized by the current engine and scheduler parsers. Leave entries",
            "commented unless you need them.",
            "",
        ]
    )

    # sessions_enabled
    lines.extend(
        [
            "sessions_enabled: true",
            "  Controls whether the scheduler owns session-state transitions.",
            "  true  = engine starts CLOSED and pm-scheduler drives the trading-day timeline.",
            "  false = engine starts in CONTINUOUS and ignores scheduler session transitions.",
            "",
        ]
    )

    # country
    lines.extend(
        [
            "country: Sweden",
            "  Country pm-scheduler uses for two purposes: (1) deciding which calendar",
            "  days are trading days -- the scheduler will not run the daily schedule on",
            "  weekends or on that country's bank holidays (via the python-holidays",
            "  package), and (2) the local timezone/wall-clock used to evaluate schedule",
            '  times and bank holidays. Accepts either a country name (e.g. "Sweden") or',
            '  an ISO 3166-1 alpha-2 code (e.g. "SE"). Defaults to "Sweden" when omitted.',
            "",
        ]
    )

    lines.extend(
        [
            "engine_tuning:",
            "  snapshot_interval_sec: 0.5",
            "    Minimum interval between published book snapshots for a dirty symbol.",
            "    Lower values reduce latency but increase CPU and outbound traffic.",
            "  quote_history_maxlen: 30",
            "    Per-gateway count of recently inactivated quotes kept for QLEGS RECENT/ALL.",
            "    Larger values improve operator history at a linear memory cost.",
            "  drop_copy_buffer_size: 10000",
            "    Number of drop-copy events retained for replay after subscriber reconnects.",
            "    Larger values increase replay depth and memory usage.",
            "  recent_trades_maxlen: 20",
            "    Number of recent trades retained per symbol for snapshots and diagnostics.",
            "    Larger values expose more context at a linear per-book memory cost.",
            "  depth_snapshot_tolerance_ticks: 100",
            "    Depth window around the last trade when publishing depth snapshots.",
            "    Larger values publish more price levels and require more work per snapshot.",
            "",
        ]
    )

    # enforce_collars
    lines.extend(
        [
            "enforce_collars: true",
            "  Global switch for price-collar validation on incoming orders.",
            "",
        ]
    )

    # enforce_circuit_breakers
    lines.extend(
        [
            "enforce_circuit_breakers: true",
            "  Global switch for circuit-breaker halt detection and enforcement.",
            "",
        ]
    )

    # require_mm_seed_quotes
    lines.extend(
        [
            "require_mm_seed_quotes: true",
            "  When true (default), every symbol must define at least one",
            "  market_maker_quotes entry once any MARKET_MAKER gateway is configured.",
            "  Set to false to allow a MARKET_MAKER gateway with a genuinely empty",
            "  book at startup (see docs/concepts/03-concepts-mm-quotes.md).",
            "",
        ]
    )

    # mm_obligation_defaults
    lines.extend(
        [
            "mm_obligation_defaults:",
            "  enforce_mm_obligation: false",
            "  mm_max_spread_ticks: 10",
            "  mm_min_qty: 100",
            "  symbols:",
            "    AAPL:",
            "      enforce_mm_obligation: true",
            "      mm_max_spread_ticks: 8",
            "      mm_min_qty: 200",
            "",
        ]
    )

    # risk_controls
    lines.extend(
        [
            "risk_controls:",
            "  default_level: L2",
            "  levels:",
            "    L1:",
            "      collar:",
            "        static_band_pct: 0.30",
            "        dynamic_band_pct: 0.05",
            "    L2:",
            "      collar:",
            "        static_band_pct: 0.20",
            "        dynamic_band_pct: 0.02",
            "",
        ]
    )

    # circuit_breaker_defaults
    lines.extend(
        [
            "circuit_breaker_defaults:",
            "  reference_window_ns: 300000000000",
            "  levels:",
            "    L1:",
            "      price_shift_pct: 0.07",
            "      halt_duration_ns: 300000000000",
            "    L2:",
            "      price_shift_pct: 0.13",
            "      halt_duration_ns: 900000000000",
            "    L3:",
            "      price_shift_pct: 0.20",
            "      halt_duration_ns: null",
            "  reopening:",
            "    enabled: true",
            "    initial_band_pct: 0.10",
            "    random_end_max_ns: 30000000000",
            "    expansions:",
            "    - widen_pct: 0.10",
            "      min_duration_ns: 120000000000",
            "    - widen_pct: 0.20",
            "      min_duration_ns: 300000000000",
            "",
        ]
    )

    # gateways
    lines.extend(
        [
            "gateways:",
            "  alf:",
            "    - id: TRADER01",
            "      description: Student workstation 1",
            "      role: TRADER",
            "      disconnect_behaviour: CANCEL_ALL",
            "      quote_refresh_policy: INACTIVATE_ON_ANY_FILL",
            "      smp_action: NONE",
            "      enforce_mm_obligation: false",
            "      mm_max_spread_ticks: 10",
            "      mm_min_qty: 100",
            "      mm_obligations:",
            "        AAPL:",
            "          enforce_mm_obligation: true",
            "          max_spread_ticks: 6",
            "          min_qty: 300",
            "",
        ]
    )

    # symbols section
    lines.extend(
        [
            "symbols:",
            "  AAPL:",
            "    tick_decimals: 2",
            "    level: L2",
            "    last_buy_price: 209.50",
            "    last_sell_price: 210.50",
            "    outstanding_shares: 2600000000",
            "    collar:",
            "      static_band_pct: 0.20",
            "      dynamic_band_pct: 0.02",
            "    order_limits:",
            "      max_order_qty: 50000",
            "      max_order_value: 2500000",
            "    circuit_breaker:",
            "      reference_window_ns: 300000000000",
            "      levels:",
            "        L1:",
            "          price_shift_pct: 0.07",
            "          halt_duration_ns: 300000000000",
            "        L2:",
            "          price_shift_pct: 0.13",
            "          halt_duration_ns: 900000000000",
            "        L3:",
            "          price_shift_pct: 0.20",
            "          halt_duration_ns:",
            "    market_maker_quotes:",
            "      - gateway_id: MM01",
            "        quote_id: SEED-MM01-AAPL",
            "        bid_price: 209.00",
            "        ask_price: 211.00",
            "        bid_qty: 1000",
            "        ask_qty: 1000",
            "        tif: DAY",
            "        seed_once: true",
            "",
        ]
    )

    # market_maker_combos
    lines.extend(
        [
            "market_maker_combos:",
            "  - combo_id: SEED-PAIR-AAPL-MSFT",
            "    combo_type: AON",
            "    tif: DAY",
            "    legs:",
            "      - symbol: AAPL",
            "        side: BUY",
            "        order_type: LIMIT",
            "        quantity: 100",
            "        price: 20950",
            "        stop_price: null",
            "        smp_action: NONE",
            "      - symbol: MSFT",
            "        side: SELL",
            "        order_type: LIMIT",
            "        quantity: 50",
            "        price: 41550",
            "        stop_price: null",
            "        smp_action: NONE",
            "",
        ]
    )

    # post_trade_gateway
    lines.extend(
        [
            "post_trade_gateway:",
            "  name: ralf-gwy01",
            "  bind_address: 0.0.0.0",
            "  port: 5580",
            "  replay_retention_sec: 86400",
            "  heartbeat_interval_sec: 1",
            "  idle_timeout_sec: 5",
            "  max_client_queue: 10000",
            "  allowed_roles: [CLEARING, DROP_COPY, AUDIT]",
            "",
        ]
    )

    # market_data_gateway
    lines.extend(
        [
            "market_data_gateway:",
            "  enabled: true",
            "  name: md-gwy01",
            "  bind_address: 0.0.0.0",
            "  port: 5570",
            "  heartbeat_interval_sec: 1",
            "  idle_timeout_sec: 5",
            "  replay_window_sec: 30",
            "  max_symbols_per_client: 200",
            "  max_client_queue: 10000",
            "  depth_levels: 10",
            "",
        ]
    )

    # dc_gateway
    lines.extend(
        [
            "dc_gateway:",
            "  name: dc-gwy01",
            "  bind_address: 0.0.0.0",
            "  port: 5590",
            "  heartbeat_interval_sec: 5",
            "  idle_timeout_sec: 30",
            "  max_client_queue: 10000",
            "",
        ]
    )

    # log_server
    lines.extend(
        [
            "log_server:",
            "  enabled: true",
            "  name: log-srv01",
            "  bind_address: 0.0.0.0",
            "  port: 5600",
            "  db_path: data/log.db",
            "  retention_days: 30",
            "  max_message_bytes: 65536",
            "  max_client_queue: 10000",
            "  write_batch_size: 50",
            "  write_batch_interval_ms: 100",
            "  heartbeat_interval_sec: 5",
            "  pubsub_enabled: true",
            "  pub_port: 5601",
            "  pull_port: 5602",
            "  lease_sec: 30",
            "  max_lease_sec: 300",
            "  max_subscribers: 32",
            "  notify_interval_ms: 250",
            "  backfill_chunk_rows: 500",
            "  max_backfill_minutes: 1440",
            "  max_backfill_rows: 100000",
            "  max_pending_rows: 20000",
            "  pub_sndhwm: 10000",
            "",
        ]
    )

    # indices
    lines.extend(
        [
            "indices:",
            "    description: Broad technology benchmark",
            "    base_value: 1000.0",
            "    publish_interval_sec: 1.0",
            "    history_file: data/indexes/EDU100_history.jsonl",
            "    state_file: data/indexes/EDU100_state.json",
            "    constituents: [AAPL, MSFT, TSLA]",
            "  - id: EDUFIN",
            "    description: Financial sector basket",
            "    base_value: 1000.0",
            "    publish_interval_sec: 1.0",
            "    history_file: data/indexes/EDUFIN_history.jsonl",
            "    state_file: data/indexes/EDUFIN_state.json",
            "    constituents: [JPM, BAC, GS]",
            "",
        ]
    )

    # api_gateways
    lines.extend(
        [
            "api_gateways:",
            "  desk:",
            "    enabled: true",
            "    host: 0.0.0.0",
            "    port: 8080",
            "    swagger_enabled: true",
            "    log_level: info",
            "    stats_db: data/stats.db",
            "    credentials:",
            "      - api_key: key-trader-demo",
            "        gateway_id: TRADER01",
            "        description: Demo trading client",
            "    rate_limit:",
            "      writes_per_second: 10",
            "      burst: 20",
            "    timeouts:",
            "      engine_auth_sec: 3.0",
            "      engine_reply_sec: 3.0",
            "      wait_ack_sec: 3.0",
            "  dashboards:",
            "    enabled: true",
            "    host: 0.0.0.0",
            "    port: 8081",
            "    credentials:",
            "      - api_key: key-dashboard-demo",
            "        gateway_id: null",
            "        description: Read-only dashboard client",
            "",
        ]
    )

    # schedule
    lines.extend(
        [
            "schedule:",
            '  pre_open: "09:00"',
            '  opening_auction_start: "09:25"',
            '  continuous_start: "09:30"',
            '  closing_auction_start: "16:00"',
            '  closing_auction_end: "16:05"',
            "",
        ]
    )

    # =========================================================================
    # Section 2: Field notes and accepted values
    # =========================================================================
    lines.extend(
        [
            "=============================================================================",
            "Field Notes and Accepted Values",
            "=============================================================================",
            "",
        ]
    )

    lines.extend(
        [
            "engine_tuning entries",
            "" + "-" * 21,
            "snapshot_interval_sec: 0.5",
            "  Minimum time between dirty-book snapshot publishes for the same symbol.",
            "  Lower values improve freshness but increase publish rate and CPU.",
            "quote_history_maxlen: 30",
            "  Per-gateway RECENT/ALL quote-history entries retained in memory.",
            "  Raise this for longer QLEGS history, lower it to cap memory usage.",
            "drop_copy_buffer_size: 10000",
            "  Number of drop-copy events available for replay after reconnect.",
            "  Raise this for longer replay windows, lower it to reduce memory usage.",
            "recent_trades_maxlen: 20",
            "  Recent trade rows stored per order book and echoed in book snapshots.",
            "  Raise this for richer diagnostics, lower it for lower per-symbol memory cost.",
            "depth_snapshot_tolerance_ticks: 100",
            "  Width of the published depth window around the last trade, in ticks.",
            "  Raise this for deeper depth snapshots, lower it to reduce snapshot work and payload size.",
            "",
        ]
    )

    lines.extend(
        [
            "mm_obligation_defaults entries",
            "" + "-" * 30,
            "enforce_mm_obligation: false",
            "  Enables exchange-side market-maker compliance checks for quote width and size.",
            "mm_max_spread_ticks: 10",
            "  Maximum allowed bid-ask spread (in ticks) for obligated quotes.",
            "mm_min_qty: 100",
            "  Minimum displayed quantity required on each side of an obligated quote.",
            "symbols:",
            "  Per-symbol policy overrides when different instruments require different",
            "  quoting obligations. Keys must match configured symbols.",
            "  Effective precedence is: gateway mm_obligations >",
            "  mm_obligation_defaults.symbols > gateway flat fields >",
            "  mm_obligation_defaults flat fields > built-in defaults.",
            "",
        ]
    )

    lines.extend(
        [
            "risk_controls entries",
            "" + "-" * 21,
            "default_level: L2",
            "  Baseline risk profile applied to symbols that do not set a symbol-specific level.",
            "levels:",
            "  Named risk profile catalog used by symbols and by default_level.",
            "levels.<NAME>.collar:",
            "  Price-band configuration for order acceptance checks:",
            "  static_band_pct anchors to a session reference, dynamic_band_pct tracks live prices.",
            "levels.<NAME>.collar.static_band_pct: 0.20",
            "  Wider static guardrail around the reference price.",
            "levels.<NAME>.collar.dynamic_band_pct: 0.02",
            "  Tighter dynamic guardrail around near-live trading levels.",
            "  Precedence: symbols.<SYM>.collar > symbols.<SYM>.level >",
            "  risk_controls.default_level > built-in defaults.",
            "  Note: levels.<NAME>.circuit_breaker is not supported; use",
            "  circuit_breaker_defaults at the top level instead.",
            "",
        ]
    )

    lines.extend(
        [
            "circuit_breaker_defaults entries",
            "" + "-" * 33,
            "reference_window_ns: 300000000000",
            "  Lookback window used to compute the rolling reference price for halt triggers.",
            "levels:",
            "  Halt ladder definitions applied exchange-wide unless overridden per symbol.",
            "  Symbol-level circuit_breaker.levels entries merge field-by-field over defaults.",
            "levels.<NAME>.price_shift_pct:",
            "  Percent move from the rolling reference price required to trigger this halt level.",
            "levels.<NAME>.halt_duration_ns: null",
            "  Halt length for this level; null means halt remains active for the rest of day.",
            "  Built-in ladder values: L1=300000000000 (5m), L2=900000000000",
            "  (15m), L3=null.",
            "  Built-in default ladder: L1=7%/5m, L2=13%/15m, L3=20%/rest-of-day.",
            "",
        ]
    )

    lines.extend(
        [
            "gateways.alf entries",
            "" + "-" * 20,
            "id:",
            "  Participant session identifier used for login, permissions, and routing.",
            "description: null",
            "  Operator-facing label for dashboards and diagnostics.",
            "role: TRADER",
            "  Permission profile: TRADER submits orders, MARKET_MAKER supplies quotes,",
            "  ADMIN can issue exchange control commands.",
            "disconnect_behaviour: CANCEL_QUOTES_ONLY",
            "  Cleanup action on disconnect to control stale exposure risk.",
            "quote_refresh_policy: INACTIVATE_ON_ANY_FILL",
            "  Determines when seeded quotes are inactivated after executions.",
            "smp_action: NONE",
            "  Gateway-level self-match-prevention default (NONE, CANCEL_AGGRESSOR,",
            "  CANCEL_RESTING, CANCEL_BOTH). Applied by the engine to any order, combo",
            "  leg, or quote from this gateway that omits its own SMP=; an explicit",
            "  per-request SMP= (including SMP=NONE) always takes precedence.",
            "enforce_mm_obligation: false",
            "  Gateway-level switch to enforce market-maker obligations for this participant.",
            "mm_max_spread_ticks: 10",
            "  Gateway-level quote spread cap used by obligation checks.",
            "mm_min_qty: 100",
            "  Gateway-level minimum quote size used by obligation checks.",
            "mm_obligations:",
            "  Per-symbol overrides for this gateway when obligations differ by instrument.",
            "  Use enforce_mm_obligation, max_spread_ticks, and min_qty inside this map.",
            "mm_obligations.<SYM>.enforce_mm_obligation: false",
            "  Per-symbol switch enabling/disabling obligation checks for this gateway.",
            "mm_obligations.<SYM>.max_spread_ticks: 10",
            "  Per-symbol spread cap in ticks.",
            "mm_obligations.<SYM>.min_qty: 100",
            "  Per-symbol minimum quote size.",
            "",
        ]
    )

    lines.extend(
        [
            "symbols entries",
            "" + "-" * 15,
            "tick_decimals: 2",
            "  Display precision and tick-size conversion for all prices of this symbol.",
            "level:",
            "  Symbol's assigned risk profile name from risk_controls.levels.",
            "  If omitted, the symbol inherits risk_controls.default_level.",
            "last_buy_price: null",
            "last_sell_price: null",
            "  Startup seed values for last-trade references before live or persisted history exists.",
            "outstanding_shares: null",
            "  Issued share count used by analytics, reporting, and index-style consumers.",
            "collar:",
            "  Symbol-specific collar override when this instrument needs tighter/looser bands.",
            "collar.static_band_pct: 0.20",
            "  Symbol-level static guardrail around reference price.",
            "collar.dynamic_band_pct: 0.02",
            "  Symbol-level dynamic guardrail around near-live prices.",
            "order_limits:",
            "  Pre-trade order-size and notional caps for this symbol. There is",
            "  no level or global default: a cap set nowhere is not enforced.",
            "order_limits.max_order_qty: null",
            "  Largest quantity a single order in this symbol may carry.",
            "order_limits.max_order_value: null",
            "  Largest notional a single priced order in this symbol may carry.",
            "  Not checked for MARKET/IOC orders, which carry no price.",
            "circuit_breaker:",
            "  Symbol-specific halt policy override layered on top of circuit_breaker_defaults.",
            "  Levels merge field-by-field, so each symbol can override only needed fields.",
            "circuit_breaker.reference_window_ns: 300000000000",
            "  Symbol-specific rolling reference window for halt detection.",
            "circuit_breaker.levels.<NAME>.price_shift_pct: 0.07",
            "  Percent move threshold that triggers halt level <NAME>.",
            "circuit_breaker.levels.<NAME>.halt_duration_ns: null",
            "  Halt duration for level <NAME>; null means rest-of-day.",
            "  halt_duration_ns may be null for rest-of-day halts.",
            "  With ACE this is the *minimum* length of the reopening call phase.",
            "  reference_window_ns can override the global rolling reference window.",
            "circuit_breaker.reopening.enabled: true",
            "  Automated Corridor Expansion for this symbol's reopening auction.",
            "  When false the halt reopens at the equilibrium price, uncollared.",
            "circuit_breaker.reopening.initial_band_pct: 0.10",
            "  Corridor half-width at the start of the first call phase, as a",
            "  fraction of the circuit breaker's rolling reference price.",
            "circuit_breaker.reopening.random_end_max_ns: 30000000000",
            "  Upper bound of the uniform random tail added to every call phase.",
            "  0 makes reopen times exactly predictable.",
            "market_maker_quotes:",
            "  Startup quote seeds used to initialize liquidity for this symbol.",
            "  Required when MARKET_MAKER gateways are configured, unless the",
            "  top-level require_mm_seed_quotes is set to false.",
            "  gateway_id must reference a configured MARKET_MAKER gateway.",
            "",
        ]
    )

    lines.extend(
        [
            "market_maker_quotes entries (under symbols.<SYM>.market_maker_quotes)",
            "" + "-" * 68,
            "gateway_id:",
            "  Market-maker session that owns and submits this seed quote.",
            "quote_id: null",
            "  External quote identifier for audit/reconciliation; auto-generated when omitted.",
            "bid_price / ask_price:",
            "  Initial two-sided quote prices used to seed the order book.",
            "  bid_price must be less than ask_price; engine converts display prices to ticks.",
            "bid_qty / ask_qty:",
            "  Initial displayed quantities for each side of the seeded quote.",
            "tif: DAY",
            "  Time-in-force policy for the seeded quote lifecycle.",
            "  Prefer DAY for seeds — GTC seeds can duplicate on restart if",
            "  gtc_orders.json still contains the previous session's orders.",
            "seed_once: true",
            "  Prevents re-injecting the same seed quote after restart when history already exists.",
            "",
        ]
    )

    lines.extend(
        [
            "market_maker_combos entries",
            "" + "-" * 27,
            "combo_id:",
            "  Stable identifier for this seeded multi-leg strategy.",
            "combo_type: AON",
            "  Execution rule for the combo (AON executes all legs together).",
            "tif: DAY",
            "  Time-in-force policy for the combo order.",
            "legs:",
            "  Ordered leg definitions that specify how the strategy is composed.",
            "  Requires 2..10 legs; symbols must be configured and unique per combo.",
            "leg.symbol:",
            "  Instrument traded by this leg; must reference a configured symbol.",
            "leg.side:",
            "  Direction of this leg within the strategy (BUY or SELL).",
            "leg.order_type:",
            "  Execution style for this leg (MARKET, LIMIT, STOP, etc.).",
            "leg.quantity:",
            "  Quantity contributed by this leg to each combo execution.",
            "leg.price:",
            "  Tick price used by priced order types (LIMIT, STOP_LIMIT, FOK, ICEBERG, IOC).",
            "  Example: with tick_decimals=2, display 209.50 is stored as tick 20950.",
            "leg.stop_price:",
            "  Trigger price in ticks for STOP, STOP_LIMIT, and TRAILING_STOP leg types.",
            "leg.smp_action: NONE",
            "  Self-match prevention behavior when this leg would cross own resting interest.",
            "",
        ]
    )

    lines.extend(
        [
            "post_trade_gateway entries",
            "" + "-" * 27,
            "name: ralf-gwy01",
            "  Service name used in logs, telemetry, and client diagnostics.",
            "bind_address: 0.0.0.0",
            "  Network interface/address the post-trade server listens on for incoming clients.",
            "port: 5580",
            "  TCP port clients connect to for fills, drop copy, and post-trade replay.",
            "replay_retention_sec: 86400",
            "  How long post-trade events are retained for client replay after reconnect.",
            "heartbeat_interval_sec: 1",
            "  Keepalive interval used to prove connection liveness to clients.",
            "idle_timeout_sec: 5",
            "  Disconnect threshold when a client is silent for too long.",
            "max_client_queue: 10000",
            "  Per-client outbound backlog limit before applying backpressure/disconnect logic.",
            "allowed_roles: [CLEARING, DROP_COPY, AUDIT]",
            "  Roles authorized to subscribe to this gateway's post-trade data stream.",
            "",
        ]
    )

    lines.extend(
        [
            "market_data_gateway entries",
            "" + "-" * 28,
            "enabled: true",
            "  Master switch that enables or disables the market data gateway service.",
            "name: md-gwy01",
            "  Service name shown in logs, monitoring, and client banners.",
            "bind_address: 0.0.0.0",
            "  Network interface/address the market data server binds to.",
            "port: 5570",
            "  TCP port clients connect to for snapshots, deltas, and replay requests.",
            "heartbeat_interval_sec: 1",
            "  Keepalive cadence for market-data client sessions.",
            "idle_timeout_sec: 5",
            "  Session timeout when no traffic is received from a client.",
            "replay_window_sec: 30",
            "  In-memory replay horizon available to late/reconnecting clients.",
            "max_symbols_per_client: 200",
            "  Subscription safety limit to prevent a single client from over-consuming fanout.",
            "max_client_queue: 10000",
            "  Per-client outbound queue cap before overload handling is triggered.",
            "depth_levels: 10",
            "  Number of aggregated price levels per side included in DEPTH channel snapshots and updates.",
            "",
        ]
    )

    lines.extend(
        [
            "dc_gateway entries",
            "" + "-" * 18,
            "name: dc-gwy01",
            "  Service name echoed in WELCOME messages to connecting DC1 clients.",
            "bind_address: 0.0.0.0",
            "  Network interface/address the drop-copy TCP gateway listens on.",
            "port: 5590",
            "  TCP port DC1 clients connect to for live fill notifications.",
            "heartbeat_interval_sec: 5",
            "  Seconds between HB keepalive lines when no other outbound traffic is pending.",
            "idle_timeout_sec: 30",
            "  Disconnect threshold when a connected client sends no traffic for this many seconds.",
            "max_client_queue: 10000",
            "  Per-client outbound line buffer capacity before the client is treated as slow and dropped.",
            "",
        ]
    )

    lines.extend(
        [
            "log_server entries",
            "" + "-" * 18,
            "enabled: true",
            "  Master switch — lets pm-log-srv refuse to accept connections when set to false.",
            "name: log-srv01",
            "  Server name echoed in the LALF WELCOME|SRV= field.",
            "bind_address: 0.0.0.0",
            "  Network interface/address the centralized log collector listens on (127.0.0.1 for loopback-only).",
            "port: 5600",
            "  TCP port LALF clients (every other pm-* process) connect to for centralized logging.",
            "db_path: data/log.db",
            "  SQLite database path where log_events/processes/server_stats are stored.",
            "retention_days: 30",
            "  Days before old log_events rows are pruned, once per hour; 0 or null means unbounded retention.",
            "max_message_bytes: 65536",
            "  Maximum LOG payload size before truncation; oversized messages are truncated and stored, never dropped.",
            "max_client_queue: 10000",
            "  Per-connection outbound backlog limit before backpressure is applied.",
            "write_batch_size: 50",
            "  Maximum rows per SQLite transaction in the background writer thread.",
            "write_batch_interval_ms: 100",
            "  Maximum time between writer-thread flushes, whichever comes first with write_batch_size.",
            "heartbeat_interval_sec: 5",
            "  Interval a connected client must send HB within (echoed as WELCOME|HBINT=).",
            "  Also the interval at which log.server_state is published on LALF-PS.",
            "pubsub_enabled: true",
            "  Master switch for LALF-PS, the ZeroMQ log distribution interface.",
            "  When false no ZeroMQ socket is bound and only TCP collection runs.",
            "pub_port: 5601",
            "  ZeroMQ PUB port carrying live rows, notify ticks, backfill chunks and acks.",
            "pull_port: 5602",
            "  ZeroMQ PULL port receiving subscriber control requests.",
            "  port, pub_port and pull_port must all be different.",
            "lease_sec: 30",
            "  Subscription lease TTL; a subscriber that stops sending log.renew within",
            "  this window is reaped and its buffers discarded.",
            "max_lease_sec: 300",
            "  Upper bound a subscriber may request; must be >= lease_sec.",
            "max_subscribers: 32",
            "  Maximum concurrent leased subscriptions before TOO_MANY_SUBS is returned.",
            "notify_interval_ms: 250",
            "  Coalescing window for NOTIFY-mode ticks, and the floor a subscriber may request.",
            "backfill_chunk_rows: 500",
            "  Rows per log.backfill chunk, and per live log.event message.",
            "max_backfill_minutes: 1440",
            "  Largest 'last n minutes' window a subscriber may request.",
            "max_backfill_rows: 100000",
            "  Hard cap on rows returned by one backfill; the final chunk sets truncated.",
            "max_pending_rows: 20000",
            "  Per-subscription STREAM buffer cap; a lagging subscriber loses its oldest",
            "  buffered rows (reported back as the dropped counter).",
            "pub_sndhwm: 10000",
            "  ZeroMQ send high-water mark on the PUB socket.",
            "",
        ]
    )

    lines.extend(
        [
            "api_gateways entries",
            "" + "-" * 20,
            "api_gateways.<NAME>:",
            "  Named REST/WebSocket gateway process configuration.",
            "enabled: true",
            "  Master switch that lets pm-api-gwy start serving clients.",
            "host: 0.0.0.0",
            "  HTTP bind address used by uvicorn (use 127.0.0.1 for loopback-only).",
            "port: 8080",
            "  HTTP listen port for REST and WebSocket clients.",
            "swagger_enabled: true",
            "  Enables /docs and /openapi.json when true.",
            "log_level: info",
            "  Uvicorn logging level: debug, info, warning, or error.",
            "stats_db: data/stats.db",
            "  SQLite stats database used by /history endpoints.",
            "credentials:",
            "  Bearer-token credentials accepted by REST and WebSocket auth.",
            "credentials[].gateway_id:",
            "  Must reference gateways.alf[].id for trading access; null means read-only.",
            "  A non-null gateway_id may appear in only one api_gateways entry.",
            "rate_limit.writes_per_second: 10",
            "  Per API-key write throughput for POST/PATCH/DELETE routes.",
            "rate_limit.burst: 20",
            "  Per API-key burst capacity for write routes.",
            "timeouts.engine_auth_sec: 3.0",
            "  Intended engine-auth handshake timeout setting.",
            "timeouts.engine_reply_sec: 3.0",
            "  Timeout for engine request/reply read endpoints.",
            "timeouts.wait_ack_sec: 3.0",
            "  Timeout for write endpoints using ?wait=ack.",
            "",
        ]
    )

    lines.extend(
        [
            "schedule entries",
            "" + "-" * 16,
            "pre_open: 09:00",
            "  Start of pre-open state, when participants can stage orders before opening auction.",
            "opening_auction_start: 09:25",
            "  Time the opening uncross begins and opening match logic takes over.",
            "continuous_start: 09:30",
            "  Transition from opening auction into continuous limit-order-book matching.",
            "closing_auction_start: 16:00",
            "  Time the closing auction phase begins and continuous matching stops.",
            "closing_auction_end: 16:05",
            "  End of closing auction and completion of the trading session timeline.",
            "  Times are HH:MM in local server time and are applied in trading-day order.",
            "",
        ]
    )

    lines.extend(
        [
            "indices entries",
            "" + "-" * 15,
            "id:",
            "  Alphanumeric index identifier used in messages, file names, and CALF subscriptions.",
            "description:",
            "  Human-readable label shown in operator output and diagnostics.",
            "base_value: 1000.0",
            "  Starting level that the divisor is calibrated to at launch.",
            "publish_interval_sec: 1.0",
            "  Throttle: minimum seconds between consecutive index.update broadcasts.",
            "history_file: data/indexes/<ID>_history.jsonl",
            "  Append-only JSONL file where pm-index records LEVEL, EOD, and CORP_ACTION entries.",
            "state_file: data/indexes/<ID>_state.json",
            "  JSON checkpoint file used to recover divisor and last prices across restarts.",
            "constituents:",
            "  Ordered list of symbol IDs included in this index; each must be configured in symbols.",
            "  Each constituent symbol must have outstanding_shares set.",
            "  Maximum 5 indices per exchange; maximum constituents per index limited by performance.",
            "",
        ]
    )

    return lines
