"""Argparse builder for pm-config-gen CLI."""

from __future__ import annotations

import argparse

from edumatcher.config_gen.defaults import (
    DEFAULT_ACE_INITIAL_BAND_PCT,
    DEFAULT_ACE_RANDOM_END_MAX_NS,
    DEFAULT_CB_WINDOW_NS,
    DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS,
    DEFAULT_DROP_COPY_BUFFER_SIZE,
    DEFAULT_MM_MIN_QTY,
    DEFAULT_MM_SPREAD_TICKS,
    DEFAULT_QUOTE_HISTORY_MAXLEN,
    DEFAULT_RECENT_TRADES_MAXLEN,
    DEFAULT_SCHEDULE,
    DEFAULT_SNAPSHOT_INTERVAL_SEC,
    DEFAULT_TICK_DECIMALS,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-config-gen",
        description=(
            "Generate a parser-compatible engine_config.yaml from concise CLI inputs."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-config-gen")

    parser.add_argument(
        "--symbols",
        nargs="+",
        required=True,
        metavar="SYM",
        help="One or more symbols.",
    )
    parser.add_argument(
        "--gateways",
        nargs="+",
        required=True,
        metavar="GW_SPEC",
        help="One or more gateway specs (ID[:ROLE[:DISCONNECT]]).",
    )
    parser.add_argument(
        "--gateway-smp",
        action="append",
        default=[],
        metavar="GW_ID:SMP_ACTION",
        help="Gateway-level self-match-prevention default (NONE, CANCEL_AGGRESSOR, "
        "CANCEL_RESTING, CANCEL_BOTH), applied by the engine to any order, combo "
        "leg, or quote from GW_ID that doesn't specify its own SMP=. GW_ID must "
        "be one of the IDs given to --gateways. Omit for a gateway to leave its "
        "default at NONE. Can be repeated.",
    )
    parser.add_argument(
        "--symbol-opts",
        action="append",
        default=[],
        metavar="SYMBOL:KEY=VALUE[,KEY=VALUE]",
        help="Per-symbol overrides. Can be repeated.",
    )
    parser.add_argument(
        "--symbol-static-band",
        action="append",
        default=[],
        metavar="SYM:PCT",
        help="Per-symbol collar static band pct in (0,1). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-dynamic-band",
        action="append",
        default=[],
        metavar="SYM:PCT",
        help="Per-symbol collar dynamic band pct in (0,1). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-max-order-qty",
        action="append",
        default=[],
        metavar="SYM:N",
        help="Per-symbol order_limits.max_order_qty in shares (> 0). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-max-order-value",
        action="append",
        default=[],
        metavar="SYM:AMOUNT",
        help=(
            "Per-symbol order_limits.max_order_value as notional (> 0). "
            "Can be repeated."
        ),
    )
    parser.add_argument(
        "--symbol-risk-level",
        action="append",
        default=[],
        metavar="SYM:LEVEL",
        help="Per-symbol risk level key override. Can be repeated.",
    )
    parser.add_argument(
        "--outstanding-shares",
        action="append",
        default=[],
        metavar="SYM:N",
        help="Per-symbol outstanding shares (positive integer). Can be repeated.",
    )

    sess_group = parser.add_mutually_exclusive_group()
    sess_group.add_argument(
        "--sessions-enabled",
        dest="sessions_enabled",
        action="store_true",
        help="Enable scheduler-driven sessions.",
    )
    sess_group.add_argument(
        "--no-sessions-enabled",
        dest="sessions_enabled",
        action="store_false",
        help="Disable scheduler-driven sessions.",
    )
    parser.set_defaults(sessions_enabled=False)

    parser.add_argument(
        "--snapshot-interval",
        type=float,
        default=DEFAULT_SNAPSHOT_INTERVAL_SEC,
        metavar="SECS",
        help="Snapshot interval seconds (> 0).",
    )
    parser.add_argument(
        "--quote-history-maxlen",
        type=int,
        default=DEFAULT_QUOTE_HISTORY_MAXLEN,
        metavar="N",
        help="Max RECENT/ALL quote-history entries kept per gateway (> 0).",
    )
    parser.add_argument(
        "--drop-copy-buffer-size",
        type=int,
        default=DEFAULT_DROP_COPY_BUFFER_SIZE,
        metavar="N",
        help="Drop-copy replay buffer size in messages (> 0).",
    )
    parser.add_argument(
        "--recent-trades-maxlen",
        type=int,
        default=DEFAULT_RECENT_TRADES_MAXLEN,
        metavar="N",
        help="Recent trades retained per book snapshot (> 0).",
    )
    parser.add_argument(
        "--depth-snapshot-tolerance-ticks",
        type=int,
        default=DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS,
        metavar="N",
        help="Depth snapshot window around last trade in ticks (> 0).",
    )

    parser.add_argument(
        "--no-collars",
        action="store_true",
        help="Set enforce_collars: false.",
    )
    parser.add_argument(
        "--no-circuit-breakers",
        action="store_true",
        help="Set enforce_circuit_breakers: false.",
    )

    parser.add_argument(
        "--static-band",
        type=float,
        default=None,
        metavar="PCT",
        help="DEFAULT static band pct in (0,1).",
    )
    parser.add_argument(
        "--dynamic-band",
        type=float,
        default=None,
        metavar="PCT",
        help="DEFAULT dynamic band pct in (0,1).",
    )

    parser.add_argument(
        "--risk-level",
        action="append",
        default=[],
        metavar="LEVEL_SPEC",
        help="Repeatable NAME:STATIC_PCT[:DYNAMIC_PCT]",
    )

    parser.add_argument(
        "--cb-levels",
        nargs="+",
        default=None,
        metavar="CB_SPEC",
        help="NAME:SHIFT_PCT[:HALT_MINS] entries. Omit HALT_MINS for a rest-of-day halt.",
    )
    parser.add_argument(
        "--cb-window-ns",
        type=int,
        default=DEFAULT_CB_WINDOW_NS,
        metavar="NS",
        help="CB reference window nanoseconds.",
    )

    parser.add_argument(
        "--no-ace",
        action="store_true",
        help=(
            "Disable Automated Corridor Expansion. A halt then reopens at the "
            "equilibrium price whatever it is, with no corridor and no extensions."
        ),
    )
    parser.add_argument(
        "--ace-initial-band",
        type=float,
        default=DEFAULT_ACE_INITIAL_BAND_PCT,
        metavar="PCT",
        help=(
            "Reopening corridor half-width as a fraction of the reference price "
            f"(default {DEFAULT_ACE_INITIAL_BAND_PCT})."
        ),
    )
    parser.add_argument(
        "--ace-expansions",
        nargs="+",
        default=None,
        metavar="EXP_SPEC",
        help=(
            "WIDEN_PCT:MINUTES rungs of the expansion ladder, in order. The last "
            "rung repeats indefinitely, which is what lets the corridor eventually "
            "contain any price. Default: 0.10:2 0.20:5 (Nasdaq's ladder)."
        ),
    )
    parser.add_argument(
        "--ace-random-end-ns",
        type=int,
        default=DEFAULT_ACE_RANDOM_END_MAX_NS,
        metavar="NS",
        help=(
            "Upper bound of the uniform random tail added to every call phase. "
            "0 disables the random end, making reopen times predictable."
        ),
    )
    parser.add_argument(
        "--ace-random-seed",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Seed the random-end generator for reproducible demos. Omit for OS "
            "entropy, which is what a real venue wants."
        ),
    )

    parser.add_argument(
        "--mm-spread-ticks",
        type=int,
        default=DEFAULT_MM_SPREAD_TICKS,
        metavar="N",
        help="Global MM max spread ticks.",
    )
    parser.add_argument(
        "--mm-min-qty",
        type=int,
        default=DEFAULT_MM_MIN_QTY,
        metavar="N",
        help="Global MM min qty.",
    )

    mm_group = parser.add_mutually_exclusive_group()
    mm_group.add_argument(
        "--enforce-mm-obligations",
        dest="enforce_mm_obligations",
        action="store_true",
        help="Enable MM obligations globally.",
    )
    mm_group.add_argument(
        "--no-enforce-mm-obligations",
        dest="enforce_mm_obligations",
        action="store_false",
        help="Disable MM obligations globally.",
    )
    parser.set_defaults(enforce_mm_obligations=False)

    parser.add_argument(
        "--tick-decimals",
        type=int,
        default=DEFAULT_TICK_DECIMALS,
        metavar="N",
        help="Default symbol tick decimals.",
    )
    parser.add_argument(
        "--seed-last-prices",
        action="store_true",
        help="Emit last_buy_price/last_sell_price null placeholders.",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        metavar="N",
        help="Deterministic RNG seed for generated training values.",
    )
    parser.add_argument(
        "--seed-mm-mid-range",
        default=None,
        metavar="MIN:MAX",
        help=(
            "Seed MM quotes from a random midpoint in the inclusive MIN:MAX range, "
            "rounded to the symbol tick grid."
        ),
    )
    parser.add_argument(
        "--seed-last-prices-from-mm",
        action="store_true",
        help=(
            "When seeding MM quotes, set last_buy_price/last_sell_price to the same "
            "midpoint used for the generated quote."
        ),
    )
    parser.add_argument(
        "--no-mm-seed-quotes",
        action="store_true",
        help=(
            "Set require_mm_seed_quotes: false. Allows a MARKET_MAKER gateway to be "
            "configured with no market_maker_quotes seed for any symbol, so the book "
            "starts genuinely empty. Without --seed-mm-mid-range, no market_maker_quotes "
            "entries are emitted at all."
        ),
    )

    parser.add_argument(
        "--post-trade-gateway",
        action="store_true",
        help="Emit a top-level post_trade_gateway section for pm-ralf-gwy.",
    )
    parser.add_argument(
        "--post-trade-name",
        default=None,
        metavar="NAME",
        help="post_trade_gateway.name override.",
    )
    parser.add_argument(
        "--post-trade-bind-address",
        default=None,
        metavar="ADDR",
        help="post_trade_gateway.bind_address override.",
    )
    parser.add_argument(
        "--post-trade-port",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.port override (> 0).",
    )
    parser.add_argument(
        "--post-trade-replay-retention-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.replay_retention_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--post-trade-allowed-roles",
        nargs="+",
        default=None,
        metavar="ROLE",
        help="post_trade_gateway.allowed_roles override (default: CLEARING DROP_COPY AUDIT).",
    )

    parser.add_argument(
        "--market-data-gateway",
        action="store_true",
        help="Emit a top-level market_data_gateway section for pm-md-gwy.",
    )
    parser.add_argument(
        "--market-data-enabled",
        dest="market_data_enabled",
        action="store_true",
        default=None,
        help="Set market_data_gateway.enabled: true.",
    )
    parser.add_argument(
        "--market-data-disabled",
        dest="market_data_enabled",
        action="store_false",
        default=None,
        help="Set market_data_gateway.enabled: false.",
    )
    parser.add_argument(
        "--market-data-name",
        default=None,
        metavar="NAME",
        help="market_data_gateway.name override.",
    )
    parser.add_argument(
        "--market-data-bind-address",
        default=None,
        metavar="ADDR",
        help="market_data_gateway.bind_address override.",
    )
    parser.add_argument(
        "--market-data-port",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.port override (> 0).",
    )
    parser.add_argument(
        "--market-data-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-replay-window-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.replay_window_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-max-symbols-per-client",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.max_symbols_per_client override (> 0).",
    )
    parser.add_argument(
        "--market-data-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--market-data-depth-levels",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.depth_levels override (> 0).",
    )

    parser.add_argument(
        "--api-gateway",
        action="store_true",
        help="Emit a top-level api_gateways section for pm-api-gwy.",
    )
    parser.add_argument(
        "--api-gateway-name",
        default="default",
        metavar="NAME",
        help="Name for the generated api_gateways entry when using a single API gateway.",
    )
    parser.add_argument(
        "--api-gateway-instance",
        action="append",
        default=[],
        metavar="NAME:GATEWAY[,GATEWAY...][:PORT]",
        help=(
            "Repeatable named API gateway process. Generates credentials only for "
            "the listed gateway IDs and optionally overrides port. Use NAME::PORT "
            "for an identity-free read-only gateway."
        ),
    )
    parser.add_argument(
        "--api-gateway-enabled",
        dest="api_gateway_enabled",
        action="store_true",
        default=None,
        help="Set api_gateway.enabled: true.",
    )
    parser.add_argument(
        "--api-gateway-disabled",
        dest="api_gateway_enabled",
        action="store_false",
        default=None,
        help="Set api_gateway.enabled: false.",
    )
    parser.add_argument(
        "--api-gateway-host",
        default=None,
        metavar="ADDR",
        help="api_gateway.host override.",
    )
    parser.add_argument(
        "--api-gateway-port",
        type=int,
        default=None,
        metavar="N",
        help="api_gateway.port override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-swagger-enabled",
        dest="api_gateway_swagger_enabled",
        action="store_true",
        default=None,
        help="Set api_gateway.swagger_enabled: true.",
    )
    parser.add_argument(
        "--api-gateway-swagger-disabled",
        dest="api_gateway_swagger_enabled",
        action="store_false",
        default=None,
        help="Set api_gateway.swagger_enabled: false.",
    )
    parser.add_argument(
        "--api-gateway-log-level",
        default=None,
        choices=["debug", "info", "warning", "error"],
        help="api_gateway.log_level override.",
    )
    parser.add_argument(
        "--api-gateway-stats-db",
        default=None,
        metavar="PATH",
        help="api_gateway.stats_db override.",
    )
    parser.add_argument(
        "--api-key",
        action="append",
        default=[],
        metavar="KEY:GATEWAY_ID[:DESCRIPTION]",
        help=(
            "Explicit api_gateways credential for single-instance generation. Use GATEWAY_ID=null for a read-only "
            "market-data key. Can be repeated."
        ),
    )
    api_key_group = parser.add_mutually_exclusive_group()
    api_key_group.add_argument(
        "--api-gateway-generate-keys",
        dest="api_gateway_generate_keys",
        action="store_true",
        default=None,
        help="Generate one API key for each configured ALF gateway when api_gateway is emitted.",
    )
    api_key_group.add_argument(
        "--no-api-gateway-generate-keys",
        dest="api_gateway_generate_keys",
        action="store_false",
        default=None,
        help="Do not auto-generate API keys for ALF gateways.",
    )
    parser.add_argument(
        "--api-gateway-readonly-key",
        action="store_true",
        help="Generate an additional read-only API key with gateway_id: null.",
    )
    parser.add_argument(
        "--api-gateway-rate-limit-writes-per-second",
        type=int,
        default=None,
        metavar="N",
        help="api_gateway.rate_limit.writes_per_second override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-rate-limit-burst",
        type=int,
        default=None,
        metavar="N",
        help="api_gateway.rate_limit.burst override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-engine-auth-sec",
        type=float,
        default=None,
        metavar="SECS",
        help="api_gateway.timeouts.engine_auth_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-engine-reply-sec",
        type=float,
        default=None,
        metavar="SECS",
        help="api_gateway.timeouts.engine_reply_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-wait-ack-sec",
        type=float,
        default=None,
        metavar="SECS",
        help="api_gateway.timeouts.wait_ack_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-order-retention-sec",
        type=int,
        default=None,
        metavar="SECS",
        help=(
            "api_gateway.order_retention_sec override (>= 0). Seconds a "
            "terminal order stays in the gateway's in-memory cache. 0 "
            "disables eviction."
        ),
    )

    # ── BALF gateway ──────────────────────────────────────────────────────────
    parser.add_argument(
        "--balf-gateway",
        action="store_true",
        help="Emit a top-level balf_gateway section for pm-balf-gwy.",
    )
    parser.add_argument(
        "--balf-name",
        default=None,
        metavar="NAME",
        help="balf_gateway.name override.",
    )
    parser.add_argument(
        "--balf-bind-address",
        default=None,
        metavar="ADDR",
        help="balf_gateway.bind_address override.",
    )
    parser.add_argument(
        "--balf-port",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.port override (> 0).",
    )
    parser.add_argument(
        "--balf-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-heartbeat-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.heartbeat_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-auth-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.auth_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--balf-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--balf-max-messages-per-second",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_messages_per_second override (> 0).",
    )
    parser.add_argument(
        "--balf-max-errors-before-disconnect",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_errors_before_disconnect override (> 0).",
    )
    parser.add_argument(
        "--balf-error-window-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.error_window_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-duplicate-session-policy",
        default=None,
        choices=["REJECT_NEW", "EVICT_OLD"],
        help="balf_gateway.duplicate_session_policy override.",
    )

    parser.add_argument(
        "--dc-gateway",
        action="store_true",
        help="Emit a top-level dc_gateway section for pm-dc-gwy.",
    )
    parser.add_argument(
        "--dc-name",
        default=None,
        metavar="NAME",
        help="dc_gateway.name override.",
    )
    parser.add_argument(
        "--dc-bind-address",
        default=None,
        metavar="ADDR",
        help="dc_gateway.bind_address override.",
    )
    parser.add_argument(
        "--dc-port",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.port override (> 0).",
    )
    parser.add_argument(
        "--dc-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--dc-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--dc-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.max_client_queue override (> 0).",
    )

    parser.add_argument(
        "--log-server",
        action="store_true",
        help="Emit a top-level log_server section for pm-log-srv.",
    )
    parser.add_argument(
        "--log-server-enabled",
        dest="log_server_enabled",
        action="store_true",
        default=None,
        help="Set log_server.enabled: true.",
    )
    parser.add_argument(
        "--log-server-disabled",
        dest="log_server_enabled",
        action="store_false",
        default=None,
        help="Set log_server.enabled: false.",
    )
    parser.add_argument(
        "--log-server-name",
        default=None,
        metavar="NAME",
        help="log_server.name override.",
    )
    parser.add_argument(
        "--log-server-bind-address",
        default=None,
        metavar="ADDR",
        help="log_server.bind_address override.",
    )
    parser.add_argument(
        "--log-server-port",
        type=int,
        default=None,
        metavar="N",
        help="log_server.port override (> 0).",
    )
    parser.add_argument(
        "--log-server-db-path",
        default=None,
        metavar="PATH",
        help="log_server.db_path override.",
    )
    parser.add_argument(
        "--log-server-retention-days",
        type=int,
        default=None,
        metavar="N",
        help=(
            "log_server.retention_days override (>= 0; 0 means unbounded "
            "retention, same as omitting the field with retention disabled)."
        ),
    )
    parser.add_argument(
        "--log-server-max-message-bytes",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_message_bytes override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--log-server-write-batch-size",
        type=int,
        default=None,
        metavar="N",
        help="log_server.write_batch_size override (> 0).",
    )
    parser.add_argument(
        "--log-server-write-batch-interval-ms",
        type=int,
        default=None,
        metavar="N",
        help="log_server.write_batch_interval_ms override (> 0).",
    )
    parser.add_argument(
        "--log-server-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="log_server.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--log-server-pubsub-enabled",
        dest="log_server_pubsub_enabled",
        action="store_true",
        default=None,
        help="Set log_server.pubsub_enabled: true (LALF-PS log distribution).",
    )
    parser.add_argument(
        "--log-server-pubsub-disabled",
        dest="log_server_pubsub_enabled",
        action="store_false",
        default=None,
        help="Set log_server.pubsub_enabled: false (bind no ZeroMQ sockets).",
    )
    parser.add_argument(
        "--log-server-pub-port",
        type=int,
        default=None,
        metavar="N",
        help="log_server.pub_port override — LALF-PS ZeroMQ PUB port (> 0).",
    )
    parser.add_argument(
        "--log-server-pull-port",
        type=int,
        default=None,
        metavar="N",
        help="log_server.pull_port override — LALF-PS ZeroMQ PULL port (> 0).",
    )
    parser.add_argument(
        "--log-server-lease-sec",
        type=int,
        default=None,
        metavar="N",
        help=(
            "log_server.lease_sec override (> 0) — subscription lease TTL; a "
            "subscriber that stops renewing is reaped after this long."
        ),
    )
    parser.add_argument(
        "--log-server-max-lease-sec",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_lease_sec override (>= lease_sec).",
    )
    parser.add_argument(
        "--log-server-max-subscribers",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_subscribers override (> 0).",
    )
    parser.add_argument(
        "--log-server-notify-interval-ms",
        type=int,
        default=None,
        metavar="N",
        help="log_server.notify_interval_ms override (> 0).",
    )
    parser.add_argument(
        "--log-server-backfill-chunk-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.backfill_chunk_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-backfill-minutes",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_backfill_minutes override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-backfill-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_backfill_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-pending-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_pending_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-pub-sndhwm",
        type=int,
        default=None,
        metavar="N",
        help="log_server.pub_sndhwm override (> 0).",
    )

    sched_group = parser.add_mutually_exclusive_group()
    sched_group.add_argument(
        "--schedule",
        dest="schedule",
        action="store_true",
        default=None,
        help="Force emit schedule section.",
    )
    sched_group.add_argument(
        "--no-schedule",
        dest="schedule",
        action="store_false",
        default=None,
        help="Suppress schedule section.",
    )

    parser.add_argument(
        "--pre-open", default=DEFAULT_SCHEDULE["pre_open"], metavar="HH:MM"
    )
    parser.add_argument(
        "--opening-auction",
        default=DEFAULT_SCHEDULE["opening_auction_start"],
        metavar="HH:MM",
    )
    parser.add_argument(
        "--continuous",
        default=DEFAULT_SCHEDULE["continuous_start"],
        metavar="HH:MM",
    )
    parser.add_argument(
        "--closing-auction",
        default=DEFAULT_SCHEDULE["closing_auction_start"],
        metavar="HH:MM",
    )
    parser.add_argument(
        "--closing-end",
        default=DEFAULT_SCHEDULE["closing_auction_end"],
        metavar="HH:MM",
    )

    parser.add_argument(
        "--country",
        type=str,
        default=None,
        metavar="COUNTRY",
        help=(
            "Country pm-scheduler uses for its bank-holiday/weekend calendar "
            '(name, e.g. "Sweden", or ISO 3166-1 alpha-2 code, e.g. "SE"). '
            'Defaults to "Sweden" when omitted.'
        ),
    )

    parser.add_argument(
        "--index",
        action="append",
        default=[],
        metavar="ID[:DESCRIPTION]",
        help=(
            "Define an index (repeatable, up to 5). "
            "ID is alphanumeric; DESCRIPTION is optional text after the first colon."
        ),
    )
    parser.add_argument(
        "--index-constituents",
        action="append",
        default=[],
        metavar="ID:SYM[,SYM,...]",
        help="Constituent symbols for an index. Can be repeated.",
    )
    parser.add_argument(
        "--index-base-value",
        action="append",
        default=[],
        metavar="ID:VALUE",
        help="Override base_value for an index (default: 1000.0). Can be repeated.",
    )
    parser.add_argument(
        "--index-interval",
        action="append",
        default=[],
        metavar="ID:SECS",
        help="Override publish_interval_sec for an index (default: 1.0). Can be repeated.",
    )
    parser.add_argument(
        "--index-history-file",
        action="append",
        default=[],
        metavar="ID:PATH",
        help="Override history_file path for an index. Can be repeated.",
    )
    parser.add_argument(
        "--index-state-file",
        action="append",
        default=[],
        metavar="ID:PATH",
        help="Override state_file path for an index. Can be repeated.",
    )

    parser.add_argument(
        "--combo",
        action="append",
        default=[],
        metavar="COMBO_SPEC",
        help=(
            "Seed a market-maker combo order: ID:TYPE:TIF:SYM/SIDE/TYPE/QTY[/PRICE[/STOP[/SMP]]],...\n"
            "PRICE and STOP accept either a raw integer tick count (e.g. 20950) or a\n"
            "decimal display price (e.g. 209.50), converted using the symbol's tick_decimals.\n"
            "Example: SEED-PAIR:AON:DAY:AAPL/BUY/LIMIT/100/209.50,MSFT/SELL/LIMIT/50/415.50\n"
            "Can be repeated."
        ),
    )

    parser.add_argument(
        "--output", default=None, metavar="FILE", help="Output file path."
    )
    parser.add_argument(
        "--force", action="store_true", help="Overwrite existing output file."
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Print only, do not write."
    )
    parser.add_argument(
        "--comment-default-config-fields",
        action="store_true",
        help=(
            "Add a header comment block listing defaultable engine_config fields "
            "and their default values."
        ),
    )

    return parser
