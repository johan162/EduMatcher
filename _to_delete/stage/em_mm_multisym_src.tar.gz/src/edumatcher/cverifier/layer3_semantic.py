"""Layer 3 — Semantic / cross-field consistency checks (M001–M026).

This layer works directly on the raw YAML mapping so that every problem is
reported independently, even when several fields are wrong at once.  It does
not build the typed EngineConfig: the CLI only runs this layer once Layer 2
reports zero schema errors, so the raw values are already well-formed enough
to reason about.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import holidays

from edumatcher.cverifier.helpers import (
    all_gateway_ids,
    gateway_ids_by_role,
    symbol_cfg_by_upper_name,
)
from edumatcher.cverifier.models import CheckResult, Severity
from edumatcher.gateway_ports import (
    DEFAULT_API_GATEWAY_PORT,
    LOG_SERVER_EXTRA_PORTS,
    SINGLETON_GATEWAYS,
    effective_port,
)
from edumatcher.models.session import VALID_TRANSITIONS, SessionState

_TIME_FIELDS = (
    "pre_open",
    "opening_auction_start",
    "continuous_start",
    "closing_auction_start",
    "closing_auction_end",
)

# Schedule field -> the session state it transitions the engine into. Mirrors
# edumatcher.scheduler.main._load_schedule's mapping, so the chain check below
# validates the same path the scheduler will actually drive at runtime.
_FIELD_TO_STATE: dict[str, SessionState] = {
    "pre_open": SessionState.PRE_OPEN,
    "opening_auction_start": SessionState.OPENING_AUCTION,
    "continuous_start": SessionState.CONTINUOUS,
    "closing_auction_start": SessionState.CLOSING_AUCTION,
    "closing_auction_end": SessionState.CLOSED,
}


def check(raw: dict[str, Any], path: Path) -> list[CheckResult]:  # noqa: ARG001
    """Run Layer 3 semantic checks."""
    results: list[CheckResult] = []
    _check_mm_obligation_symbols(raw, results)
    _check_mm_seeds(raw, results)
    _check_sessions_schedule(raw, results)
    _check_country(raw, results)
    _check_enforce_flags(raw, results)
    _check_indices(raw, results)
    _check_combos(raw, results)
    _check_admin_gateway(raw, results)
    _check_post_trade_admin(raw, results)
    _check_balf_gateway_semantic(raw, results)
    _check_gateway_port_collisions(raw, results)
    _check_api_gateway_semantic(raw, results)
    return results


# ---------------------------------------------------------------------------
# MM seed checks
# ---------------------------------------------------------------------------


def _check_mm_seeds(raw: dict[str, Any], results: list[CheckResult]) -> None:
    mm_gateways = gateway_ids_by_role(raw, "MARKET_MAKER")
    all_ids = all_gateway_ids(raw)
    require_mm_seed_quotes = bool(raw.get("require_mm_seed_quotes", True))
    gateways_by_role: dict[str, str] = {}
    gateways = raw.get("gateways")
    if isinstance(gateways, dict):
        alf = gateways.get("alf")
        if isinstance(alf, list):
            for gw in alf:
                if not isinstance(gw, dict):
                    continue
                gw_id = gw.get("id")
                if not isinstance(gw_id, str) or not gw_id.strip():
                    continue
                gateways_by_role[gw_id.strip().upper()] = str(
                    gw.get("role", "TRADER")
                ).upper()

    symbols = raw.get("symbols", {})
    if not isinstance(symbols, dict):
        return

    # M003 only applies when MM obligations are actually configured.
    mm_obligation_defaults = raw.get("mm_obligation_defaults")
    mm_max_spread: int | None = None
    if isinstance(mm_obligation_defaults, dict) and mm_obligation_defaults:
        try:
            mm_max_spread = int(mm_obligation_defaults.get("mm_max_spread_ticks", 10))
        except (TypeError, ValueError):
            mm_max_spread = 10

    for sym_raw, cfg in symbols.items():
        sym = str(sym_raw).upper()
        if not isinstance(cfg, dict):
            cfg = {}

        mm_quotes = cfg.get("market_maker_quotes") or []
        if not isinstance(mm_quotes, list):
            mm_quotes = []

        # M001: MM gateway present but symbol has no seeds
        if mm_gateways and require_mm_seed_quotes and not mm_quotes:
            gw_list = ", ".join(mm_gateways)
            results.append(
                CheckResult(
                    code="M001",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}' has no market_maker_quotes entry for "
                        f"MARKET_MAKER gateway(s) {gw_list}."
                    ),
                    suggestion=(
                        "Add a bid/ask seed quote or the engine will reject startup. "
                        "Run pm-config-gen with --seed-mm to generate placeholder seeds."
                    ),
                    path=f"symbols.{sym}.market_maker_quotes",
                )
            )

        for i, quote in enumerate(mm_quotes):
            if not isinstance(quote, dict):
                continue

            gw_id_raw = quote.get("gateway_id")
            if gw_id_raw:
                gw_id = str(gw_id_raw).strip().upper()
                # M002: seed references unknown gateway
                if gw_id not in all_ids:
                    results.append(
                        CheckResult(
                            code="M002",
                            severity=Severity.ERROR,
                            message=(
                                f"Symbol '{sym}': market_maker_quotes gateway_id "
                                f"'{gw_id}' is not listed in gateways.alf."
                            ),
                            suggestion=(
                                "Either add the gateway or remove the seed entry."
                            ),
                            path=f"symbols.{sym}.market_maker_quotes[{i}].gateway_id",
                        )
                    )
                elif gw_id not in mm_gateways:
                    role = gateways_by_role.get(gw_id, "TRADER")
                    results.append(
                        CheckResult(
                            code="M020",
                            severity=Severity.ERROR,
                            message=(
                                f"Symbol '{sym}': market_maker_quotes gateway_id "
                                f"'{gw_id}' has role {role}, not MARKET_MAKER."
                            ),
                            suggestion=(
                                "Point this quote seed to a MARKET_MAKER gateway or "
                                "change the gateway role to MARKET_MAKER."
                            ),
                            path=f"symbols.{sym}.market_maker_quotes[{i}].gateway_id",
                        )
                    )

            # M003: spread exceeds MM max spread ticks
            if mm_max_spread is not None:
                bid = quote.get("bid_price")
                ask = quote.get("ask_price")
                tick_decimals = cfg.get("tick_decimals", 2)
                if bid is not None and ask is not None:
                    try:
                        spread_price = float(ask) - float(bid)
                        tick_size = 10 ** (-int(tick_decimals))
                        spread_ticks = round(spread_price / tick_size)
                        if spread_ticks > mm_max_spread:
                            results.append(
                                CheckResult(
                                    code="M003",
                                    severity=Severity.WARN,
                                    message=(
                                        f"Symbol '{sym}': market_maker_quotes[{i}] spread "
                                        f"({spread_ticks} ticks) exceeds mm_max_spread_ticks "
                                        f"({mm_max_spread})."
                                    ),
                                    suggestion=(
                                        "The seed quote would be immediately rejected. "
                                        "Narrow the spread or raise mm_max_spread_ticks."
                                    ),
                                    path=f"symbols.{sym}.market_maker_quotes[{i}]",
                                )
                            )
                    except (TypeError, ValueError):
                        pass


def _check_mm_obligation_symbols(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    symbols = symbol_cfg_by_upper_name(raw)
    mm_defaults = raw.get("mm_obligation_defaults")
    if not isinstance(mm_defaults, dict):
        return
    sym_overrides = mm_defaults.get("symbols")
    if not isinstance(sym_overrides, dict):
        return

    for sym_raw in sym_overrides:
        sym = str(sym_raw).upper()
        if sym not in symbols:
            results.append(
                CheckResult(
                    code="M019",
                    severity=Severity.ERROR,
                    message=(
                        "mm_obligation_defaults.symbols references unknown symbol "
                        f"'{sym}'."
                    ),
                    suggestion=(
                        f"Add symbol '{sym}' under symbols, or remove the override entry."
                    ),
                    path=f"mm_obligation_defaults.symbols.{sym}",
                )
            )


# ---------------------------------------------------------------------------
# Sessions / schedule
# ---------------------------------------------------------------------------


def _check_sessions_schedule(raw: dict[str, Any], results: list[CheckResult]) -> None:
    sessions_enabled = bool(raw.get("sessions_enabled", False))
    schedule = raw.get("schedule")

    # M004: sessions enabled but no schedule
    if sessions_enabled and not isinstance(schedule, dict):
        results.append(
            CheckResult(
                code="M004",
                severity=Severity.ERROR,
                message=(
                    "sessions_enabled is true but no schedule is defined. "
                    "The engine will wait indefinitely in CLOSED state."
                ),
                suggestion=("Add a schedule section or set sessions_enabled: false."),
                path="schedule",
            )
        )

    # M005: sessions disabled but schedule present
    if not sessions_enabled and isinstance(schedule, dict):
        results.append(
            CheckResult(
                code="M005",
                severity=Severity.WARN,
                message=(
                    "A schedule section is present but sessions_enabled is false. "
                    "The schedule will be ignored."
                ),
                suggestion=(
                    "Set sessions_enabled: true or remove the schedule section."
                ),
                path="sessions_enabled",
            )
        )

    if isinstance(schedule, dict):
        # M021/M023: values must be quoted "HH:MM" strings, not unquoted
        # times that YAML mis-parses as sexagesimal integers.
        _check_schedule_value_types(schedule, results)
        # M006: schedule times out of order
        _check_schedule_order(schedule, results)
        if sessions_enabled:
            # M024: schedule must define every phase
            _check_schedule_completeness(schedule, results)
            # M025: present phases must form a legal transition chain from CLOSED
            _check_schedule_chain(schedule, results)


# ---------------------------------------------------------------------------
# country
# ---------------------------------------------------------------------------


def _check_country(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Flag a ``country`` value pm-scheduler's holiday calendar won't recognise.

    Layer 2 (S065) already rejects a non-string/blank ``country``; this check
    is semantic because it needs the ``python-holidays`` package to know
    which strings are valid calendars. Severity is WARN, not ERROR, because
    pm-scheduler itself does not fail on an unrecognised country — it logs a
    warning and falls back to the default (Sweden) rather than crashing, so a
    config with a typo here is degraded, not broken.
    """
    country = raw.get("country")
    if not isinstance(country, str) or not country.strip():
        return  # not a string / blank — Layer 2 (S065) already reports this

    try:
        holidays.country_holidays(country)
    except NotImplementedError:
        results.append(
            CheckResult(
                code="M026",
                severity=Severity.WARN,
                message=(
                    f"'country' value '{country}' is not recognised by the "
                    "holidays package. pm-scheduler will fall back to Sweden "
                    "at runtime."
                ),
                suggestion=(
                    'Set country to a country name (e.g. "Sweden") or an '
                    'ISO 3166-1 alpha-2 code (e.g. "SE").'
                ),
                path="country",
            )
        )


def _parse_hhmm(t: Any) -> int | None:
    """Return minutes since midnight or None on parse error."""
    if not isinstance(t, str):
        return None
    parts = t.strip().split(":")
    if len(parts) != 2:
        return None
    try:
        h, m = int(parts[0]), int(parts[1])
        if 0 <= h <= 23 and 0 <= m <= 59:
            return h * 60 + m
    except ValueError:
        pass
    return None


def _check_schedule_order(schedule: dict[str, Any], results: list[CheckResult]) -> None:
    times = []
    for field in _TIME_FIELDS:
        val = schedule.get(field)
        t = _parse_hhmm(val)
        if t is not None:
            times.append((field, t, str(val)))

    for i in range(len(times) - 1):
        name_a, t_a, v_a = times[i]
        name_b, t_b, v_b = times[i + 1]
        if t_a >= t_b:
            results.append(
                CheckResult(
                    code="M006",
                    severity=Severity.WARN,
                    message=(
                        f"Schedule times are out of order: "
                        f"{name_a}={v_a} >= {name_b}={v_b}."
                    ),
                    suggestion=(
                        "Expected order: pre_open < opening_auction_start < "
                        "continuous_start < closing_auction_start < closing_auction_end."
                    ),
                    path="schedule",
                )
            )


def _check_schedule_value_types(
    schedule: dict[str, Any], results: list[CheckResult]
) -> None:
    """Flag schedule time values that are not valid quoted ``"HH:MM"`` strings.

    PyYAML (YAML 1.1) parses an unquoted ``09:30`` as the base-60 integer 570
    (sexagesimal), not the string ``"09:30"``. That value silently fails
    string-based time parsing downstream, so flag it explicitly instead of
    letting it disappear from ordering/chain checks with no diagnostic.
    """
    for field in _TIME_FIELDS:
        if field not in schedule:
            continue
        val = schedule[field]
        if val is None:
            continue
        if isinstance(val, str):
            if _parse_hhmm(val) is None:
                results.append(
                    CheckResult(
                        code="M023",
                        severity=Severity.ERROR,
                        message=(
                            f"'schedule.{field}' value '{val}' is not a valid "
                            '24-hour "HH:MM" time.'
                        ),
                        suggestion=(
                            f"Use a zero-padded 24-hour time, e.g. {field}: '09:30'."
                        ),
                        path=f"schedule.{field}",
                    )
                )
            continue

        if isinstance(val, int) and not isinstance(val, bool) and 0 <= val < 24 * 60:
            suggestion = (
                f"Quote the value, e.g. {field}: '{val // 60:02d}:{val % 60:02d}'."
            )
            detail = (
                f"'schedule.{field}' is {val!r} — an unquoted time that YAML parsed "
                "as a base-60 integer (sexagesimal) instead of a string."
            )
        else:
            suggestion = f"Set {field} to a quoted 24-hour time, e.g. '09:30'."
            detail = (
                f"'schedule.{field}' must be a quoted \"HH:MM\" string. Got {val!r}."
            )

        results.append(
            CheckResult(
                code="M021",
                severity=Severity.ERROR,
                message=detail,
                suggestion=suggestion,
                path=f"schedule.{field}",
            )
        )


def _check_schedule_completeness(
    schedule: dict[str, Any], results: list[CheckResult]
) -> None:
    """M024: sessions_enabled requires all five schedule phases to be set.

    A partial schedule sends the engine an out-of-sequence transition (e.g.
    ``CONTINUOUS`` first), which it rejects since session transitions are
    sequential and dependent.
    """
    missing = [f for f in _TIME_FIELDS if schedule.get(f) is None]
    if missing:
        results.append(
            CheckResult(
                code="M024",
                severity=Severity.ERROR,
                message=(
                    "sessions_enabled is true but 'schedule' is missing: "
                    f"{', '.join(missing)}. Engine session transitions are "
                    "sequential, so a partial schedule will be rejected at "
                    "runtime once it reaches the missing phase."
                ),
                suggestion=(
                    "Add the missing schedule field(s), or set "
                    "sessions_enabled: false if partial scheduling is intended."
                ),
                path="schedule",
            )
        )


def _check_schedule_chain(schedule: dict[str, Any], results: list[CheckResult]) -> None:
    """M025: present schedule phases must form a legal path through
    ``VALID_TRANSITIONS``, starting from the engine's boot state (CLOSED).

    Mirrors ``edumatcher.scheduler.main._validate_schedule`` so a schedule
    that would desync the engine is caught statically, not just at scheduler
    runtime.
    """
    prev_state = SessionState.CLOSED
    for field in _TIME_FIELDS:
        val = schedule.get(field)
        if not isinstance(val, str) or _parse_hhmm(val) is None:
            # Not a well-formed entry; already reported by
            # _check_schedule_value_types. Skip it here so one bad value
            # doesn't cascade into spurious chain errors.
            continue
        state = _FIELD_TO_STATE[field]
        if state not in VALID_TRANSITIONS.get(prev_state, set()):
            results.append(
                CheckResult(
                    code="M025",
                    severity=Severity.ERROR,
                    message=(
                        f"Schedule transition {prev_state.value} -> {state.value} "
                        f"(schedule.{field}) is not a legal transition. The engine "
                        "will reject it and remain in its current state."
                    ),
                    suggestion=(
                        "A schedule must be a valid path through the session "
                        "lifecycle starting from CLOSED: CLOSED -> PRE_OPEN -> "
                        "OPENING_AUCTION -> CONTINUOUS -> CLOSING_AUCTION -> "
                        f"CLOSED. Add the missing intermediate phase, or remove "
                        f"schedule.{field}."
                    ),
                    path=f"schedule.{field}",
                )
            )
        prev_state = state


# ---------------------------------------------------------------------------
# Enforce flags
# ---------------------------------------------------------------------------


def _check_enforce_flags(raw: dict[str, Any], results: list[CheckResult]) -> None:
    enforce_collars = raw.get("enforce_collars", True)
    enforce_cb = raw.get("enforce_circuit_breakers", True)

    rc = raw.get("risk_controls", {})
    has_collar_levels = False
    if isinstance(rc, dict):
        levels = rc.get("levels", {})
        if isinstance(levels, dict):
            for level_cfg in levels.values():
                if isinstance(level_cfg, dict) and level_cfg.get("collar"):
                    has_collar_levels = True
                    break

    # M007: enforce_collars=false but collars configured
    if not enforce_collars and has_collar_levels:
        results.append(
            CheckResult(
                code="M007",
                severity=Severity.WARN,
                message=(
                    "enforce_collars is false but risk_controls defines collar levels. "
                    "Collars are configured but inactive."
                ),
                suggestion=(
                    "Set enforce_collars: true to activate them, or remove the "
                    "risk_controls.levels collar entries."
                ),
                path="enforce_collars",
            )
        )

    cb_defaults = raw.get("circuit_breaker_defaults")
    has_cb_levels = isinstance(cb_defaults, dict) and bool(cb_defaults.get("levels"))

    # M008: enforce_circuit_breakers=false but CB configured
    if not enforce_cb and has_cb_levels:
        results.append(
            CheckResult(
                code="M008",
                severity=Severity.WARN,
                message=(
                    "enforce_circuit_breakers is false but circuit_breaker_defaults "
                    "defines levels. Circuit breakers are configured but inactive."
                ),
                suggestion="Set enforce_circuit_breakers: true to activate them.",
                path="enforce_circuit_breakers",
            )
        )


# ---------------------------------------------------------------------------
# Index checks
# ---------------------------------------------------------------------------


def _get_symbol_names(raw: dict[str, Any]) -> set[str]:
    return set(symbol_cfg_by_upper_name(raw))


def _check_indices(raw: dict[str, Any], results: list[CheckResult]) -> None:
    indices = raw.get("indices")
    if indices is None:
        return
    if not isinstance(indices, list):
        return

    symbol_cfgs = symbol_cfg_by_upper_name(raw)
    symbol_names = set(symbol_cfgs)

    # M011: more than 5 indices
    if len(indices) > 5:
        excess = len(indices) - 5
        results.append(
            CheckResult(
                code="M011",
                severity=Severity.ERROR,
                message=(
                    f"{len(indices)} indices are defined but only 5 are supported."
                ),
                suggestion=f"Remove {excess} index entries.",
                path="indices",
            )
        )

    for idx in indices:
        if not isinstance(idx, dict):
            continue
        idx_id = str(idx.get("id", "?"))
        constituents = idx.get("constituents") or []
        if not isinstance(constituents, list):
            continue
        for sym_raw in constituents:
            sym = str(sym_raw).upper()
            # M009: constituent not in symbols
            if sym not in symbol_names:
                results.append(
                    CheckResult(
                        code="M009",
                        severity=Severity.ERROR,
                        message=(
                            f"Index '{idx_id}': constituent '{sym}' is not listed "
                            "in the symbols section."
                        ),
                        suggestion=(
                            f"Add '{sym}' to symbols or remove it from the index constituents."
                        ),
                        path=f"indices[id={idx_id}].constituents",
                    )
                )
            else:
                sym_cfg = symbol_cfgs.get(sym, {})
                if sym_cfg.get("outstanding_shares") is None:
                    results.append(
                        CheckResult(
                            code="M010",
                            severity=Severity.ERROR,
                            message=(
                                f"Index '{idx_id}': constituent '{sym}' has no outstanding_shares."
                            ),
                            suggestion=(
                                "This field is required for cap-weighted index calculation. "
                                f"Add outstanding_shares to symbol '{sym}'."
                            ),
                            path=f"symbols.{sym}.outstanding_shares",
                        )
                    )


# ---------------------------------------------------------------------------
# Combo checks
# ---------------------------------------------------------------------------


def _check_combos(raw: dict[str, Any], results: list[CheckResult]) -> None:
    combos = raw.get("market_maker_combos")
    if not isinstance(combos, list):
        return

    symbol_names = _get_symbol_names(raw)

    for n, combo in enumerate(combos):
        if not isinstance(combo, dict):
            continue

        # M012: GTC tif
        tif = combo.get("tif", "DAY")
        if str(tif).upper() == "GTC":
            results.append(
                CheckResult(
                    code="M012",
                    severity=Severity.WARN,
                    message=(f"market_maker_combos[{n}] uses tif: GTC."),
                    suggestion=(
                        "On engine restart, GTC combo seeds may collide with persisted "
                        "orders from a previous session. Use tif: DAY unless you explicitly "
                        "manage persisted state."
                    ),
                    path=f"market_maker_combos[{n}].tif",
                )
            )

        legs = combo.get("legs") or []
        if not isinstance(legs, list):
            continue
        for j, leg in enumerate(legs):
            if not isinstance(leg, dict):
                continue
            leg_sym = leg.get("symbol")
            if leg_sym is not None and str(leg_sym).upper() not in symbol_names:
                results.append(
                    CheckResult(
                        code="M015",
                        severity=Severity.ERROR,
                        message=(
                            f"market_maker_combos[{n}].legs[{j}]: symbol "
                            f"'{leg_sym}' is not listed in the symbols section."
                        ),
                        suggestion=(
                            "Add the symbol to the symbols section or correct the combo leg."
                        ),
                        path=f"market_maker_combos[{n}].legs[{j}].symbol",
                    )
                )


# ---------------------------------------------------------------------------
# Admin gateway
# ---------------------------------------------------------------------------


def _check_admin_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    admin_gateways = gateway_ids_by_role(raw, "ADMIN")
    if not admin_gateways:
        results.append(
            CheckResult(
                code="M013",
                severity=Severity.WARN,
                message="No gateway has role: ADMIN.",
                suggestion=(
                    "Without an admin gateway, halt, resume, kill-switch, and emergency "
                    "commands cannot be issued at runtime. Add a gateway with role: ADMIN:\n"
                    "    - id: OPS01\n"
                    "      role: ADMIN\n"
                    "      disconnect_behaviour: LEAVE_ALL"
                ),
                path="gateways.alf",
            )
        )

    # C010: LEAVE_ALL on non-ADMIN gateways
    gateways = raw.get("gateways", {})
    if not isinstance(gateways, dict):
        return
    alf = gateways.get("alf", [])
    if not isinstance(alf, list):
        return
    for n, gw in enumerate(alf):
        if not isinstance(gw, dict):
            continue
        role = str(gw.get("role", "TRADER")).upper()
        disconnect = str(gw.get("disconnect_behaviour", "")).upper()
        gw_id = str(gw.get("id", "?"))
        if disconnect == "LEAVE_ALL" and role != "ADMIN":
            results.append(
                CheckResult(
                    code="C010",
                    severity=Severity.WARN,
                    message=(
                        f"Gateway '{gw_id}' has disconnect_behaviour: LEAVE_ALL but "
                        f"role {role}."
                    ),
                    suggestion=(
                        "LEAVE_ALL is typically reserved for ADMIN gateways. "
                        "TRADER and MARKET_MAKER gateways usually use CANCEL_ALL "
                        "or CANCEL_QUOTES_ONLY to prevent stale orders after disconnection."
                    ),
                    path=f"gateways.alf[{n}].disconnect_behaviour",
                )
            )


def _check_post_trade_admin(raw: dict[str, Any], results: list[CheckResult]) -> None:
    post_trade = raw.get("post_trade_gateway")
    if post_trade is None:
        return
    admin_gateways = gateway_ids_by_role(raw, "ADMIN")
    if not admin_gateways:
        results.append(
            CheckResult(
                code="M016",
                severity=Severity.WARN,
                message=(
                    "post_trade_gateway is configured but no ADMIN gateway exists."
                ),
                suggestion=(
                    "RALF admin commands (replay, etc.) will be unavailable. "
                    "Add a gateway with role: ADMIN."
                ),
                path="post_trade_gateway",
            )
        )


def _check_balf_gateway_semantic(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    """Semantic cross-field checks for the balf_gateway section (M017)."""
    section = raw.get("balf_gateway")
    if section is None or not isinstance(section, dict):
        return

    # M017 — heartbeat timeout should exceed heartbeat interval
    interval_raw = section.get("heartbeat_interval_sec")
    timeout_raw = section.get("heartbeat_timeout_sec")
    if interval_raw is not None and timeout_raw is not None:
        try:
            f_interval = float(interval_raw)
            f_timeout = float(timeout_raw)
            if f_timeout <= f_interval:
                results.append(
                    CheckResult(
                        code="M017",
                        severity=Severity.WARN,
                        message=(
                            f"balf_gateway.heartbeat_timeout_sec ({f_timeout}) must be "
                            f"greater than heartbeat_interval_sec ({f_interval})."
                        ),
                        suggestion=(
                            "Set heartbeat_timeout_sec to at least 2\u00d7 "
                            "heartbeat_interval_sec so a single missed heartbeat "
                            "triggers the timeout."
                        ),
                        path="balf_gateway.heartbeat_timeout_sec",
                    )
                )
        except (TypeError, ValueError):
            pass  # type errors already reported by layer 2


# ---------------------------------------------------------------------------
# Gateway port collisions (M018) — full N-way check
# ---------------------------------------------------------------------------

# The gateway/port table now lives in edumatcher.gateway_ports so that
# pm-config-show and this collision check can never disagree about which
# sections bind what.  Adding a gateway means editing that one table.
_SINGLETON_GATEWAY_PORTS = tuple(
    (spec.key, spec.process, spec.default_port) for spec in SINGLETON_GATEWAYS
)

_DEFAULT_API_GATEWAY_PORT = DEFAULT_API_GATEWAY_PORT

_LOG_SERVER_EXTRA_PORTS = tuple(
    (extra.field, extra.function, extra.default_port)
    for extra in LOG_SERVER_EXTRA_PORTS
)


def _effective_port(
    section: dict[str, Any], default: int, key: str = "port"
) -> int | None:
    # Malformed values return None; layer 2 has already reported them.
    return effective_port(section, default, key)


def _collect_log_server_pubsub_ports(
    raw: dict[str, Any],
) -> list[tuple[str, str, int]]:
    """Return (label, field, effective port) for the LALF-PS sockets."""
    section = raw.get("log_server")
    if not isinstance(section, dict):
        return []
    # A disabled interface binds nothing, so its configured ports cannot
    # collide with anything and must not be reported as if they could.
    if section.get("pubsub_enabled", True) is False:
        return []

    entries: list[tuple[str, str, int]] = []
    for key, display_name, default_port in _LOG_SERVER_EXTRA_PORTS:
        port = _effective_port(section, default_port, key=key)
        if port is not None:
            entries.append((f"log_server (pm-log-srv {display_name})", key, port))
    return entries


def _collect_gateway_ports(raw: dict[str, Any]) -> list[tuple[str, str, int]]:
    """Return (label, field, effective port) for every configured listener.

    Uses each section's own runtime default when the port key is omitted, so
    two sections that are both simply absent-or-default never collide, but an
    explicit port that happens to match another section's default (or
    another explicit port) is caught.

    The ``field`` element exists because ``log_server`` is the one section
    that binds more than one listener — everything else keys off ``port``,
    but LALF-PS also has ``pub_port`` and ``pull_port``, and a finding needs
    to name the right one.
    """
    entries: list[tuple[str, str, int]] = []

    for key, display_name, default_port in _SINGLETON_GATEWAY_PORTS:
        section = raw.get(key)
        if not isinstance(section, dict):
            continue
        port = _effective_port(section, default_port)
        if port is not None:
            entries.append((f"{key} ({display_name})", "port", port))

    entries.extend(_collect_log_server_pubsub_ports(raw))

    api_gateways = raw.get("api_gateways")
    if isinstance(api_gateways, dict):
        for name, section in api_gateways.items():
            if not isinstance(section, dict):
                continue
            port = _effective_port(section, _DEFAULT_API_GATEWAY_PORT)
            if port is not None:
                entries.append((f"api_gateways.{name} (pm-api-gwy)", "port", port))

    return entries


def _check_gateway_port_collisions(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    """M018 — any two configured gateway sections bound to the same port.

    Previously this only checked balf_gateway against post_trade_gateway and
    market_data_gateway. It now checks every pair across alf_gateway,
    balf_gateway, post_trade_gateway, market_data_gateway, dc_gateway,
    log_server (including its two LALF-PS ZeroMQ ports), and every named
    api_gateways.<name> instance — the full set of independently-configurable
    listeners in engine_config.yaml.
    """
    entries = _collect_gateway_ports(raw)
    seen: dict[int, tuple[str, str]] = {}
    for label, field, port in entries:
        prior = seen.get(port)
        if prior is not None:
            prior_label, prior_field = prior
            results.append(
                CheckResult(
                    code="M018",
                    severity=Severity.ERROR,
                    message=(
                        f"{label}.{field} ({port}) conflicts with "
                        f"{prior_label}.{prior_field} ({port})."
                    ),
                    suggestion=(
                        "Each listener must bind to a unique port. "
                        f"Change {field} on {label}, or {prior_field} on "
                        f"{prior_label}."
                    ),
                    path=f"{label.split(' ', 1)[0]}.{field}",
                )
            )
        else:
            seen[port] = (label, field)


def _check_api_gateway_semantic(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    """Cross-field checks for api_gateways sections."""

    known_gateway_ids = all_gateway_ids(raw)
    if not known_gateway_ids:
        return

    for path, gateway_id in _iter_api_gateway_credential_ids(raw):
        if gateway_id not in known_gateway_ids:
            results.append(
                CheckResult(
                    code="M022",
                    severity=Severity.ERROR,
                    message=(
                        f"API gateway credential gateway_id '{gateway_id}' is not "
                        "defined in gateways.alf."
                    ),
                    suggestion=(
                        f"Add gateway '{gateway_id}' under gateways.alf or update "
                        "the credential to an existing ALF gateway id."
                    ),
                    path=path,
                )
            )


def _iter_api_gateway_credential_ids(raw: dict[str, Any]) -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = []

    named = raw.get("api_gateways")
    if isinstance(named, dict):
        for name, section in named.items():
            if not isinstance(section, dict):
                continue
            entry = str(name).strip() or str(name)
            creds = section.get("credentials")
            if not isinstance(creds, list):
                continue
            for index, cred in enumerate(creds):
                if not isinstance(cred, dict):
                    continue
                gateway = cred.get("gateway_id")
                if gateway is None:
                    continue
                gateway_id = str(gateway).strip().upper()
                if gateway_id:
                    items.append(
                        (
                            f"api_gateways.{entry}.credentials[{index}].gateway_id",
                            gateway_id,
                        )
                    )

    return items
