"""CALF gateway configuration loading helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from edumatcher.config import (
    ENGINE_PUB_ADDR,
    INDEX_PUB_CONNECT_ADDR,
    resolve_gateway_bind_host,
)


@dataclass(frozen=True)
class MarketDataGatewayConfig:
    """Runtime configuration for ``pm-md-gwy``."""

    enabled: bool = True
    name: str = "md-gwy01"
    bind_address: str = field(default_factory=resolve_gateway_bind_host)
    port: int = 5570
    engine_pub_addr: str = ENGINE_PUB_ADDR
    index_pub_addr: str = INDEX_PUB_CONNECT_ADDR
    heartbeat_interval_sec: int = 1
    # 5s matches config_gen's DEFAULT_MARKET_DATA_GATEWAY_IDLE_TIMEOUT_SEC, the
    # sample config, the config spec, and both protocol docs. The runtime alone
    # used to carry 300, which only made sense while the idle timer ignored
    # outbound traffic and so dropped every passive consumer; with that fixed
    # in gateway.py, a client is aged out only when writes to it have actually
    # been failing, which is what this timeout is for.
    idle_timeout_sec: int = 5
    replay_window_sec: int = 30
    max_connections: int = 64
    max_messages_per_second: int = 200
    max_symbols_per_client: int = 200
    max_client_queue: int = 10_000
    depth_levels: int = 10


def _as_int(raw: object, field: str) -> int:
    if isinstance(raw, bool):
        raise ValueError(f"market_data_gateway.{field} must be an integer")
    if not isinstance(raw, (int, str, float)):
        raise ValueError(f"market_data_gateway.{field} must be an integer")
    try:
        return int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"market_data_gateway.{field} must be an integer") from exc


def _load_market_data_gateway_config_from_raw(
    raw: dict[str, Any],
) -> MarketDataGatewayConfig:
    md_raw = raw.get("market_data_gateway")
    if md_raw is None:
        return MarketDataGatewayConfig()
    if not isinstance(md_raw, dict):
        raise ValueError("market_data_gateway must be a mapping")

    enabled = bool(md_raw.get("enabled", True))
    name = str(md_raw.get("name", "md-gwy01"))
    bind_address = resolve_gateway_bind_host(md_raw.get("bind_address"))
    port = _as_int(md_raw.get("port", 5570), "port")
    heartbeat_interval_sec = _as_int(
        md_raw.get("heartbeat_interval_sec", 1),
        "heartbeat_interval_sec",
    )
    idle_timeout_sec = _as_int(md_raw.get("idle_timeout_sec", 5), "idle_timeout_sec")
    replay_window_sec = _as_int(
        md_raw.get("replay_window_sec", 30),
        "replay_window_sec",
    )
    max_connections = _as_int(
        md_raw.get("max_connections", 64),
        "max_connections",
    )
    max_messages_per_second = _as_int(
        md_raw.get("max_messages_per_second", 200),
        "max_messages_per_second",
    )
    max_symbols_per_client = _as_int(
        md_raw.get("max_symbols_per_client", 200),
        "max_symbols_per_client",
    )
    max_client_queue = _as_int(
        md_raw.get("max_client_queue", 10_000),
        "max_client_queue",
    )
    depth_levels = _as_int(
        md_raw.get("depth_levels", 10),
        "depth_levels",
    )

    if port <= 0:
        raise ValueError("market_data_gateway.port must be > 0")
    if heartbeat_interval_sec <= 0:
        raise ValueError("market_data_gateway.heartbeat_interval_sec must be > 0")
    if idle_timeout_sec <= 0:
        raise ValueError("market_data_gateway.idle_timeout_sec must be > 0")
    if replay_window_sec <= 0:
        raise ValueError("market_data_gateway.replay_window_sec must be > 0")
    if max_connections <= 0:
        raise ValueError("market_data_gateway.max_connections must be > 0")
    if max_messages_per_second <= 0:
        raise ValueError("market_data_gateway.max_messages_per_second must be > 0")
    if max_symbols_per_client <= 0:
        raise ValueError("market_data_gateway.max_symbols_per_client must be > 0")
    if max_client_queue <= 0:
        raise ValueError("market_data_gateway.max_client_queue must be > 0")
    if depth_levels <= 0:
        raise ValueError("market_data_gateway.depth_levels must be > 0")

    return MarketDataGatewayConfig(
        enabled=enabled,
        name=name,
        bind_address=bind_address,
        port=port,
        engine_pub_addr=ENGINE_PUB_ADDR,
        index_pub_addr=INDEX_PUB_CONNECT_ADDR,
        heartbeat_interval_sec=heartbeat_interval_sec,
        idle_timeout_sec=idle_timeout_sec,
        replay_window_sec=replay_window_sec,
        max_connections=max_connections,
        max_messages_per_second=max_messages_per_second,
        max_symbols_per_client=max_symbols_per_client,
        max_client_queue=max_client_queue,
        depth_levels=depth_levels,
    )


def load_market_data_gateway_config(path: Path) -> MarketDataGatewayConfig:
    """Load optional ``market_data_gateway`` block from engine config YAML."""
    if not path.exists():
        return MarketDataGatewayConfig()

    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        return MarketDataGatewayConfig()

    return _load_market_data_gateway_config_from_raw(raw)


def validate_market_data_gateway_section(raw: dict[str, Any]) -> None:
    """Validate market_data_gateway section using runtime loader semantics."""

    _load_market_data_gateway_config_from_raw(raw)


def load_default_market_data_gateway_config() -> MarketDataGatewayConfig:
    """Return this subsystem's section of the deployed compiled configuration.

    Falls back to dataclass defaults when nothing has been deployed yet, which
    is exactly what the YAML loader above did for a missing file — many tools
    that read this section, such as the spies and viewers, must still run
    against an exchange whose configuration was never installed.

    The import is deferred because ``config_artifact`` imports this module to
    describe the artifact's shape.
    """
    from edumatcher.config_artifact import load_compiled_config

    compiled = load_compiled_config()
    return (
        MarketDataGatewayConfig() if compiled is None else compiled.market_data_gateway
    )
