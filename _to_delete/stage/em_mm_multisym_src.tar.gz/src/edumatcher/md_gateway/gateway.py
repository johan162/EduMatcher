"""CALF market data gateway runtime.

Design priorities for this implementation:
- Correctness first: strict protocol validation and deterministic behavior
- Maintainability: clear decomposition and heavily documented control flow
- Defensive behavior: bounded queues, explicit disconnect paths, replay checks

The gateway bridges engine PUB topics onto CALF/TCP streams.
"""

from __future__ import annotations

import logging
import select
import signal
import socket
import threading
import time
from collections import defaultdict
from typing import Any

from edumatcher.md_gateway.client_session import ClientSession
from edumatcher.md_gateway.config import MarketDataGatewayConfig
from edumatcher.md_gateway.fanout import SubscriptionRegistry
from edumatcher.md_gateway.normaliser import EngineNormaliser
from edumatcher.md_gateway.protocol import build_line, iso_utc, parse_line
from edumatcher.md_gateway.replay_buffer import ReplayBuffer, ReplayMissError
from edumatcher.md_gateway.sequencer import SequenceAllocator
from edumatcher.messaging.bus import make_subscriber
from edumatcher.models.message import decode
from edumatcher.models.price import DEFAULT_TICK_DECIMALS
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.session import TOPIC_SESSION_STATE
from edumatcher.models.generated.book import PREFIX_BOOK_SNAPSHOT
from edumatcher.models.generated.auction import (
    PREFIX_AUCTION_INDICATIVE,
    PREFIX_AUCTION_RESULT,
)
from edumatcher.models.generated.circuit_breaker import (
    PREFIX_CIRCUIT_BREAKER_EXTEND,
    PREFIX_CIRCUIT_BREAKER_HALT,
    PREFIX_CIRCUIT_BREAKER_RESUME,
)
from edumatcher.models.generated.index import TOPIC_INDEX_UPDATE

_ALLOWED_CHANNELS = frozenset(
    {"TOP", "TRADE", "STATE", "INDEX", "DEPTH", "AUCTION", "CB"}
)

# Channels that may be combined with SYM=* on a single SUB line (CALF 1.0.0,
# see EduMatcher-CALF-Extensions.md §5; AUCTION added by
# EduMatcher-CALF-auction-cb.md §6.4). INDEX, DEPTH, and CB are deliberately
# excluded: INDEX always requires an explicit index id, DEPTH is heavy enough
# per-message that a wildcard subscription could multiply one client's
# outbound bandwidth by the whole symbol count (§6.9), and CB halts/resumes
# are rare, operator-relevant-per-symbol events rather than a firehose use
# case. AUCTION is included: auction events are extremely low frequency (at
# most a handful per symbol per day), so a wildcard subscription poses none
# of DEPTH's bandwidth risk.
_WILDCARD_ELIGIBLE_CHANNELS = frozenset({"STATE", "TOP", "TRADE", "AUCTION"})
# Channels that have a current-state baseline a SNAP can express, and so the
# exact set _send_snapshot_for_stream knows how to fill. TRADE and AUCTION are
# streams of discrete events with no such state: there is no snapshot of a
# print, and emitting an empty envelope in place of one tells a client
# something false. Kept beside the channel sets it partitions so the two
# cannot drift.
_SNAPSHOT_CHANNELS = frozenset({"TOP", "STATE", "INDEX", "DEPTH", "CB"})
_MAX_LINE_BYTES = 4096
_HELLO_TIMEOUT_SEC = 5
_MAX_ENGINE_EVENTS_PER_LOOP = 2000
_DEBUG_SUMMARY_INTERVAL_SEC = 5.0

log = logging.getLogger(__name__)


class MarketDataGateway:
    """CALF TCP gateway process."""

    def __init__(
        self,
        config: MarketDataGatewayConfig,
        known_symbols: set[str] | None = None,
        tick_decimals: dict[str, int] | None = None,
    ) -> None:
        self.config = config
        self._known_symbols = set(s.upper() for s in (known_symbols or set()))
        # Per-symbol display precision, for WELCOME|REF= and the SYMBOLS reply.
        # Separate from _known_symbols rather than replacing it: the symbol set
        # grows at runtime as unseen instruments appear on the engine bus, and
        # those arrive with no configured precision, so the two are genuinely
        # different sets. _ref_fields resolves that difference in one place.
        self._tick_decimals = {
            s.upper(): int(d) for s, d in (tick_decimals or {}).items()
        }

        self._running = False
        self._server: socket.socket | None = None
        self._clients: dict[int, ClientSession] = {}

        self._subs = SubscriptionRegistry()
        self._normaliser = EngineNormaliser(depth_levels=config.depth_levels)
        self._sequencer = SequenceAllocator()
        self._replay = ReplayBuffer(config.replay_window_sec)
        self._debug_counts: defaultdict[str, int] = defaultdict(int)
        self._debug_last_summary = time.monotonic()

        self._sub_sock = make_subscriber(
            config.engine_pub_addr,
            PREFIX_BOOK_SNAPSHOT,
            TOPIC_TRADE_EXECUTED,
            TOPIC_SESSION_STATE,
            PREFIX_CIRCUIT_BREAKER_HALT,
            PREFIX_CIRCUIT_BREAKER_RESUME,
            PREFIX_CIRCUIT_BREAKER_EXTEND,
            PREFIX_AUCTION_RESULT,
            PREFIX_AUCTION_INDICATIVE,
        )
        self._index_sub = make_subscriber(config.index_pub_addr, "index.")

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        self._debug_counts[key] += amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in sorted(self._debug_counts.items())
        )
        log.debug("md_gateway flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Start TCP listener and process loop until stopped."""
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind((self.config.bind_address, self.config.port))
        self._server.listen(128)
        self._server.setblocking(False)

        self._running = True

        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, lambda *_: self.stop())
            signal.signal(signal.SIGTERM, lambda *_: self.stop())

        log.info(
            "listening on %s:%s (engine_pub=%s index_pub=%s)",
            self.config.bind_address,
            self.config.port,
            self.config.engine_pub_addr,
            self.config.index_pub_addr,
        )

        try:
            while self._running:
                self._accept_new_clients()
                self._read_client_data()
                self._poll_engine_events()
                self._send_heartbeats_if_due()
                self._flush_client_writes()
                self._drop_idle_clients()
                time.sleep(0.01)
        finally:
            self.close()

    def stop(self) -> None:
        log.info("stop requested")
        self._running = False

    def close(self) -> None:
        self._flush_debug_summary(force=True)
        log.info("closing market data gateway")
        for session in list(self._clients.values()):
            try:
                session.sock.close()
            except OSError:
                pass
        self._clients.clear()

        if self._server is not None:
            self._server.close()
            self._server = None

        if not self._sub_sock.closed:
            self._sub_sock.close()
        if not self._index_sub.closed:
            self._index_sub.close()

    # ------------------------------------------------------------------
    # Network IO
    # ------------------------------------------------------------------

    def _accept_new_clients(self) -> None:
        if self._server is None:
            return

        while True:
            try:
                conn, addr = self._server.accept()
            except BlockingIOError:
                break
            except OSError as exc:
                log.warning("accept failed: %s", exc)
                break

            if len(self._clients) >= self.config.max_connections:
                log.warning(
                    "connection rejected: max_connections=%d reached",
                    self.config.max_connections,
                )
                try:
                    conn.close()
                except OSError:
                    pass
                continue

            conn.setblocking(False)
            session = ClientSession(sock=conn, addr=addr)
            session.rate_tokens = float(self.config.max_messages_per_second)
            self._clients[conn.fileno()] = session
            log.info(
                "client connected addr=%s:%s fd=%d", addr[0], addr[1], conn.fileno()
            )

    def _read_client_data(self) -> None:
        if not self._clients:
            return

        readable = [session.sock for session in self._clients.values()]
        try:
            ready, _, _ = select.select(readable, [], [], 0)
        except (OSError, ValueError) as exc:
            log.warning("read select failed: %s", exc)
            return

        for sock_obj in ready:
            self._dbg_count("readable_sockets")
            session = self._clients.get(sock_obj.fileno())
            if session is None:
                continue

            try:
                chunk = session.sock.recv(4096)
            except (BlockingIOError, OSError):
                continue

            if not chunk:
                self._disconnect(session, reason="peer_closed")
                continue

            session.in_buffer.extend(chunk)
            session.last_activity = time.monotonic()

            # Defensive framing guard: when no newline arrives and the line grows
            # beyond the protocol max, fail fast to avoid unbounded buffering.
            if (
                b"\n" not in session.in_buffer
                and len(session.in_buffer) > _MAX_LINE_BYTES
            ):
                self._queue_line(
                    session,
                    "ERR",
                    {"CODE": "BAD_MESSAGE", "MSG": "line exceeds 4096 bytes"},
                )
                log.warning(
                    "dropping client fd=%d due to oversized inbound line",
                    session.sock.fileno(),
                )
                self._close_after_flush(session)
                continue

            self._drain_lines(session)

    def _drain_lines(self, session: ClientSession) -> None:
        """Extract complete newline-delimited lines and dispatch parser.

        TCP is a byte stream. This loop deliberately handles all three cases:
        1) partial line (leave in buffer)
        2) exactly one full line
        3) multiple lines in one recv chunk
        """
        while True:
            idx = session.in_buffer.find(b"\n")
            if idx < 0:
                return

            raw = bytes(session.in_buffer[:idx])
            del session.in_buffer[: idx + 1]

            if len(raw) + 1 > _MAX_LINE_BYTES:
                self._queue_line(
                    session,
                    "ERR",
                    {"CODE": "BAD_MESSAGE", "MSG": "line exceeds 4096 bytes"},
                )
                log.warning(
                    "dropping client fd=%d due to oversized framed line",
                    session.sock.fileno(),
                )
                self._close_after_flush(session)
                return

            line = raw.decode("utf-8", errors="replace")
            self._handle_client_line(session, line)

    def _flush_client_writes(self) -> None:
        """Flush queued outbound bytes to all clients.

        Writes are non-blocking and may complete partially; ``out_offset`` tracks
        progress for the first queued message until fully sent.
        """
        for session in list(self._clients.values()):
            while session.out_queue:
                payload = session.out_queue[0]
                unsent = payload[session.out_offset :]
                try:
                    sent = session.sock.send(unsent)
                except (BlockingIOError, OSError):
                    break

                if sent <= 0:
                    break

                # Outbound progress counts as activity, per the protocol's
                # "no inbound and no outbound traffic" idle rule. Without this
                # the timer only ever advanced on inbound bytes, so a purely
                # passive consumer — the normal shape of a market-data client,
                # which has nothing to say — was disconnected every
                # idle_timeout_sec despite a perfectly healthy socket.
                # Deliberately keyed on a successful send rather than on
                # queuing, so a client that has stopped draining still ages
                # out instead of being kept alive by our own backlog.
                session.last_activity = time.monotonic()
                session.out_offset += sent

                if session.out_offset >= len(payload):
                    session.out_queue.popleft()
                    session.out_offset = 0

            if len(session.out_queue) > self.config.max_client_queue:
                log.warning(
                    "disconnecting slow client fd=%d queue=%d max=%d",
                    session.sock.fileno(),
                    len(session.out_queue),
                    self.config.max_client_queue,
                )
                self._disconnect(session, reason="slow_client")
                continue

            if session.closing and not session.out_queue:
                self._disconnect(session, reason="close_after_flush")

    # ------------------------------------------------------------------
    # Protocol handling
    # ------------------------------------------------------------------

    def _handle_client_line(self, session: ClientSession, line: str) -> None:
        try:
            frame = parse_line(line)
        except Exception as exc:
            log.debug(
                "parse error for fd=%d line=%r err=%s", session.sock.fileno(), line, exc
            )
            self._queue_line(
                session,
                "ERR",
                {"CODE": "BAD_MESSAGE", "MSG": "parse error"},
            )
            return

        if not self._allow_message_now(session):
            log.debug("rate-limited client fd=%d", session.sock.fileno())
            self._queue_line(
                session,
                "ERR",
                {"CODE": "RATE_LIMITED", "MSG": "too many messages"},
            )
            return

        if not session.authenticated:
            if frame.msg_type != "HELLO":
                self._queue_line(
                    session,
                    "ERR",
                    {"CODE": "AUTH_REQUIRED", "MSG": "send HELLO first"},
                )
                log.info(
                    "pre-auth command rejected fd=%d cmd=%s",
                    session.sock.fileno(),
                    frame.msg_type,
                )
                self._close_after_flush(session)
                return
            self._handle_hello(session, frame.fields)
            return

        if frame.msg_type == "SUB":
            self._handle_sub(session, frame.fields)
        elif frame.msg_type == "SYMBOLS":
            self._handle_symbols(session)
        elif frame.msg_type == "RESUME":
            self._handle_resume(session, frame.fields)
        elif frame.msg_type == "UNSUB":
            self._handle_unsub(session, frame.fields)
        elif frame.msg_type == "PING":
            self._queue_raw(session, build_line("PONG"), is_market_data=False)
        elif frame.msg_type == "EXIT":
            self._close_after_flush(session)
        else:
            self._queue_line(
                session,
                "ERR",
                {"CODE": "BAD_MESSAGE", "MSG": f"unsupported {frame.msg_type}"},
            )
            log.debug(
                "unsupported command fd=%d cmd=%s",
                session.sock.fileno(),
                frame.msg_type,
            )

    def _handle_hello(self, session: ClientSession, fields: dict[str, str]) -> None:
        client = fields.get("CLIENT", "")
        proto = fields.get("PROTO", "")
        if not client or len(client) > 32 or proto != "CALF1":
            self._queue_line(
                session,
                "ERR",
                {"CODE": "PROTO_MISMATCH", "MSG": "CLIENT and PROTO=CALF1 required"},
            )
            self._close_after_flush(session)
            return

        session.client_id = client
        session.authenticated = True
        session.last_activity = time.monotonic()

        welcome_fields = {
            "PROTO": "CALF1",
            "GW": self.config.name,
            "HBINT": str(self.config.heartbeat_interval_sec),
            "REPLAY": str(self.config.replay_window_sec),
            # CH_SUPPORTED lets a client detect gateway capability without a
            # PROTO version bump (EduMatcher-CALF-Extensions.md §3.2). Always
            # the full _ALLOWED_CHANNELS list since every channel in it ships
            # on by default as of 1.0.0 — its value to a client is mainly in
            # its *presence*, which distinguishes a 1.0.0+ gateway from a
            # pre-1.0.0 one that predates this field entirely.
            "CH_SUPPORTED": ",".join(sorted(_ALLOWED_CHANNELS)),
        }
        if self._known_symbols:
            welcome_fields["SYMBOLS"] = ",".join(sorted(self._known_symbols))
            welcome_fields["REF"] = self._ref_fields()

        self._queue_line(session, "WELCOME", welcome_fields)
        log.info("client authenticated fd=%d client=%s", session.sock.fileno(), client)

    def _handle_symbols(self, session: ClientSession) -> None:
        """Answer a ``SYMBOLS`` request with the current instrument universe.

        ``WELCOME|SYMBOLS=`` alone is not enough for a client that needs the
        universe: it is optional, sent once, and omitted entirely when the
        gateway started without a readable engine config. The set also *grows*
        as instruments are seen on the engine bus, so a client that connected
        before a symbol first traded had no way to learn of it short of
        reconnecting. This makes the list askable at any time.

        ``COUNT`` is always present, including when it is ``0`` — that is a
        meaningful answer ("this gateway knows of no instruments yet"), and a
        client must be able to tell it apart from a malformed reply.
        """
        fields = {"COUNT": str(len(self._known_symbols))}
        if self._known_symbols:
            fields["SYMBOLS"] = ",".join(sorted(self._known_symbols))
            fields["REF"] = self._ref_fields()
        self._queue_line(session, "SYMBOLS", fields)

    def _ref_fields(self) -> str:
        """Build ``REF=SYM:DEC,...`` — per-symbol display precision.

        Static reference data, so it belongs here and on ``WELCOME`` rather
        than on a market data channel: ``tick_decimals`` never changes for a
        symbol, and repeating it on every ``TOP`` or ``TRADE`` would put a
        constant on the hottest path in a protocol whose ``MD`` messages are
        deliberately deltas.

        Without it a client has no way to learn an instrument's precision at
        all — the only other source is ``GET /api/symbols``, which requires a
        trading credential that a market data consumer has no business holding
        — so every client rendering a price had to assume the default of 2 and
        be quietly wrong about anything else.

        The ``SYM:DEC`` tuple reuses the colon-delimited grammar ``DEPTH``
        already uses for ``price:qty:count``, and leaves room to grow to
        ``SYM:DEC:MULT:CCY`` as further reference fields are defined, without
        another protocol change. Parallel positional lists would have to stay
        index-aligned forever.

        Every symbol in ``SYMBOLS`` appears here, so a client never has to
        reason about one being listed in one field and missing from the other.
        Symbols first seen on the engine bus at runtime have no configured
        precision and are reported at ``DEFAULT_TICK_DECIMALS``, which is what
        the rest of the system assumes for them too.
        """
        return ",".join(
            f"{sym}:{self._tick_decimals.get(sym, DEFAULT_TICK_DECIMALS)}"
            for sym in sorted(self._known_symbols)
        )

    def _handle_resume(self, session: ClientSession, fields: dict[str, str]) -> None:
        """Resume one ``(CH, SYM)`` stream from ``LASTSEQ``.

        A standalone, repeatable command rather than a ``HELLO`` flag. As a
        flag it could only ever run once per connection — ``HELLO`` is
        dispatched only while a session is unauthenticated — so a client
        following more than one stream, which is the normal case, had no way to
        resume the rest of them after a reconnect.

        Malformed requests answer ``ERR`` and leave the session open, matching
        ``SUB``. Killing the connection was defensible when this could only
        happen during the handshake; for a command a client may send many times
        it would turn one bad request into a full resubscribe cycle.
        """
        ch_values = self._parse_csv_upper(fields.get("CH", ""))
        sym_values = self._parse_csv_upper(fields.get("SYM", ""))

        if len(ch_values) != 1 or len(sym_values) != 1:
            self._queue_line(
                session,
                "ERR",
                {
                    "CODE": "BAD_MESSAGE",
                    "MSG": "RESUME requires exactly one CH and one SYM",
                },
            )
            return

        last_seq_raw = fields.get("LASTSEQ", "")
        try:
            last_seq = int(last_seq_raw)
        except (TypeError, ValueError):
            self._queue_line(
                session,
                "ERR",
                {"CODE": "BAD_MESSAGE", "MSG": "LASTSEQ must be an integer"},
            )
            return

        if last_seq <= 0:
            self._queue_line(
                session,
                "ERR",
                {"CODE": "BAD_MESSAGE", "MSG": "LASTSEQ must be > 0"},
            )
            return

        ch = ch_values[0]
        sym = sym_values[0]

        if ch not in _ALLOWED_CHANNELS:
            self._queue_line(
                session,
                "ERR",
                {"CODE": "INVALID_CHANNEL", "CH": ch, "SYM": sym},
            )
            return

        # SYM=* is meaningless for RESUME: unlike SUB, there is no per-symbol
        # snapshot-burst path here, so a wildcard resume that falls through to
        # _send_snapshot_for_stream on a replay miss would silently produce an
        # empty TOP snapshot (top_snapshot_fields("*") finds no such symbol).
        # Reject up front with the same error SUB uses for wildcard misuse,
        # rather than accepting a request that cannot be served correctly.
        if sym == "*":
            self._queue_line(
                session,
                "ERR",
                {"CODE": "INVALID_SYMBOL", "CH": ch, "SYM": sym},
            )
            return

        # Resume implies immediate live continuation for the requested stream,
        # but only where the client is not already receiving it. A wildcard
        # subscriber (SUB|CH=TRADE|SYM=*, which is how the terminal bridge
        # follows the tape) would otherwise accumulate one redundant concrete
        # pair per RESUME, permanently: nothing ever removes them, and
        # session_wants scans the set linearly for every client on every
        # stream event.
        if not self._subs.session_wants(session.sock.fileno(), ch, sym):
            session.subscriptions.add((ch, sym))
            self._subs.set_for_client(session.sock.fileno(), session.subscriptions)

        try:
            lines = self._replay.replay_since(ch, sym, last_seq)
        except ReplayMissError:
            self._queue_line(
                session,
                "ERR",
                {"CODE": "REPLAY_MISS", "CH": ch, "SYM": sym},
            )
            # Only the snapshot-backed channels have a baseline to re-sync to,
            # and _send_snapshot_for_stream can only fill those. TRADE and
            # AUCTION carry discrete events: it would emit a SNAP envelope with
            # no payload, which a client decoding by CH reads as a print of
            # zero shares at zero price. A missed print is simply gone — the
            # ERR says so, and inventing a snapshot of one says something
            # false.
            if ch in _SNAPSHOT_CHANNELS:
                self._send_snapshot_for_stream(session, ch, sym)
            return

        for line in lines:
            self._queue_raw(session, line, is_market_data=True)

    def _handle_sub(self, session: ClientSession, fields: dict[str, str]) -> None:
        channels = self._parse_csv_upper(fields.get("CH", ""))
        symbols = self._parse_csv_upper(fields.get("SYM", ""))

        if not channels:
            self._queue_line(session, "ERR", {"CODE": "INVALID_CHANNEL"})
            return
        if not symbols:
            self._queue_line(session, "ERR", {"CODE": "INVALID_SYMBOL"})
            return

        # Validate channels first so request is all-or-nothing.
        for ch in channels:
            if ch not in _ALLOWED_CHANNELS:
                self._queue_line(session, "ERR", {"CODE": "INVALID_CHANNEL", "CH": ch})
                return

        # Validate symbol wildcard and known symbol list before mutating state.
        # SYM=* is allowed for STATE, TOP, and TRADE (CALF 1.0.0, see
        # EduMatcher-CALF-Extensions.md §5); INDEX and DEPTH still require an
        # explicit symbol/index id (§4.2, §6.9).
        for sym in symbols:
            if sym == "*" and not set(channels).issubset(_WILDCARD_ELIGIBLE_CHANNELS):
                self._queue_line(session, "ERR", {"CODE": "INVALID_SYMBOL", "SYM": sym})
                return
            if sym != "*" and self._known_symbols and sym not in self._known_symbols:
                if not any(ch == "INDEX" for ch in channels):
                    self._queue_line(
                        session, "ERR", {"CODE": "INVALID_SYMBOL", "SYM": sym}
                    )
                    return
            if any(ch == "INDEX" for ch in channels) and not sym:
                self._queue_line(session, "ERR", {"CODE": "INVALID_SYMBOL", "SYM": sym})
                return

        requested_pairs = {(ch, sym) for ch in channels for sym in symbols}
        merged_subs = set(session.subscriptions)
        merged_subs.update(requested_pairs)

        unique_symbols = {sym for _, sym in merged_subs}
        if len(unique_symbols) > self.config.max_symbols_per_client:
            self._queue_line(session, "ERR", {"CODE": "SUB_LIMIT"})
            return

        # Only newly added pairs trigger auto SNAP behavior.
        new_pairs = requested_pairs - session.subscriptions
        session.subscriptions = merged_subs
        self._subs.set_for_client(session.sock.fileno(), session.subscriptions)
        log.debug(
            "subscriptions updated fd=%d total=%d new=%d",
            session.sock.fileno(),
            len(session.subscriptions),
            len(new_pairs),
        )

        for ch, sym in sorted(new_pairs):
            # Wildcard TOP has no single meaningful "top of book" of its own
            # (unlike STATE's session-wide summary) — top_snapshot_fields("*")
            # would look up a symbol literally named "*" and return an empty
            # snapshot. Send one real per-symbol SNAP for every currently
            # known symbol instead (EduMatcher-CALF-Extensions.md §5.4). The
            # ("TOP", "*") pair itself is still stored in session.subscriptions
            # above so future live MD events fan out via the wildcard match in
            # SubscriptionRegistry.session_wants, including for symbols that
            # become known only after this SUB.
            if ch == "TOP" and sym == "*":
                for real_sym in sorted(self._known_symbols):
                    self._send_snapshot_for_stream(session, "TOP", real_sym)
                continue
            # INDEX has always had a working SNAP path (index_snapshot_fields,
            # the "elif ch == 'INDEX'" branch below) but it was never wired
            # into SUB's auto-snapshot trigger, so SUB|CH=INDEX silently sent
            # no baseline — contradicting EduMatcher-Index.md's original
            # design ("gateway sends an initial SNAP"). Fixed here to match
            # TOP/STATE/DEPTH's already-established pattern.
            if ch in _SNAPSHOT_CHANNELS:
                self._send_snapshot_for_stream(session, ch, sym)

    def _handle_unsub(self, session: ClientSession, fields: dict[str, str]) -> None:
        channels = self._parse_csv_upper(fields.get("CH", ""))
        symbols = self._parse_csv_upper(fields.get("SYM", ""))
        if not channels or not symbols:
            self._queue_line(session, "ERR", {"CODE": "BAD_MESSAGE"})
            return

        for ch in channels:
            for sym in symbols:
                session.subscriptions.discard((ch, sym))
        self._subs.set_for_client(session.sock.fileno(), session.subscriptions)
        log.debug(
            "subscriptions removed fd=%d now=%d",
            session.sock.fileno(),
            len(session.subscriptions),
        )

    # ------------------------------------------------------------------
    # Snapshot and stream emission
    # ------------------------------------------------------------------

    def _send_snapshot_for_stream(
        self, session: ClientSession, ch: str, sym: str
    ) -> None:
        seq = self._sequencer.ensure_started(ch, sym)
        fields: dict[str, str] = {
            "CH": ch,
            "SYM": sym,
            "SEQ": str(seq),
            "TS": iso_utc(time.time()),
        }
        if ch == "TOP":
            fields.update(self._normaliser.top_snapshot_fields(sym))
        elif ch == "STATE":
            fields.update(self._normaliser.state_snapshot_fields(sym))
        elif ch == "INDEX":
            fields.update(self._normaliser.index_snapshot_fields(sym))
        elif ch == "DEPTH":
            fields.update(self._normaliser.depth_snapshot_fields(sym))
        elif ch == "CB":
            fields.update(self._normaliser.cb_snapshot_fields(sym))

        self._queue_raw(session, build_line("SNAP", fields), is_market_data=True)

    def _emit_stream_event(
        self,
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        """Emit one market-data event to subscribed clients.

        This method centralizes sequence allocation + replay persistence so all
        CALF stream event types behave consistently.
        """
        seq = self._sequencer.next_seq(ch, sym)
        fields = {
            "CH": ch,
            "SYM": sym,
            "SEQ": str(seq),
            "TS": iso_utc(ts_seconds),
        }
        fields.update(payload_fields)

        line = build_line(msg_type, fields)
        trade_id = payload_fields.get("TRADE_ID") if ch == "TRADE" else None
        if not self._replay.append(ch, sym, seq, line, trade_id=trade_id):
            return
        self._dbg_count("stream_events")

        for target in self._clients.values():
            if not target.authenticated or target.closing:
                continue
            if self._subs.session_wants(target.sock.fileno(), ch, sym):
                self._queue_raw(target, line, is_market_data=True)

    # ------------------------------------------------------------------
    # Engine event mapping
    # ------------------------------------------------------------------

    def _poll_engine_events(self) -> None:
        budget = _MAX_ENGINE_EVENTS_PER_LOOP
        while budget > 0 and self._sub_sock.poll(timeout=0):
            self._dbg_count("engine_sub_messages")
            try:
                topic, payload = decode(self._sub_sock.recv_multipart())
            except Exception as exc:
                log.warning("md_gateway decode error on engine SUB event: %s", exc)
                budget -= 1
                continue
            budget -= 1
            try:
                now_seconds = _extract_ts(payload)

                if topic.startswith(PREFIX_BOOK_SNAPSHOT):
                    self._dbg_count("book_topics")
                    sym = topic[5:].upper()
                    self._known_symbols.add(sym)
                    md_fields = self._normaliser.normalise_book(sym, payload)
                    if md_fields:
                        self._emit_stream_event(
                            "MD", "TOP", sym, md_fields, now_seconds
                        )
                    depth_fields = self._normaliser.normalise_depth(sym, payload)
                    if depth_fields:
                        self._emit_stream_event(
                            "DEPTH", "DEPTH", sym, depth_fields, now_seconds
                        )
                    continue

                if topic == TOPIC_TRADE_EXECUTED:
                    self._dbg_count("trade_topics")
                    sym, trade_fields = self._normaliser.normalise_trade(payload)
                    if sym:
                        self._known_symbols.add(sym)
                        self._emit_stream_event(
                            "TRADE",
                            "TRADE",
                            sym,
                            trade_fields,
                            now_seconds,
                        )
                    continue

                if topic == TOPIC_SESSION_STATE:
                    self._dbg_count("session_state_topics")
                    sym, state_fields = self._normaliser.normalise_session_state(
                        payload
                    )
                    self._emit_stream_event(
                        "STATE", "STATE", sym, state_fields, now_seconds
                    )
                    # A SUB carrying an explicit symbol only matches events on
                    # that symbol, so a client watching one instrument would
                    # never learn the exchange had opened or closed — it saw
                    # halts and resumes but not the session around them. Repeat
                    # the transition per symbol so a single-symbol subscriber is
                    # as well informed as a wildcard one.
                    for (
                        per_sym,
                        per_fields,
                    ) in self._normaliser.apply_session_to_symbols(self._known_symbols):
                        self._emit_stream_event(
                            "STATE", "STATE", per_sym, per_fields, now_seconds
                        )
                    continue

                if topic.startswith(PREFIX_CIRCUIT_BREAKER_HALT):
                    self._dbg_count("halt_topics")
                    sym = topic.split(".", 2)[2].upper()
                    state_sym, state_fields = self._normaliser.normalise_halt(sym)
                    self._emit_stream_event(
                        "STATE",
                        "STATE",
                        state_sym,
                        state_fields,
                        now_seconds,
                    )
                    cb_sym, cb_fields = self._normaliser.normalise_cb_halt(sym, payload)
                    self._emit_stream_event("CB", "CB", cb_sym, cb_fields, now_seconds)
                    continue

                if topic.startswith(PREFIX_CIRCUIT_BREAKER_EXTEND):
                    # An ACE extension leaves the symbol halted, so STATE is
                    # unchanged and deliberately not re-emitted — only the CB
                    # corridor and resume time have moved.
                    self._dbg_count("extend_topics")
                    sym = topic.split(".", 2)[2].upper()
                    cb_sym, cb_fields = self._normaliser.normalise_cb_extend(
                        sym, payload
                    )
                    self._emit_stream_event("CB", "CB", cb_sym, cb_fields, now_seconds)
                    continue

                if topic.startswith(PREFIX_CIRCUIT_BREAKER_RESUME):
                    self._dbg_count("resume_topics")
                    sym = topic.split(".", 2)[2].upper()
                    state_sym, state_fields = self._normaliser.normalise_resume(sym)
                    self._emit_stream_event(
                        "STATE",
                        "STATE",
                        state_sym,
                        state_fields,
                        now_seconds,
                    )
                    cb_sym, cb_fields = self._normaliser.normalise_cb_resume(
                        sym, payload
                    )
                    self._emit_stream_event("CB", "CB", cb_sym, cb_fields, now_seconds)
                    continue

                if topic.startswith(PREFIX_AUCTION_INDICATIVE):
                    self._dbg_count("auction_indicative_topics")
                    (
                        indic_sym,
                        indic_fields,
                    ) = self._normaliser.normalise_auction_indicative(payload)
                    if indic_sym:
                        # INDIC rather than AUCTION: same channel, different
                        # statement. AUCTION says what happened at an uncross;
                        # INDIC says what would happen if the phase ended now,
                        # and a client must not mistake the second for the
                        # first (T-M1).
                        self._emit_stream_event(
                            "INDIC", "AUCTION", indic_sym, indic_fields, now_seconds
                        )
                    continue

                if topic.startswith(PREFIX_AUCTION_RESULT):
                    self._dbg_count("auction_topics")
                    sym, auction_fields = self._normaliser.normalise_auction_result(
                        payload
                    )
                    if sym:
                        self._emit_stream_event(
                            "AUCTION", "AUCTION", sym, auction_fields, now_seconds
                        )
            except Exception:
                log.warning(
                    "md_gateway handler error on engine topic=%s", topic, exc_info=True
                )
                continue

        while budget > 0 and self._index_sub.poll(timeout=0):
            self._dbg_count("index_sub_messages")
            try:
                topic, payload = decode(self._index_sub.recv_multipart())
            except Exception as exc:
                log.warning("md_gateway decode error on index SUB event: %s", exc)
                budget -= 1
                continue
            budget -= 1
            try:
                now_seconds = _extract_ts(payload)
                if topic == TOPIC_INDEX_UPDATE:
                    self._dbg_count("index_update_topics")
                    index_id, fields = self._normaliser.normalise_index_update(payload)
                    if index_id:
                        self._emit_stream_event(
                            "IDX", "INDEX", index_id, fields, now_seconds
                        )
            except Exception:
                log.warning(
                    "md_gateway handler error on index topic=%s", topic, exc_info=True
                )
                continue

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def _send_heartbeats_if_due(self) -> None:
        now = time.monotonic()
        for session in self._clients.values():
            if not session.authenticated:
                continue
            baseline = max(session.last_market_data_sent, session.last_heartbeat_sent)
            if now - baseline < self.config.heartbeat_interval_sec:
                continue
            self._queue_line(session, "HB", {"TS": iso_utc(time.time())})
            session.last_heartbeat_sent = now

    def _drop_idle_clients(self) -> None:
        now = time.monotonic()
        for session in list(self._clients.values()):
            idle = now - session.last_activity
            if (
                not session.authenticated
                and now - session.connected_at > _HELLO_TIMEOUT_SEC
            ):
                self._disconnect(session, reason="auth_timeout")
                continue
            if session.authenticated and idle > self.config.idle_timeout_sec:
                self._disconnect(session, reason="idle_timeout")

    # ------------------------------------------------------------------
    # Queue/disconnect helpers
    # ------------------------------------------------------------------

    def _queue_line(
        self,
        session: ClientSession,
        msg_type: str,
        fields: dict[str, str],
    ) -> None:
        self._queue_raw(session, build_line(msg_type, fields), is_market_data=False)

    def _queue_raw(
        self,
        session: ClientSession,
        payload: bytes,
        *,
        is_market_data: bool,
    ) -> None:
        if session.closing and is_market_data:
            return
        if len(session.out_queue) >= self.config.max_client_queue:
            if not session.closing:
                session.out_queue.clear()
                session.out_offset = 0
                session.closing = True
            return
        session.out_queue.append(payload)
        if is_market_data:
            session.last_market_data_sent = time.monotonic()

    def _allow_message_now(self, session: ClientSession) -> bool:
        now = time.monotonic()
        elapsed = now - session.rate_updated
        session.rate_updated = now
        max_rate = float(self.config.max_messages_per_second)
        session.rate_tokens = min(max_rate, session.rate_tokens + elapsed * max_rate)
        if session.rate_tokens < 1.0:
            self._dbg_count("rate_limited")
            return False
        session.rate_tokens -= 1.0
        return True

    def _disconnect(self, session: ClientSession, reason: str = "unspecified") -> None:
        fd = session.sock.fileno()
        client_id = session.client_id or "-"
        try:
            session.sock.close()
        except OSError:
            pass
        self._clients.pop(fd, None)
        self._subs.remove_client(fd)
        log.info("client disconnected fd=%d client=%s reason=%s", fd, client_id, reason)

    def _close_after_flush(self, session: ClientSession) -> None:
        session.closing = True
        log.debug("session fd=%d marked closing-after-flush", session.sock.fileno())

    @staticmethod
    def _parse_csv_upper(raw: str) -> list[str]:
        return [token.strip().upper() for token in raw.split(",") if token.strip()]


def _extract_ts(payload: dict[str, Any]) -> float:
    """Extract event timestamp with robust fallback."""
    raw = payload.get("timestamp")
    if raw is None:
        return time.time()
    try:
        return float(raw)
    except (TypeError, ValueError):
        return time.time()
