# EduMatcher Operational Scripts

This directory contains operational scripts for starting and stopping a named
EduMatcher process profile. The main entry point is `pm-opctl-cli`.

## `pm-opctl-cli`

Run it from the repository checkout with Python or Poetry:

```bash
poetry run pm-opctl-cli start
poetry run pm-opctl-cli start micro
poetry run pm-opctl-cli list
poetry run pm-opctl-cli health
poetry run pm-opctl-cli stop
poetry run pm-opctl-cli init
```

When installed as an executable, the same commands are:

```bash
pm-opctl-cli start
pm-opctl-cli start micro
pm-opctl-cli list
pm-opctl-cli health
pm-opctl-cli stop
pm-opctl-cli kill
pm-opctl-cli init
```

`start` without a name starts the `default` profile. When no
`<DATA-DIR>/emo-config.yaml` exists, the built-in `default`, `mini` and
`micro` profiles are available. When the file exists, its profiles replace the built-ins and a
missing `default` profile is supplied from the built-in nominal profile.

`init` writes all built-in profiles (`default`, `micro`, and `mini`) to
`<DATA-DIR>/emo-config.yaml` as a starting point for customization. It refuses
to overwrite an existing file and returns a nonzero exit code; remove or move
the existing file explicitly before creating a fresh one.

The `default` profile starts a full nominal exchange stack. The `mini` profile
starts a trading-capable subset with external access but no audit or clearing.
The `micro` profile starts only centralized logging and the engine.
Processes are launched from the repository root, inherit the
current environment (including `EDUMATCHER_DATA_DIR`), and write their combined
stdout/stderr to `<DATA-DIR>/emo/<process>.log`. PID files are kept beside them.

`stop` stops only processes that `pm-opctl-cli` recorded in its PID directory. It
does not search for or terminate unrelated processes with the same executable
name.

`kill` is an emergency command. It runs:

```bash
pkill -15 -f -i -l 'pm-'
```

This sends signal 15 (`SIGTERM`) to every process whose full command line
contains `pm-`, including processes not started by `pm-opctl-cli`. Use it only when
you intentionally want to stop the entire EduMatcher process group. It also
clears `pm-opctl-cli`'s persisted PID and active-profile state. A result with no
matching processes is treated as success.

`list` reads the active profile recorded by `start` and prints one status row
per configured process. The markers are:

- green `✓` — the PID is alive and, if configured, its `healthcheck` passed or
  its `tcp` address accepted a connection
- red `✗` — the PID is no longer alive
- yellow `⚠` — the PID is alive but its configured `healthcheck` or `tcp` check
  failed or timed out

`health` runs the same checks as `list` but is meant for scripting: it prints
a compact per-process line plus an overall `health: OK`/`health: FAIL` line,
and exits `0` only when every process in the active profile is `running`
(exits `1` otherwise, including when no profile is active). Pass `-q`/`--quiet`
to suppress all output and rely on the exit code alone, e.g. in a monitoring
cron job:

```bash
poetry run pm-opctl-cli health -q || alert "pm-opctl-cli profile unhealthy"
```

There is no generic, reliable way to determine whether an arbitrary process is
internally hung. Two optional per-process checks upgrade the liveness report
from "PID exists" to something closer to "is responding":

- `tcp: "host:port"` — the cheapest useful check for a process that binds a
  ZMQ or TCP socket (engine, log server, gateways). `pm-opctl-cli` attempts a plain
  `socket.create_connection()` with a short (0.3s) timeout and immediately
  closes it; a successful connect is reported as `running`, a refused or
  timed-out connect as `not responding`. **Caveat:** libzmq's I/O thread
  accepts TCP connections independently of the application's own processing
  loop, so a successful connect proves the process is alive and bound to the
  port, but does not prove its message loop is unstuck. Treat it as a cheap
  "is it alive and listening" signal, not a full liveness guarantee.
- `healthcheck` — a command that returns exit code `0` when the process is
  responsive, for a stronger, application-level check where one exists (e.g.
  `pm-stats-cli health -q`, or an HTTP health endpoint via `curl --fail`).

When both `tcp` and `healthcheck` are configured for the same process,
`healthcheck` takes precedence since it is the stronger signal; `tcp` is used
only when no `healthcheck` is configured. When neither is configured, an alive
PID is reported as `running` with no further detail.

```yaml
default:
	processes:
		- name: api-desk
			command: [pm-api-gwy, --verbose, --instance, desk]
			tcp: "127.0.0.1:8080"
			healthcheck: [curl, --fail, --silent, http://127.0.0.1:8080/api/v1/health]
```

Healthchecks are executed with a two-second timeout and do not inherit stdin.
They should be read-only and inexpensive. For processes without a suitable
`tcp` address or health endpoint, `list`/`health` can only report process
liveness, not application health.

The built-in profiles configure `tcp` using each process's conventional bind
address: `pm-log-srv` 5600, `pm-engine` 5555, `pm-md-gwy` 5570, `pm-ralf-gwy`
5580, `pm-dc-gwy` 5590, `pm-alf-gwy` 5565, `pm-balf-gwy` 5560, and `pm-api-gwy`
8080/8081 for the `desk`/`dashboards` instances. Processes that only subscribe
to the bus (`pm-audit`, `pm-stats`, `pm-clearing`, `pm-scheduler`) do not bind
a socket and have no `tcp` entry.

## Process configuration

The optional configuration file is:

```text
<DATA-DIR>/emo-config.yaml
```

It maps profile names to process lists. A profile can be written either as a
mapping containing `processes`, or directly as a list:

```yaml
default:
	processes:
		- name: log
			command: [pm-log-srv]
		- name: audit
			command: [pm-audit]
		- name: stats
			command: [pm-stats]
		- name: clearing
			command: [pm-clearing]
		- name: engine
			command: [pm-engine, --verbose]
		- name: scheduler
			command: [pm-scheduler]
		- name: market-data
			command: [pm-md-gwy]
		- name: api
			command: [pm-api-gwy, --instance, desk]

micro:
	processes:
		- name: log
			command: pm-log-srv
		- name: engine
			command: "pm-engine --verbose"
		- name: trader
			command: "pm-alf-console --id TRADER01 --verbose"
```

Each process entry has:

| Field | Required | Meaning |
|---|---:|---|
| `name` | yes | Unique PID/log identifier within the profile |
| `command` | yes | Either a YAML list of argv tokens or a shell-like command string; it is launched without a shell |
| `healthcheck` | no | Optional YAML command list or shell-like string; exit code `0` means responsive |
| `tcp` | no | Optional `"host:port"` string; a successful connect means responsive (see caveat above) |

The command must be available on `PATH`. Use `poetry run` explicitly in a
command when the profile is launched with plain Python, or run the script as
`poetry run pm-opctl-cli ...` so installed project commands are
available from the Poetry environment.

The profile format is deliberately small so future commands can reuse the same
profile loader. A future `status` command can read the same PID files and
compare them with the selected profile without changing the YAML format.

## Data directory

`pm-opctl-cli` follows the project data-directory convention:

1. `EDUMATCHER_DATA_DIR`, when set.
2. `<repo>/src/data` when this script is in a source checkout.
3. `~/.local/share/edumatcher` otherwise.

All processes in a profile inherit the same data-directory environment. Deploy
the configuration before starting a profile:

```bash
poetry run pm-config-deploy engine_config.yaml
poetry run pm-opctl-cli start micro
```

