"""
Message envelope helpers for ZeroMQ pub/sub and push/pull.

All messages are multipart ZMQ frames:
  frame[0]: topic (bytes) — used for PUB/SUB filtering
  frame[1]: JSON payload  (bytes)

Topic conventions
-----------------
  order.new          — gateway → engine (PUSH/PULL, but we still include a topic for audit)
  order.cancel       — gateway → engine
    system.gateway_connect   — gateway → engine: authenticate gateway_id
    system.gateway_auth.{GW_ID} — engine → all: auth accepted/rejected (connect)
    system.gateway_disconnect — gateway → engine: graceful disconnect
    system.gateway_bye.{GW_ID} — engine → all: disconnect broadcast
  order.ack.{GW_ID}  — engine → gateway: accepted or rejected
  order.fill.{GW_ID} — engine → gateway: partial or full fill
  order.cancelled.{GW_ID} — engine → gateway: cancel confirmed
  order.expired.{GW_ID}   — engine → gateway: DAY order expired at shutdown
  trade.executed     — engine → all subscribers
  book.{SYMBOL}      — engine → all subscribers
"""

from __future__ import annotations

import time
from collections.abc import Mapping
from typing import Any

# Imported as a MODULE, not by name, and so is this module's counterpart import
# inside the generated file. The two import each other: generated code needs
# encode/decode/dumps from here, and make_trade_msg below delegates to there.
# Binding module objects keeps that cycle harmless, because neither side needs
# the other's contents until call time. Importing `make_trade_executed` by name
# instead would raise ImportError whenever the generated module happened to be
# imported first.
from edumatcher.models.generated import admin as _gen_admin
from edumatcher.models.generated import auction as _gen_auction
from edumatcher.models.generated import book as _gen_book
from edumatcher.models.generated import index as _gen_index
from edumatcher.models.generated import log as _gen_log
from edumatcher.models.generated import order as _gen_order
from edumatcher.models.generated import quote as _gen_quote
from edumatcher.models.generated import risk as _gen_risk
from edumatcher.models.generated import session as _gen_session
from edumatcher.models.generated import structure as _gen_structure
from edumatcher.models.generated import system as _gen_system
from edumatcher.models.generated import trade as _gen_trade

# PERF improvement #6: Use orjson instead of stdlib json.
#
# orjson is a C-extension JSON serializer that is ~9-10x faster than
# json.dumps().encode() for the dict sizes used in our message envelopes
# (~10-15 keys).  With 2-4 encode() calls per order on the hot path,
# switching from json (~2.1µs/call) to orjson (~0.22µs/call) saves
# ~4-7µs per aggressive order.  orjson.dumps() returns bytes directly,
# eliminating the extra .encode() step required by stdlib json.
#
# For decode (inbound messages from gateways), orjson.loads() is similarly
# faster, but decode is not on the latency-critical path since the gateway
# already parsed the user command before sending.
try:
    import orjson as _json_mod

    def _dumps(obj: dict[str, Any]) -> bytes:
        return _json_mod.dumps(obj)

    def _loads(data: bytes) -> dict[str, Any]:
        return _json_mod.loads(data)  # type: ignore[no-any-return]

except ImportError:
    # Fallback to stdlib json if orjson is not installed (e.g. minimal envs)
    import json as _json_fallback

    def _dumps(obj: dict[str, Any]) -> bytes:
        return _json_fallback.dumps(obj).encode()

    def _loads(data: bytes) -> dict[str, Any]:
        return _json_fallback.loads(data)  # type: ignore[no-any-return]


def encode(topic: str, payload: dict[str, Any]) -> list[bytes]:
    """Return a two-frame ZMQ multipart message."""
    return [topic.encode(), _dumps(payload)]


def decode(frames: list[bytes]) -> tuple[str, dict[str, Any]]:
    """Parse a ZMQ multipart message.

    Reads only the topic and payload frames. Publishers append a third frame
    carrying a per-topic sequence number (see ``messaging/bus.py``); it is
    ignored here so every subscriber keeps working unchanged. Use
    :func:`decode_sequence` to read it.
    """
    topic = frames[0].decode()
    payload = _loads(frames[1])
    return topic, payload


def decode_sequence(frames: list[bytes]) -> int | None:
    """Return the publisher's per-topic sequence number, if the frame is there.

    ``None`` means the message came from a publisher that does not stamp
    sequences, so the receiver cannot tell whether anything was dropped.
    """
    if len(frames) < 3:
        return None
    try:
        return int(frames[2])
    except (ValueError, TypeError):
        return None


def dumps(payload: dict[str, Any]) -> bytes:
    """Public JSON serializer for payloads used in fast-path message publishing."""
    return _dumps(payload)


def make_order_new_msg(order_dict: dict[str, Any]) -> list[bytes]:
    return _gen_order.make_order_new(**order_dict)


def make_order_new_unchecked_msg(order_dict: dict[str, Any]) -> list[bytes]:
    """Same frames as :func:`make_order_new_msg`, without ``validate()``.

    For a caller that has already validated every field itself and is hot
    enough to care — today that is the ALF gateway's single-order path alone,
    and ``_unchecked``'s own docstring asks that it stay that way.

    Most of what this saves is not the validation. The validating builder goes
    dict → ``OrderNew`` → ``validate()`` → dict; this one builds the payload
    directly. Measured on one order: 7 349 ns against 2 364 ns, of which
    ``validate()`` is 355 ns and the dataclass round trip is the other 4 630.
    The generator guarantees the two emit byte-identical frames for any input,
    and ``test_alf_gwy_wire_bounds.py`` holds that guarantee to it.
    """
    return _gen_order.make_order_new_unchecked(**order_dict)


def make_gateway_connect_msg(gateway_id: str) -> list[bytes]:
    return _gen_system.make_gateway_connect(gateway_id=gateway_id)


def make_gateway_auth_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    description: str = "",
) -> list[bytes]:
    """Engine → all subscribers: a participant's connection verdict.

    ``gateway_id`` is in the topic *and* the body; the spec enumerates the
    body fields rather than taking the default projection, which would have
    dropped it (design section 26.4).
    """
    return _gen_system.make_gateway_auth(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        description=description,
    )


def make_order_cancel_msg(
    order_id: str, gateway_id: str, request_tag: str | None = None
) -> list[bytes]:
    return _gen_order.make_order_cancel(
        order_id=order_id,
        gateway_id=gateway_id,
        request_tag=request_tag,
    )


def make_order_amend_msg(
    order_id: str,
    gateway_id: str,
    price: float | None = None,
    qty: int | None = None,
    request_tag: str | None = None,
) -> list[bytes]:
    # The generated builder omits price/qty when None, matching the former
    # hand-rolled regime-3 conditional exactly (verified byte-identical).
    return _gen_order.make_order_amend(
        order_id=order_id,
        gateway_id=gateway_id,
        price=price,
        qty=qty,
        request_tag=request_tag,
    )


def make_amended_msg(
    gateway_id: str,
    order_id: str,
    price: float | None,
    qty: int,
    remaining_qty: int,
    priority_reset: bool,
    client_tag: str | None = None,
    request_tag: str | None = None,
) -> list[bytes]:
    """Generated from ``spec/messages/order.yaml``. Byte-identical to before."""
    return _gen_order.make_order_amended_unchecked(
        gateway_id=gateway_id,
        order_id=order_id,
        price=price,
        qty=qty,
        remaining_qty=remaining_qty,
        priority_reset=priority_reset,
        client_tag=client_tag,
        request_tag=request_tag,
    )


#: Identifiers that tie an order to the structure it belongs to. Carried on
#: every ack/fill/cancel/expiry so a consumer can attribute an event without
#: joining it against its own record of the parent order — which it may not
#: have after a reconnect, and which is exactly the state-stitching that made
#: these events awkward to consume.
GROUP_ID_FIELDS = ("oco_group_id", "combo_parent_id", "quote_id", "leg_index")


def order_client_tag(
    client_tag: str | None, order: dict[str, Any] | None
) -> str | None:
    """Resolve the ``client_tag`` for a lifecycle event about *order*.

    An explicit argument wins; otherwise the tag comes from the order itself.

    This exists because the three lifecycle builders below used to disagree
    about it. ``make_ack_msg`` read the tag off ``order``; ``make_cancelled_msg``
    and ``make_expired_msg`` took the same ``order`` argument, used it only for
    group ids, and left ``client_tag`` at its ``None`` default. Seven
    engine-initiated cancels and every expiry therefore reached clients
    untagged - not because anyone decided they should be, but because two
    builders with near-identical signatures behaved differently and said
    nothing about it. Sourcing the tag in one place is what stops the next
    caller from having to know which builder it is talking to.
    """
    if client_tag is not None:
        return client_tag
    if not order:
        return None
    tag = order.get("client_tag")
    return None if tag is None else str(tag)


def group_ids(order: dict[str, Any] | None) -> dict[str, Any]:
    """Extract the group identifiers present on *order*.

    Absent keys are omitted rather than emitted as ``null``: an ordinary
    single order carries none of these, and its events should not grow four
    empty fields to say so.
    """
    if not order:
        return {}
    return {
        field: order[field] for field in GROUP_ID_FIELDS if order.get(field) is not None
    }


def make_ack_msg(
    gateway_id: str,
    order_id: str,
    accepted: bool,
    reason: str = "",
    *,
    reject_code: _gen_order.OrderAckRejectCode | None = None,
    client_tag: str | None = None,
    request_tag: str | None = None,
    order: dict[str, Any] | None = None,
) -> list[bytes]:
    """Generated from ``spec/messages/order.yaml``.

    One wire change against the hand-written builder it replaces: a MARKET
    order's ack no longer carries ``"price": null``, because the spec declares
    ``price`` omitted-when-none like every other optional field. Invisible to
    readers, which all use ``.get`` - see design section B.7.2.
    """
    detail = order or {}
    return _gen_order.make_order_ack_unchecked(
        gateway_id=gateway_id,
        order_id=order_id,
        accepted=accepted,
        reason=reason,
        reject_code=reject_code,
        symbol=detail.get("symbol"),
        side=detail.get("side"),
        order_type=detail.get("order_type"),
        tif=detail.get("tif"),
        qty=detail.get("quantity"),
        price=detail.get("price"),
        client_tag=order_client_tag(client_tag, order),
        request_tag=request_tag,
        **group_ids(order),
    )


def make_fill_msg(
    gateway_id: str,
    order_id: str,
    fill_qty: int,
    fill_price: float,
    remaining_qty: int,
    status: str,
    order: dict[str, Any] | None = None,
    trade_ids: list[str] | None = None,
    *,
    liquidity_flag: _gen_order.OrderFillLiquidityFlag | None = None,
) -> list[bytes]:
    """Generated from ``spec/messages/order.yaml``.

    Same one wire change as ``make_ack_msg``: a MARKET order's fill no longer
    carries ``"price": null``. ``trade_ids`` are the public trade.executed ids
    that composed this fill (one, or several for a swept VWAP fill).
    ``liquidity_flag`` is ``TAKER`` for the aggressor side and ``MAKER`` for
    the resting side (G9) -- keyword-only, matching ``cancel_reason`` on
    ``make_cancelled_msg``, so it cannot be confused with the positionals
    above it. None only for a fill with no trade behind it.
    """
    detail = order or {}
    return _gen_order.make_order_fill_unchecked(
        gateway_id=gateway_id,
        order_id=order_id,
        fill_qty=fill_qty,
        fill_price=fill_price,
        remaining_qty=remaining_qty,
        status=status,
        symbol=detail.get("symbol"),
        side=detail.get("side"),
        order_type=detail.get("order_type"),
        tif=detail.get("tif"),
        qty=detail.get("quantity"),
        price=detail.get("price"),
        client_tag=detail.get("client_tag"),
        trade_ids=list(trade_ids) if trade_ids else [],
        liquidity_flag=liquidity_flag,
        **group_ids(order),
    )


def make_cancelled_msg(
    gateway_id: str,
    order_id: str,
    client_tag: str | None = None,
    request_tag: str | None = None,
    order: dict[str, Any] | None = None,
    *,
    cancel_reason: _gen_order.OrderCancelledCancelReason | None = None,
) -> list[bytes]:
    """Generated from ``spec/messages/order.yaml``.

    ``cancel_reason`` says why the *exchange* cancelled the order and is None
    for a client-requested cancel; it is keyword-only so it cannot be confused
    with the two tag positionals above it.
    """
    return _gen_order.make_order_cancelled_unchecked(
        gateway_id=gateway_id,
        order_id=order_id,
        client_tag=order_client_tag(client_tag, order),
        request_tag=request_tag,
        cancel_reason=cancel_reason,
        **group_ids(order),
    )


def make_expired_msg(
    gateway_id: str,
    order_id: str,
    client_tag: str | None = None,
    order: dict[str, Any] | None = None,
) -> list[bytes]:
    """Generated from ``spec/messages/order.yaml``. Byte-identical to before."""
    return _gen_order.make_order_expired_unchecked(
        gateway_id=gateway_id,
        order_id=order_id,
        client_tag=order_client_tag(client_tag, order),
        **group_ids(order),
    )


def make_trade_msg(trade_dict: dict[str, Any]) -> list[bytes]:
    """Build the ``trade.executed`` frames from a payload dict.

    Generated from ``spec/messages/trade.yaml``. The frames are byte-identical
    to what this function produced when it built them by hand, but it now also
    **validates**: a payload with a price of 0, or an ``aggressor_side``
    outside ``BUY``/``SELL``/``AUCTION``, raises ``MessageValidationError``
    (a ``ValueError``) instead of being published. Producers are held to the
    contract; readers of historical data should use
    ``generated.trade.TradeExecuted.from_dict``, which coerces without
    validating. See ``docs/developer/06-msgen.md``.
    """
    return _gen_trade.make_trade_executed(**trade_dict)


def make_book_msg(symbol: str, book_snapshot: dict[str, Any]) -> list[bytes]:
    # The builder takes the topic's symbol from the payload, which the engine
    # always fills from the same book as ``symbol``.
    return _gen_book.make_book_snapshot(**book_snapshot)


def make_orders_request_msg(gateway_id: str) -> list[bytes]:
    return _gen_order.make_orders_request(gateway_id=gateway_id)


def make_orders_msg(gateway_id: str, orders: list[dict[str, Any]]) -> list[bytes]:
    return _gen_order.make_orders(gateway_id=gateway_id, orders=orders)


def make_price_level_orders_request_msg(
    gateway_id: str, symbol: str, price: float | None = None
) -> list[bytes]:
    """ADMIN -> engine: every resting order for *symbol* across every
    gateway, optionally narrowed to one *price* level. See
    spec/messages/order.yaml's price_level_orders_request for the
    rejection semantics (non-ADMIN callers get an empty, rejected=True
    reply rather than this request failing to build)."""
    kwargs: dict[str, Any] = {"gateway_id": gateway_id, "symbol": symbol.upper()}
    if price is not None:
        kwargs["price"] = price
    return _gen_order.make_price_level_orders_request(**kwargs)


def make_price_level_orders_msg(
    gateway_id: str,
    symbol: str,
    orders: list[dict[str, Any]],
    *,
    price: float | None = None,
    rejected: bool = False,
    reason: str = "",
) -> list[bytes]:
    """Engine -> ADMIN caller: reply to price_level_orders_request."""
    kwargs: dict[str, Any] = {
        "gateway_id": gateway_id,
        "symbol": symbol.upper(),
        "rejected": rejected,
        "orders": orders,
    }
    if price is not None:
        kwargs["price"] = price
    if reason:
        kwargs["reason"] = reason
    return _gen_order.make_price_level_orders(**kwargs)


def make_book_snapshot_request_msg(symbol: str) -> list[bytes]:
    return _gen_book.make_book_snapshot_request(symbol=symbol)


def make_eod_msg(books: list[dict[str, Any]]) -> list[bytes]:
    """
    End-of-day broadcast — engine sends this before shutting down.
    ``books`` is a list of book snapshots (one per symbol), each containing
    the current best bid/ask so subscribers can record closing prices.

    A full ``OrderBook.snapshot()`` may be passed: ``EodBook`` declares the
    five keys end of day carries and ``from_dict`` drops the rest, which is
    the trim ``SystemEodPayload`` used to perform without saying so.
    """
    return _gen_system.make_eod(books=books)


def make_symbols_request_msg(gateway_id: str) -> list[bytes]:
    return _gen_system.make_symbols_request(gateway_id=gateway_id)


def make_symbols_msg(
    gateway_id: str,
    symbols: list[dict[str, Any]],
) -> list[bytes]:
    """Engine → caller: the tradable instruments and this caller's terms.

    One collection. ``symbols`` used to be a list of strings beside a parallel
    ``symbol_meta`` map keyed by those same strings, built in the same loop;
    each entry is now one ``SymbolInfo`` record carrying its own symbol.
    """
    return _gen_system.make_symbols(gateway_id=gateway_id, symbols=symbols)


def make_quote_bootstrap_request_msg(gateway_id: str, symbol: str = "") -> list[bytes]:
    """Gateway -> engine: request active quote bootstrap state."""
    return _gen_system.make_quote_bootstrap_request(
        gateway_id=gateway_id, symbol=symbol.upper()
    )


def make_quote_bootstrap_msg(
    gateway_id: str, quotes: list[dict[str, Any]]
) -> list[bytes]:
    """Engine -> gateway: reply with active quote bootstrap state."""
    return _gen_system.make_quote_bootstrap(gateway_id=gateway_id, quotes=quotes)


def make_quote_legs_request_msg(
    gateway_id: str, symbol: str = "", show: str = "ALL"
) -> list[bytes]:
    """Gateway -> engine: request quote leg snapshot (QLEGS)."""
    return _gen_system.make_quote_legs_request(
        gateway_id=gateway_id, symbol=symbol.upper(), show=show.upper()
    )


def make_quote_legs_msg(
    gateway_id: str,
    legs: list[dict[str, Any]],
    *,
    show_requested: str = "ACTIVE",
    complete: bool = True,
    recent: list[dict[str, Any]] | None = None,
) -> list[bytes]:
    """Engine -> gateway: reply with quote legs snapshot.

    *legs* is the currently-active per-leg detail (qty, remaining, status)
    — populated when *show_requested* is ``"ACTIVE"`` or ``"ALL"``.

    *recent* is a bounded, most-recently-removed-first list of quote-level
    summaries (quote_id, symbol, leg order ids, final quote_status, removal
    *reason*, and *removed_at_ns*) drawn from the engine's in-memory,
    per-gateway inactivation history — populated when *show_requested* is
    ``"RECENT"`` or ``"ALL"``. Unlike *legs*, recent rows do not carry live
    qty/remaining/status: that detail is not retained once an order leaves
    the book. This history does not survive an engine restart.

    *complete* is ``True`` when the reply fully answers what was requested
    (always true for ``ACTIVE``; also true for ``RECENT``/``ALL`` now that
    real history is tracked, modulo the history buffer's bound).
    """
    return _gen_system.make_quote_legs(
        gateway_id=gateway_id,
        legs=legs,
        show_requested=show_requested,
        complete=complete,
        recent=recent or [],
    )


# ------------------------------------------------------------------
# Session-status query (read current state without advancing it)
# ------------------------------------------------------------------


def make_session_state_request_msg(gateway_id: str) -> list[bytes]:
    """Operator → engine: request the current session state."""
    return _gen_system.make_session_state_request(gateway_id=gateway_id)


def make_session_status_msg(
    gateway_id: str,
    state: str,
    sessions_enabled: bool,
) -> list[bytes]:
    """Engine → operator: reply with the current session state."""
    return _gen_system.make_session_status(
        gateway_id=gateway_id, state=state, sessions_enabled=sessions_enabled
    )


# ------------------------------------------------------------------
# Session schedule query
# ------------------------------------------------------------------


def make_session_schedule_request_msg(gateway_id: str) -> list[bytes]:
    """Operator → engine: request the session schedule configuration."""
    return _gen_system.make_session_schedule_request(gateway_id=gateway_id)


def make_session_schedule_msg(
    gateway_id: str,
    sessions_enabled: bool,
    schedule: dict[str, Any] | None,
) -> list[bytes]:
    """Engine → operator: reply with the session schedule configuration.

    ``schedule`` is the same ``SessionTimes`` record ``system.reference``
    carries. It is ``None`` — not ``{}`` — when no ``schedule:`` block is
    configured: one spelling of the absence rather than two.
    """
    return _gen_system.make_session_schedule(
        gateway_id=gateway_id,
        sessions_enabled=sessions_enabled,
        schedule=schedule,
    )


# ------------------------------------------------------------------
# Compiled reference data (tick sizes, risk levels, circuit breaker
# ladders, schedule, indexes) — static, changes only on reload.
# ------------------------------------------------------------------


def make_reference_request_msg(gateway_id: str) -> list[bytes]:
    """Any caller → engine: request the compiled reference-data bundle."""
    return _gen_system.make_reference_request(gateway_id=gateway_id)


def make_reference_msg(
    gateway_id: str,
    *,
    symbols: list[dict[str, Any]],
    risk: dict[str, Any],
    indexes: list[dict[str, Any]],
    schedule: dict[str, Any],
    config_version: str | None,
) -> list[bytes]:
    """Engine → caller: reply with the compiled reference-data bundle.

    Named parameters rather than the single ``reference: dict[str, Any]`` this
    replaces. ``from_dict`` reads declared keys only, so routing an open dict
    through a generated builder would silently drop anything the spec does not
    declare — the hazard design section 27.2 found on ``drop_copy``, where
    adoption under the old signature would have made the wire *less* safe.

    The bundle is always complete. Before an engine config is loaded it used to
    be ``{"config_version": None}`` and nothing else, a second payload shape
    every slicing endpoint compensated for with ``.get(key, {})``.
    """
    return _gen_system.make_reference(
        gateway_id=gateway_id,
        symbols=symbols,
        risk=risk,
        indexes=indexes,
        schedule=schedule,
        config_version=config_version,
    )


def make_reference_reload_msg(gateway_id: str, command_id: str) -> list[bytes]:
    """ADMIN → engine: request a reload of static reference data from disk."""
    return _gen_system.make_reference_reload(
        gateway_id=gateway_id, command_id=command_id
    )


def make_reference_reload_ack_msg(
    gateway_id: str,
    command_id: str,
    accepted: bool,
    config_version: str | None = None,
    reason: str | None = None,
) -> list[bytes]:
    """Engine → ADMIN: reload verdict."""
    return _gen_system.make_reference_reload_ack(
        gateway_id=gateway_id,
        command_id=command_id,
        accepted=accepted,
        config_version=config_version,
        reason=reason,
    )


# ------------------------------------------------------------------
# Live per-symbol risk state (collar reference price, circuit-breaker
# reference/trigger/expansion state) — distinct from the *static* risk
# definitions in the reference-data bundle.
# ------------------------------------------------------------------


def make_risk_state_request_msg(gateway_id: str) -> list[bytes]:
    """ADMIN → engine: request live per-symbol risk state."""
    return _gen_system.make_risk_state_request(gateway_id=gateway_id)


def make_risk_state_msg(gateway_id: str, symbols: list[dict[str, Any]]) -> list[bytes]:
    """Engine → ADMIN: reply with live per-symbol risk state.

    One `SymbolRiskState` record per symbol, carrying its own symbol. This was
    a map keyed by symbol, and the corridor inside each entry was a box named
    `corridor` holding keys named `corridor_low`/`corridor_high` -- the prefix
    and the box saying the same thing twice, from a helper that splats the
    same three values *flat* into `circuit_breaker.halt`. Flat here too, so
    one producer emits one shape.
    """
    return _gen_system.make_risk_state(gateway_id=gateway_id, symbols=symbols)


# ------------------------------------------------------------------
# Gateway-list query
# ------------------------------------------------------------------


def make_gateways_request_msg(gateway_id: str) -> list[bytes]:
    """Operator → engine: request the list of configured gateways."""
    return _gen_system.make_gateways_request(gateway_id=gateway_id)


def make_gateways_msg(
    gateway_id: str,
    gateways: list[dict[str, Any]],
) -> list[bytes]:
    """Engine → operator: reply with configured gateways and connection status."""
    return _gen_system.make_gateways(gateway_id=gateway_id, gateways=gateways)


# ------------------------------------------------------------------
# Daily volume query
# ------------------------------------------------------------------


def make_volume_request_msg(gateway_id: str) -> list[bytes]:
    """Operator → engine: request daily traded volume."""
    return _gen_system.make_volume_request(gateway_id=gateway_id)


def make_volume_msg(
    gateway_id: str,
    symbols: list[dict[str, Any]],
    total_qty: int,
    total_value: float,
    total_trades: int,
) -> list[bytes]:
    """Engine → operator: reply with daily volume data."""
    return _gen_system.make_volume(
        gateway_id=gateway_id,
        symbols=symbols,
        total_qty=total_qty,
        total_value=total_value,
        total_trades=total_trades,
    )


# ------------------------------------------------------------------
# Combo-order messages
# ------------------------------------------------------------------


def make_combo_order_msg(combo_dict: dict[str, Any]) -> list[bytes]:
    """Gateway → engine: submit a combo order."""
    return _gen_order.make_order_combo(**combo_dict)


def make_combo_cancel_msg(combo_id: str, gateway_id: str) -> list[bytes]:
    """Gateway → engine: cancel a combo and all its child legs."""
    return _gen_order.make_order_combo_cancel(combo_id=combo_id, gateway_id=gateway_id)


def make_combo_ack_msg(
    gateway_id: str,
    combo_id: str,
    accepted: bool,
    reason: str = "",
) -> list[bytes]:
    """Engine → gateway: combo accepted or rejected.

    Carried a full ``ComboOrder.to_dict()`` state dump until the submission,
    event and persistence shapes were separated. No consumer ever read it —
    alf_console, alf_gwy, pm-stats and the api_gateway event stream all take
    only ``combo_id``, ``accepted`` and ``reason``.
    """
    return _gen_structure.make_combo_ack(
        gateway_id=gateway_id,
        combo_id=combo_id,
        accepted=accepted,
        reason=reason,
    )


def make_combo_status_msg(
    gateway_id: str,
    combo_id: str,
    status: str,
    reason: str = "",
) -> list[bytes]:
    """Engine → gateway: combo status transition (MATCHED / FAILED / etc.).

    ``reason`` replaced a ``details`` mapping that only ever carried one key,
    always ``"reason"`` — and which both consumers unwrapped on arrival with
    ``details.get("reason")``. Design section 15.4 excludes maps because a
    spec that appears to need one is describing a message that should have
    been simpler; this was the thinnest possible instance of that.
    """
    return _gen_structure.make_combo_status(
        gateway_id=gateway_id,
        combo_id=combo_id,
        status=status,
        reason=reason,
    )


# ---------------------------------------------------------------------------
# Session / auction messages
# ---------------------------------------------------------------------------


def make_session_transition_msg(
    to_state: str,
    next_state: str = "",
    next_at: str = "",
    command_id: str = "",
    gateway_id: str = "",
) -> list[bytes]:
    """Scheduler → engine: request session state transition.

    ``next_state``/``next_at`` describe the transition *after* this one, so
    the engine can publish a countdown target the terminal can render. Only
    the scheduler knows the day's timetable, and only the process that will
    actually perform the next transition has any business asserting when it
    happens — a manual transition omits them, which clears any stale target
    the engine was holding.

    ``command_id``/``gateway_id`` are supplied by an *interactive* requester
    that wants to know the outcome. When both are present the engine replies
    on ``session.transition_ack.{gateway_id}``. `pm-scheduler` omits them: it
    drives the timetable and has nobody to report back to, and the public
    ``session.state`` broadcast already tells it what happened.
    """
    payload: dict[str, Any] = {"to_state": to_state}
    # Both-or-neither, expressed as a record rather than a pair of keys: a
    # phase without a time cannot be counted down to, and a time without a
    # phase does not say what happens.
    if next_state and next_at:
        payload["next"] = {"state": next_state, "at": next_at}
    if command_id and gateway_id:
        payload["reply_to"] = {"command_id": command_id, "gateway_id": gateway_id}
    return _gen_session.make_session_transition(**payload)


def make_session_transition_ack_msg(
    gateway_id: str,
    command_id: str,
    accepted: bool,
    to_state: str = "",
    reason: str = "",
) -> list[bytes]:
    """Engine → the requesting gateway: outcome of a transition request.

    Addressed to one requester rather than broadcast, because a
    ``command_id`` belongs to whoever issued it — putting it on the public
    ``session.state`` topic would hand every subscriber another operator's
    correlation id.

    This also closes a silent failure: a transition request that the engine
    discards (sessions disabled, unknown state) previously produced no reply
    of any kind, so a caller saw only a timeout and could not tell a rejected
    request from a slow one.
    """
    return _gen_session.make_session_transition_ack_unchecked(
        gateway_id=gateway_id,
        command_id=command_id,
        accepted=accepted,
        to_state=to_state,
        reason=reason,
    )


def make_session_state_msg(
    state: str, prev_state: str = "", next_state: str = "", next_at: str = ""
) -> list[bytes]:
    """Engine → all: broadcast current session state."""
    # The validating constructor, not an ``_unchecked`` one: a message with a
    # nested record has no dict-literal fast path (design section 15.5), and a
    # session transition happens a handful of times a day.
    return _gen_session.make_session_state(
        state=state,
        prev_state=prev_state,
        next=({"state": next_state, "at": next_at} if next_state and next_at else None),
    )


def make_auction_indicative_msg(
    symbol: str,
    phase: str,
    eq_price: float | None,
    eq_qty: int,
    imbalance_side: str,
    imbalance_qty: int,
) -> list[bytes]:
    """Engine → all: where a symbol *would* uncross, mid-call-phase.

    Published repeatedly while an opening or closing auction collects orders,
    which is the difference between this and ``auction.result``: that one
    reports what happened, this one reports what would happen if the phase
    ended now. Both are needed. A participant can only supply the offsetting
    interest that resolves an imbalance if the imbalance is visible while
    there is still time to act on it -- which is the reasoning
    ``normalise_cb_halt`` already applies to a reopening, and which holds
    with more force at the open and the close, where the largest volume of
    the day prints.

    ``eq_price`` is ``None`` when the book would not cross at all. That is a
    real and informative state during a call phase -- nothing would trade yet
    -- and is not the same as a price of zero.

    ``imbalance_side`` is ``""`` when the book is balanced, and the spec
    declares it an enum of BUY and SELL that omits when unset -- so the empty
    string becomes an absent key here. Every reader already defaults it
    through ``payload.get("imbalance_side", "")``.
    """
    return _gen_auction.make_auction_indicative(
        symbol=symbol,
        phase=phase,
        eq_price=eq_price,
        eq_qty=eq_qty,
        imbalance_side=imbalance_side or None,
        imbalance_qty=imbalance_qty,
    )


def make_auction_result_msg(
    symbol: str,
    eq_price: float | None,
    eq_qty: int,
    trades_count: int,
    imbalance_side: str,
    imbalance_qty: int,
    reason: str,
) -> list[bytes]:
    """Engine → all: auction uncross result for one symbol.

    ``reason`` says which uncross this was, because the four are otherwise
    indistinguishable to a consumer:

      ``SCHEDULED`` — leaving an auction or other non-matching session phase
      ``REOPEN``    — a halted symbol reopening at the end of its halt
      ``RECOVERY``  — restored GTC orders uncrossed at engine startup
      ``BACKSTOP``  — the closing backstop forcing a still-halted symbol to
                      reopen at the corridor boundary

    ``imbalance_side`` is ``""`` when balanced and omits — see
    ``make_auction_indicative_msg``.
    """
    return _gen_auction.make_auction_result(
        symbol=symbol,
        eq_price=eq_price,
        eq_qty=eq_qty,
        trades_count=trades_count,
        imbalance_side=imbalance_side or None,
        imbalance_qty=imbalance_qty,
        reason=reason,
    )


# ------------------------------------------------------------------
# OCO-order messages
# ------------------------------------------------------------------


def make_oco_order_msg(payload: dict[str, Any]) -> list[bytes]:
    """Gateway → engine: submit an OCO (One-Cancels-Other) pair."""
    return _gen_order.make_order_oco(**payload)


def make_oco_cancel_msg(oco_id: str, gateway_id: str) -> list[bytes]:
    """Gateway → engine: cancel an OCO pair and both its legs."""
    return _gen_order.make_order_oco_cancel(oco_id=oco_id, gateway_id=gateway_id)


def make_oco_ack_msg(
    gateway_id: str,
    oco_id: str,
    accepted: bool,
    reason: str = "",
    order_id_1: str = "",
    order_id_2: str = "",
) -> list[bytes]:
    """Engine → gateway: OCO pair accepted or rejected."""
    return _gen_structure.make_oco_ack(
        gateway_id=gateway_id,
        oco_id=oco_id,
        accepted=accepted,
        reason=reason,
        order_id_1=order_id_1,
        order_id_2=order_id_2,
    )


def make_oco_cancelled_msg(
    gateway_id: str, oco_id: str, cancelled_order_id: str, reason: str = ""
) -> list[bytes]:
    """Engine → gateway: OCO sibling cancelled because the other leg was actioned."""
    return _gen_structure.make_oco_cancelled(
        gateway_id=gateway_id,
        oco_id=oco_id,
        cancelled_order_id=cancelled_order_id,
        reason=reason,
    )


# ------------------------------------------------------------------
# MM quote / risk-control messages
# ------------------------------------------------------------------


def make_quote_new_msg(payload: dict[str, Any]) -> list[bytes]:
    """Gateway → engine: submit/replace two-sided quote for one symbol.

    Prices are **integer ticks**; the submitting gateway converts. They were
    display money until 6.1b, which is the one path design section 15.2 missed
    when it made ticks the sole engine-inbound unit — see section 25.2. Every
    producer builds it from the declared fields in ticks, so unlike
    ``order.new`` it routes through the validating builder, not an open
    ``encode``.
    """
    return _gen_quote.make_quote_new(**payload)


def make_quote_cancel_msg(gateway_id: str, symbol: str) -> list[bytes]:
    """Gateway → engine: cancel active quote for one symbol."""
    return _gen_quote.make_quote_cancel(gateway_id=gateway_id, symbol=symbol)


def make_quote_ack_msg(
    gateway_id: str,
    quote_id: str,
    accepted: bool,
    reason: str = "",
    bid_order_id: str = "",
    ask_order_id: str = "",
) -> list[bytes]:
    """Engine → gateway: quote accepted or rejected."""
    return _gen_quote.make_quote_ack(
        gateway_id=gateway_id,
        quote_id=quote_id,
        accepted=accepted,
        reason=reason,
        bid_order_id=bid_order_id,
        ask_order_id=ask_order_id,
    )


def make_quote_status_msg(
    gateway_id: str,
    quote_id: str,
    status: str,
    reason: str = "",
) -> list[bytes]:
    """Engine → gateway: quote lifecycle transition."""
    return _gen_quote.make_quote_status(
        gateway_id=gateway_id,
        quote_id=quote_id,
        status=status,
        reason=reason,
    )


def make_gateway_disconnect_msg(gateway_id: str, reason: str = "") -> list[bytes]:
    """Gateway → engine: graceful disconnect notification."""
    return _gen_system.make_gateway_disconnect(gateway_id=gateway_id, reason=reason)


def make_gateway_bye_msg(gateway_id: str, reason: str = "") -> list[bytes]:
    """
    Engine → all subscribers: gateway lifecycle *disconnect* broadcast.

    The PUB-side counterpart to ``system.gateway_auth.{id}`` (connect).  The
    inbound ``system.gateway_disconnect`` is a gateway→engine PULL message and
    never reaches PUB subscribers such as clearing; this broadcast republishes
    the disconnect on the public feed so downstream consumers can close the
    matching session.

    ``gateway_id`` is in the topic and the body; ``clearing`` — the only
    structural reader — takes it from the body, so the spec enumerates it.
    """
    return _gen_system.make_gateway_bye(gateway_id=gateway_id, reason=reason)


def make_kill_switch_msg(
    gateway_id: str, symbol: str = "", command_id: str = "", note: str = ""
) -> list[bytes]:
    """Gateway/admin → engine: cancel open risk-bearing exposure.

    ``command_id`` is echoed on the ack. Unlike the symbol halt/resume/cancel
    acks — which carry ``symbol`` and can therefore be told apart — a
    kill-switch ack has no natural identifier, so two concurrent mass cancels
    for one gateway were previously indistinguishable once both acks were in
    flight. Supplying it is optional; without it the ack is unchanged.

    ``note`` is free text recorded on the admin monitor. The engine's handler
    had always read one, but this builder had no parameter for it and none of
    the four producers sent one — so ``kill_switch.self`` was the only admin
    action whose note was permanently blank, while its two siblings recorded
    a real one (design section 22.2).
    """
    return _gen_risk.make_kill_switch(
        gateway_id=gateway_id,
        symbol=symbol,
        note=note,
        command_id=command_id,
    )


def make_kill_switch_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    cancelled_orders: int = 0,
    cancelled_quotes: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """Engine → gateway/admin: kill-switch result summary."""
    return _gen_risk.make_kill_switch_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        cancelled_orders=cancelled_orders,
        cancelled_quotes=cancelled_quotes,
        command_id=command_id,
    )


def make_circuit_breaker_halt_all_msg(gateway_id: str) -> list[bytes]:
    """Admin → engine: halt trading for all known symbols."""
    return _gen_risk.make_circuit_breaker_halt_all(gateway_id=gateway_id)


def make_circuit_breaker_halt_all_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    halted_symbols: int = 0,
    cancelled_quotes: int = 0,
) -> list[bytes]:
    """Engine → admin: global circuit-breaker halt result summary."""
    return _gen_risk.make_circuit_breaker_halt_all_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        halted_symbols=halted_symbols,
        cancelled_quotes=cancelled_quotes,
    )


def make_circuit_breaker_resume_all_msg(gateway_id: str) -> list[bytes]:
    """Admin → engine: resume trading for all symbols halted by global CB halt."""
    return _gen_risk.make_circuit_breaker_resume_all(gateway_id=gateway_id)


def make_circuit_breaker_resume_all_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    resumed_symbols: int = 0,
) -> list[bytes]:
    """Engine → admin: global circuit-breaker resume result summary."""
    return _gen_risk.make_circuit_breaker_resume_all_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        resumed_symbols=resumed_symbols,
    )


# ---------------------------------------------------------------------------
# Per-symbol halt / resume
# ---------------------------------------------------------------------------


def make_symbol_halt_msg(
    gateway_id: str,
    symbol: str,
    level: str | None = None,
    note: str = "",
    command_id: str = "",
) -> list[bytes]:
    """Admin → engine: halt trading on a single symbol (ADMIN role required).

    ``level``, when given, must name one of the symbol's configured
    ``circuit_breaker.levels`` — the halt then runs through the same
    ``CircuitBreakerState.activate()`` state machine a price-triggered halt
    uses (so it gets a real ``resume_at_ns``, ACE corridor, etc). Omitted or
    unmatched, the halt falls back to the previous behaviour: an indefinite
    halt with no timed resume, cleared only by an explicit resume.
    """
    return _gen_risk.make_symbol_halt(
        gateway_id=gateway_id,
        symbol=symbol.upper(),
        level=(level or "").upper(),
        note=note,
        command_id=command_id,
    )


def make_symbol_halt_ack_msg(
    gateway_id: str,
    symbol: str,
    accepted: bool,
    reason: str = "",
    cancelled_quotes: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """Engine → admin: per-symbol halt result."""
    return _gen_risk.make_symbol_halt_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        symbol=symbol,
        reason=reason,
        cancelled_quotes=cancelled_quotes,
        command_id=command_id,
    )


def make_symbol_resume_msg(
    gateway_id: str, symbol: str, note: str = "", command_id: str = ""
) -> list[bytes]:
    """Admin → engine: resume trading on a single halted symbol (ADMIN role required)."""
    return _gen_risk.make_symbol_resume(
        gateway_id=gateway_id,
        symbol=symbol.upper(),
        note=note,
        command_id=command_id,
    )


def make_symbol_resume_ack_msg(
    gateway_id: str,
    symbol: str,
    accepted: bool,
    reason: str = "",
    command_id: str = "",
) -> list[bytes]:
    """Engine → admin: per-symbol resume result."""
    return _gen_risk.make_symbol_resume_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        symbol=symbol,
        reason=reason,
        command_id=command_id,
    )


# ---------------------------------------------------------------------------
# Symbol-scoped mass cancel (across all gateways)
# ---------------------------------------------------------------------------


def make_cancel_symbol_msg(
    gateway_id: str, symbol: str, note: str = "", command_id: str = ""
) -> list[bytes]:
    """Admin → engine: cancel all resting orders for *symbol* across every gateway."""
    return _gen_risk.make_cancel_symbol(
        gateway_id=gateway_id,
        symbol=symbol.upper(),
        note=note,
        command_id=command_id,
    )


def make_cancel_symbol_ack_msg(
    gateway_id: str,
    symbol: str,
    accepted: bool,
    reason: str = "",
    cancelled_orders: int = 0,
    cancelled_quotes: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """Engine → admin: symbol-level mass-cancel result."""
    return _gen_risk.make_cancel_symbol_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        symbol=symbol,
        reason=reason,
        cancelled_orders=cancelled_orders,
        cancelled_quotes=cancelled_quotes,
        command_id=command_id,
    )


# ---------------------------------------------------------------------------
# Gateway-scoped and market-wide kill switch (ADMIN targeting another
# gateway, or every gateway at once) — distinct from risk.kill_switch, which
# only ever acts on the caller's own gateway_id.
# ---------------------------------------------------------------------------


def make_kill_switch_gateway_msg(
    gateway_id: str, target_gateway_id: str, note: str = "", command_id: str = ""
) -> list[bytes]:
    """ADMIN → engine: cancel every order/quote belonging to *target_gateway_id*.

    ``gateway_id`` is the ADMIN caller (for role/connection checks and the
    ack topic); ``target_gateway_id`` is whose exposure gets cancelled —
    unlike ``risk.kill_switch``, these are allowed to differ.
    """
    return _gen_risk.make_kill_switch_gateway(
        gateway_id=gateway_id,
        target_gateway_id=target_gateway_id.upper(),
        note=note,
        command_id=command_id,
    )


def make_kill_switch_gateway_ack_msg(
    gateway_id: str,
    target_gateway_id: str,
    accepted: bool,
    reason: str = "",
    cancelled_orders: int = 0,
    cancelled_quotes: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """Engine → ADMIN: gateway-targeted kill-switch result."""
    return _gen_risk.make_kill_switch_gateway_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        target_gateway_id=target_gateway_id,
        reason=reason,
        cancelled_orders=cancelled_orders,
        cancelled_quotes=cancelled_quotes,
        command_id=command_id,
    )


def make_kill_switch_global_msg(
    gateway_id: str, note: str = "", command_id: str = ""
) -> list[bytes]:
    """ADMIN → engine: cancel every resting order/quote for every gateway."""
    return _gen_risk.make_kill_switch_global(
        gateway_id=gateway_id,
        note=note,
        command_id=command_id,
    )


def make_kill_switch_global_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    cancelled_orders: int = 0,
    cancelled_quotes: int = 0,
    affected_gateways: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """Engine → ADMIN: market-wide kill-switch result."""
    return _gen_risk.make_kill_switch_global_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        cancelled_orders=cancelled_orders,
        cancelled_quotes=cancelled_quotes,
        affected_gateways=affected_gateways,
        command_id=command_id,
    )


# ---------------------------------------------------------------------------
# Synthetic admin-monitor-only event — published alongside (not instead of)
# each admin command's own ack, so /admin/monitor has one uniform shape to
# watch regardless of which command ran. Never routed to a trading client's
# private or market-data stream — see events.py's ADMIN_ACTION_PREFIX.
# ---------------------------------------------------------------------------


def make_admin_action_msg(
    gateway_id: str,
    command_id: str,
    action: str,
    scope: dict[str, Any],
    accepted: bool,
    reason: str = "",
) -> list[bytes]:
    """Engine → admin monitor: uniform record of one admin-gated command.

    ``gateway_id`` is the initiator (the ADMIN caller), ``action`` names the
    command (e.g. ``"circuit_breaker.trigger"``, ``"kill_switch.global"``),
    and ``scope`` says what it acted on and what it did.

    ``scope`` is a declared record, not the open map it used to be: the twelve
    producer sites draw on a closed set of seven keys and never anything else.
    A key outside that set is silently dropped by ``from_dict`` rather than
    rejected, so ``test_msgen_admin.py`` walks the engine's ``scope=`` literals
    and fails on an undeclared one. The docstring here used to offer
    ``index_id`` as an example and no producer has ever sent it.
    """
    return _gen_admin.make_admin_action(
        gateway_id=gateway_id,
        command_id=command_id,
        initiator_gateway_id=gateway_id,
        action=action,
        scope=scope,
        accepted=accepted,
        reason=reason,
    )


# ---------------------------------------------------------------------------
# Halt-status snapshot (request / reply)
# ---------------------------------------------------------------------------


def make_halt_status_request_msg(gateway_id: str) -> list[bytes]:
    """Any process → engine: request current halt state for all symbols."""
    return _gen_system.make_halt_status_request(gateway_id=gateway_id)


def make_halt_status_msg(
    gateway_id: str,
    halted: list[dict[str, Any]],
) -> list[bytes]:
    """Engine → requester: snapshot of currently halted symbols.

    Each entry in *halted* has:
      ``symbol`` (str), ``resume_at_ns`` (int | None),
      ``level`` (str | None), ``halt_source`` (str | None).
    An empty list means no symbols are currently halted.
    """
    return _gen_system.make_halt_status(gateway_id=gateway_id, halted=halted)


def make_position_request_msg(gateway_id: str) -> list[bytes]:
    """Any process → engine: request current position snapshot for *gateway_id*.

    The engine replies on ``system.position_snapshot.<GW_ID>``.
    """
    return _gen_system.make_position_request(gateway_id=gateway_id)


def make_position_snapshot_msg(
    gateway_id: str,
    positions: list[dict[str, Any]],
) -> list[bytes]:
    """Engine → requester: per-symbol position snapshot for *gateway_id*.

    Each entry in *positions* has:
      ``symbol`` (str), ``net_qty`` (int, positive = long / negative = short),
      ``avg_cost`` (float display price, 0.0 if flat).
    Only symbols with a non-zero net position are included.
    An empty list means the gateway is flat across all symbols.
    """
    return _gen_system.make_position_snapshot(
        gateway_id=gateway_id, positions=positions
    )


# ------------------------------------------------------------------
# Index messages
# ------------------------------------------------------------------


def make_index_update_msg(
    index_id: str,
    level: float,
    aggregate_cap: float,
    divisor: float,
    session_state: str,
    day: Mapping[str, float] | None = None,
) -> list[bytes]:
    """pm-index → subscribers: current index level broadcast.

    *day* is the session's ``{open, high, low}`` or None. It replaced three
    flat ``day_*`` keys under one ``if day_open is not None`` guard: three
    keys sharing a guard are a record that was flattened for want of one, and
    a nullable record makes the half-set state unrepresentable rather than
    merely invalid (design section 16.2).
    """
    return _gen_index.make_index_update(
        index_id=index_id,
        level=level,
        aggregate_cap=aggregate_cap,
        divisor=divisor,
        session_state=session_state,
        timestamp=time.time(),
        day=dict(day) if day is not None else None,
    )


def make_index_history_request_msg(
    gateway_id: str,
    index_id: str,
    from_ts: float,
    to_ts: float,
    types: list[str] | None = None,
    max_records: int = 10_000,
) -> list[bytes]:
    """Gateway/operator → pm-index: request structural/audit index records.

    pm-index's history is a structural audit log only (INIT, CORP_ACTION,
    ADD_CONSTITUENT, DELIST, REBALANCE) — it no longer stores level or EOD
    ticks. Omitting *types* returns all structural record types. For index
    level/EOD time-series history, query pm-stats instead.

    The key is now **omitted** when *types* is None rather than sent as a
    client-side copy of the server's default. That copy had drifted: it listed
    four of the five structural types, so every caller taking the default
    silently never saw a REBALANCE record (design section 20.4).
    """
    return _gen_index.make_index_history_request(
        gateway_id=gateway_id,
        index_id=index_id,
        from_ts=from_ts,
        to_ts=to_ts,
        types=list(types) if types else [],
        max_records=max_records,
    )


def make_index_history_msg(
    gateway_id: str,
    index_id: str,
    records: list[dict[str, Any]],
    warnings: list[str] | None = None,
) -> list[bytes]:
    """pm-index → requestor: history response.

    The archive is written through the generated ``HistoryRecord`` (validated on
    append) and ``IndexHistory.query`` drops any non-conforming row on read, so
    every record here is canonical and the checked builder replays it. See
    design section 9.
    """
    return _gen_index.make_index_history(
        gateway_id=gateway_id,
        index_id=index_id,
        records=records,
        warnings=warnings or [],
    )


def make_index_corp_action_msg(
    action: str,
    index_id: str,
    symbol: str,
    gateway_id: str,
    params: dict[str, Any],
) -> list[bytes]:
    """Operator → pm-index: apply a corporate action.

    *params* carries the action-specific fields — ``ratio_numerator`` and
    ``ratio_denominator`` for SPLIT, ``dividend_per_share`` for
    CASH_DIVIDEND, ``new_shares_outstanding`` for SHARES_ISSUANCE. The IDL has
    no variant type to say "these belong to that action", so they are declared
    flat and optional; design section 20.3 records why one was not built.
    """
    return _gen_index.make_index_corp_action(
        action=action,
        index_id=index_id,
        symbol=symbol,
        gateway_id=gateway_id,
        **params,
    )


def make_index_constituent_change_msg(
    change_type: str,
    index_id: str,
    symbol: str,
    gateway_id: str,
    shares_outstanding: int | None = None,
    initial_price: float | None = None,
) -> list[bytes]:
    """Operator → pm-index: add or delist a constituent."""
    return _gen_index.make_index_constituent_change(
        change_type=change_type,
        index_id=index_id,
        symbol=symbol,
        gateway_id=gateway_id,
        shares_outstanding=shares_outstanding,
        initial_price=initial_price,
    )


def make_index_corp_action_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    index_id: str = "",
    level: float | None = None,
    divisor: float | None = None,
) -> list[bytes]:
    """pm-index → requestor: corporate action ack."""
    return _gen_index.make_index_corp_action_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        timestamp=time.time(),
        index_id=index_id,
        level=level,
        divisor=divisor,
    )


def make_index_constituent_change_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    index_id: str = "",
    level: float | None = None,
    divisor: float | None = None,
) -> list[bytes]:
    """pm-index → requestor: constituent change ack."""
    return _gen_index.make_index_constituent_change_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        timestamp=time.time(),
        index_id=index_id,
        level=level,
        divisor=divisor,
    )


def make_index_rebalance_msg(
    index_id: str,
    gateway_id: str,
    updates: list[dict[str, Any]],
    command_id: str = "",
) -> list[bytes]:
    """ADMIN → pm-index: batch update constituent shares outstanding.

    ``updates`` is a list of ``{"symbol": ..., "new_shares_outstanding": ...}``
    — each entry mirrors the existing SHARES_ISSUANCE corporate action,
    applied to every named *existing* constituent as one batch with a single
    recompute/publish, rather than one corp-action round-trip per symbol.

    The non-empty and positive-share rules were pydantic constraints on
    ``IndexRebalanceRequest``, so they held for the API gateway and for
    nobody else. Declaring them in the spec makes them properties of the
    message (design section 15.5).
    """
    return _gen_index.make_index_rebalance(
        index_id=index_id,
        gateway_id=gateway_id,
        updates=updates,
        command_id=command_id,
    )


def make_index_rebalance_ack_msg(
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    index_id: str = "",
    level: float | None = None,
    divisor: float | None = None,
    updated_symbols: int = 0,
    command_id: str = "",
) -> list[bytes]:
    """pm-index → ADMIN: rebalance result."""
    return _gen_index.make_index_rebalance_ack(
        gateway_id=gateway_id,
        accepted=accepted,
        reason=reason,
        timestamp=time.time(),
        updated_symbols=updated_symbols,
        index_id=index_id,
        level=level,
        divisor=divisor,
        command_id=command_id,
    )


def make_index_error_msg(gateway_id: str, reason: str) -> list[bytes]:
    """pm-index → requestor: generic index error reply."""
    return _gen_index.make_index_error(
        gateway_id=gateway_id,
        accepted=False,
        reason=reason,
        timestamp=time.time(),
    )


def make_depth_msg(symbol: str, depth: dict[str, Any]) -> list[bytes]:
    """Engine → subscribers: depth ladder snapshot.

    The topic is ``depth.{symbol}``, **not** ``book.depth.{symbol}``. It
    published under the latter until this was corrected, which made the
    factory a trap: the engine publishes depth inline as ``depth.{symbol}``,
    every subscriber filters on ``depth.``, and the reference documents
    ``depth.{SYMBOL}`` — so a caller using this factory produced messages that
    no subscriber received.

    Worse, ``book.depth.X`` matches a ``book.`` prefix subscription. pm-stats
    subscribes to ``book.`` and derives the symbol as everything after the
    first dot, so it recorded a phantom instrument literally named
    ``depth.AAPL`` into daily_stats.
    """
    return _gen_book.make_depth(**depth)


# ---------------------------------------------------------------------------
# LALF-PS — pm-log-srv log distribution (subscriber ↔ pm-log-srv)
# ---------------------------------------------------------------------------
# Subscriber → pm-log-srv control requests only. The server side builds its
# own outbound messages inside edumatcher.log_srv.pubsub, which already holds
# all the state (lease deadlines, cursors, counters) those payloads report;
# duplicating them here as make_* helpers would mean passing a dozen unrelated
# arguments through just to reach encode(). These helpers exist for the client
# half — log viewers and CLIs — which is where a shared, typo-proof
# constructor actually earns its keep.


def make_log_subscribe_msg(
    sub_id: str,
    mode: str = "STREAM",
    log_filter: dict[str, Any] | None = None,
    backfill_minutes: int | None = None,
    lease_sec: int | None = None,
    notify_interval_ms: int | None = None,
) -> list[bytes]:
    """Subscriber → pm-log-srv: open or replace a leased subscription.

    Every optional field is ``omit_when_none`` in the spec, so the builder
    drops whatever the caller left unset rather than the wrapper deciding it
    here; the filter is validated and filled to the canonical ``LogFilter``
    shape the server reads, not passed through raw.
    """
    return _gen_log.make_log_subscribe(
        sub_id=sub_id,
        mode=mode,
        filter=log_filter,
        backfill_minutes=backfill_minutes,
        lease_sec=lease_sec,
        notify_interval_ms=notify_interval_ms,
    )


def make_log_renew_msg(sub_id: str) -> list[bytes]:
    """Subscriber → pm-log-srv: lease keepalive; the liveness signal."""
    return _gen_log.make_log_renew(sub_id=sub_id, timestamp=time.time())


def make_log_unsubscribe_msg(sub_id: str) -> list[bytes]:
    """Subscriber → pm-log-srv: close a subscription immediately."""
    return _gen_log.make_log_unsubscribe(sub_id=sub_id, timestamp=time.time())


def make_log_backfill_request_msg(
    sub_id: str,
    minutes: int,
    log_filter: dict[str, Any] | None = None,
    max_rows: int | None = None,
) -> list[bytes]:
    """Subscriber → pm-log-srv: replay the last ``minutes`` of history."""
    return _gen_log.make_log_backfill_request(
        sub_id=sub_id,
        minutes=minutes,
        filter=log_filter,
        max_rows=max_rows,
    )


def make_log_status_request_msg(sub_id: str) -> list[bytes]:
    """Subscriber → pm-log-srv: request subscription/server diagnostics."""
    return _gen_log.make_log_status_request(sub_id=sub_id, timestamp=time.time())
