"""
Domain models: Order, enums.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from edumatcher.models.clock import now_ns
from edumatcher.models.ids import new_order_id


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"
    FOK = "FOK"
    ICEBERG = "ICEBERG"
    IOC = "IOC"  # Immediate-Or-Cancel: fill what you can, cancel rest
    TRAILING_STOP = (
        "TRAILING_STOP"  # Dynamic stop that trails market price by a fixed offset
    )


class TIF(str, Enum):
    DAY = "DAY"
    GTC = "GTC"
    ATO = "ATO"  # At-The-Open: valid only during opening auction, expires after
    ATC = "ATC"  # At-The-Close: valid only during closing auction, expires after


class OrderStatus(str, Enum):
    NEW = "NEW"
    PARTIAL = "PARTIAL"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class SmpAction(str, Enum):
    """
    Self Match Prevention action — applied when an incoming order would trade
    against a resting order from the same gateway.

    NONE             — explicitly disabled; self-trades are allowed
    CANCEL_AGGRESSOR — cancel the incoming order, resting order stays
    CANCEL_RESTING   — cancel the resting order, continue matching
    CANCEL_BOTH      — cancel both orders

    ``Order.smp_action`` (and ``ComboLeg.smp_action``) is typed
    ``SmpAction | None`` rather than defaulting to ``NONE`` outright: ``None``
    means the client did not specify ``SMP=`` at all, which is distinct from
    an *explicit* ``SMP=NONE`` (a deliberate request to allow self-trades).
    Client-facing processes (``alf_gwy``, ``alf_console``, ``api_gateway``)
    preserve that distinction when parsing the wire request; the engine
    resolves ``None`` to the order's gateway-configured default
    (``gateways.alf[].smp_action``, falling back to ``NONE`` itself if the
    gateway has none configured) before the order reaches the matching
    engine — see ``Engine._resolve_smp_action`` in ``engine/main.py``. Code
    that inspects ``Order.smp_action`` after that resolution point (e.g. the
    order book) can safely assume it is a concrete member, never ``None``.
    """

    NONE = "NONE"
    CANCEL_AGGRESSOR = "CANCEL_AGGRESSOR"
    CANCEL_RESTING = "CANCEL_RESTING"
    CANCEL_BOTH = "CANCEL_BOTH"


class OrderOrigin(str, Enum):
    """Source of the order in the matching engine."""

    ORDER = "ORDER"
    QUOTE = "QUOTE"
    IMPLIED = "IMPLIED"


# ---------------------------------------------------------------------------
# PERF improvement #5: Pre-built enum-by-value lookup dicts.
#
# Python's Enum(value) constructor iterates through all members doing string
# comparisons (~600-800ns per call).  A dict lookup is ~50ns.  With 5 enum
# constructions per Order.from_dict() call, this saves ~3-4µs per order on
# the hot path — a ~15-20% improvement for the deserialization step.
# ---------------------------------------------------------------------------
_SIDE_MAP: dict[str, Side] = {v.value: v for v in Side}
_TYPE_MAP: dict[str, OrderType] = {v.value: v for v in OrderType}
_TIF_MAP: dict[str, TIF] = {v.value: v for v in TIF}
_STATUS_MAP: dict[str, OrderStatus] = {v.value: v for v in OrderStatus}
_SMP_MAP: dict[str, SmpAction] = {v.value: v for v in SmpAction}
_ORIGIN_MAP: dict[str, OrderOrigin] = {v.value: v for v in OrderOrigin}


# ---------------------------------------------------------------------------
# PERF improvement #4: __slots__ on the Order dataclass.
#
# Without __slots__, each Order instance carries a __dict__ (hash table with
# 18 keys).  With __slots__, attributes are stored in a fixed-size C array,
# giving:
#   - ~30% faster attribute access (fixed offset vs. hash lookup)
#   - ~40% lower per-instance memory (no per-object dict overhead)
#   - Reduced GC pressure from thousands of resting orders on the book
#
# At 5+ attribute accesses per fill in the inner loop (remaining_qty, side,
# price, gateway_id, status), this saves ~1.5-2µs per aggressive order.
# ---------------------------------------------------------------------------
@dataclass(slots=True)
class Order:
    id: str
    symbol: str
    side: Side
    order_type: OrderType
    tif: TIF
    quantity: int  # total original quantity
    remaining_qty: int  # quantity yet to be filled
    gateway_id: str
    timestamp: int
    status: OrderStatus

    price: Optional[int] = (
        None  # limit / stop-limit / FOK / iceberg limit price (ticks)
    )
    stop_price: Optional[int] = None  # STOP / STOP_LIMIT / TRAILING_STOP trigger price
    visible_qty: Optional[int] = None  # ICEBERG: fixed peak size
    displayed_qty: Optional[int] = None  # ICEBERG: current visible slice on book
    # Self-match prevention. None means "not yet resolved": either the client
    # omitted SMP= (engine should apply the gateway's configured default) or
    # this Order predates resolution (e.g. an unresolved ComboLeg). By the
    # time an Order reaches the matching engine / order book, this is always
    # a concrete SmpAction — see SmpAction's docstring.
    smp_action: Optional[SmpAction] = None

    # Trailing stop field
    trail_offset: Optional[int] = (
        None  # TRAILING_STOP: fixed distance to trail market price
    )

    # OCO-order field (shared group ID for two linked orders)
    oco_group_id: Optional[str] = None  # OCO pair group identifier

    # Combo-order fields (set only on child orders of a combo)
    combo_parent_id: Optional[str] = None  # parent ComboOrder.id
    leg_index: Optional[int] = None  # position in combo legs list (0-based)

    # Source metadata
    origin: OrderOrigin = OrderOrigin.ORDER
    quote_id: Optional[str] = None

    # Client-supplied order tag — echoed back on every lifecycle event
    # (ack, fill, cancelled, expired) so subscribers can correlate without
    # a FIFO matching scheme.  Optional; ignored when absent.
    client_tag: Optional[str] = None

    # Engine-assigned monotonic arrival sequence (finding H1).  Time priority
    # in the book is keyed on this, NOT on the client-supplied `timestamp`,
    # so a back-dated payload timestamp cannot jump the price-time queue.
    # Assigned by OrderBook when the order is placed on a heap; 0 = unassigned.
    arrival_seq: int = 0

    # Why the *exchange* cancelled this order, set by OrderBook when it makes
    # that decision itself (self-match prevention, an unfillable MARKET/IOC
    # remainder) and read by the engine when it publishes order.cancelled.
    # Deliberately absent from to_dict(): it is a marker carried on the event
    # object between the book and the publisher for the duration of one
    # handler call, not part of the order's persisted or wire representation.
    # A client cancel leaves it None.
    cancel_reason: Optional[str] = None

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------
    @classmethod
    def create(
        cls,
        symbol: str,
        side: Side,
        order_type: OrderType,
        quantity: int,
        gateway_id: str,
        tif: TIF = TIF.DAY,
        price: Optional[int] = None,
        stop_price: Optional[int] = None,
        visible_qty: Optional[int] = None,
        smp_action: Optional[SmpAction] = None,
        trail_offset: Optional[int] = None,
        oco_group_id: Optional[str] = None,
        client_tag: Optional[str] = None,
    ) -> "Order":
        displayed = visible_qty if order_type == OrderType.ICEBERG else None
        return cls(
            id=new_order_id(),
            symbol=symbol,
            side=side,
            order_type=order_type,
            tif=tif,
            quantity=quantity,
            remaining_qty=quantity,
            gateway_id=gateway_id,
            timestamp=now_ns(),
            status=OrderStatus.NEW,
            price=price,
            stop_price=stop_price,
            visible_qty=visible_qty,
            displayed_qty=displayed,
            smp_action=smp_action,
            trail_offset=trail_offset,
            oco_group_id=oco_group_id,
            client_tag=client_tag,
        )

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side.value,
            "order_type": self.order_type.value,
            "tif": self.tif.value,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
            "gateway_id": self.gateway_id,
            "trail_offset": self.trail_offset,
            "oco_group_id": self.oco_group_id,
            "timestamp": self.timestamp,
            "status": self.status.value,
            "price": self.price,
            "stop_price": self.stop_price,
            "visible_qty": self.visible_qty,
            "displayed_qty": self.displayed_qty,
            "smp_action": (
                self.smp_action.value if self.smp_action is not None else None
            ),
            "combo_parent_id": self.combo_parent_id,
            "leg_index": self.leg_index,
            "origin": self.origin.value,
            "quote_id": self.quote_id,
            "client_tag": self.client_tag,
            "arrival_seq": self.arrival_seq,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Order":
        # PERF #5 + #10: Bypass the dataclass __init__ (which parses 19 kwargs)
        # and write slots directly via __new__.  Combined with pre-built enum
        # lookup dicts, this reduces Order.from_dict from ~1400ns to ~1000ns.
        #
        # The dataclass-generated __init__ uses LOAD_FAST for each of the 19
        # parameters, then STORE_ATTR for each slot — but the function call
        # overhead of 19 keyword arguments dominates (~400ns just for arg
        # dispatch).  __new__ + direct slot writes avoids this entirely.
        o = object.__new__(cls)
        o.id = d["id"]
        o.symbol = d["symbol"]
        o.side = _SIDE_MAP[d["side"]]
        o.order_type = _TYPE_MAP[d["order_type"]]
        o.tif = _TIF_MAP[d["tif"]]
        o.quantity = d["quantity"]
        o.remaining_qty = d["remaining_qty"]
        o.gateway_id = d["gateway_id"]
        o.timestamp = d["timestamp"]
        o.status = _STATUS_MAP[d["status"]]
        o.price = d.get("price")
        o.stop_price = d.get("stop_price")
        o.visible_qty = d.get("visible_qty")
        o.displayed_qty = d.get("displayed_qty")
        # Absent key or explicit null both mean "client did not specify" —
        # preserved as None (see SmpAction's docstring), not silently
        # defaulted to SmpAction.NONE, so the engine can still tell the
        # difference from an explicit SMP=NONE and apply a gateway default.
        _smp_raw = d.get("smp_action")
        o.smp_action = _SMP_MAP.get(_smp_raw) if _smp_raw is not None else None
        o.trail_offset = d.get("trail_offset")
        o.oco_group_id = d.get("oco_group_id")
        o.combo_parent_id = d.get("combo_parent_id")
        o.leg_index = d.get("leg_index")
        o.origin = _ORIGIN_MAP.get(d.get("origin", "ORDER"), OrderOrigin.ORDER)
        o.quote_id = d.get("quote_id")
        o.client_tag = d.get("client_tag")
        o.arrival_seq = d.get("arrival_seq", 0)
        # Not carried on the wire (see the field comment): __new__ bypasses the
        # dataclass default, so the slot must be initialised here or the first
        # read raises AttributeError.
        o.cancel_reason = None
        return o
