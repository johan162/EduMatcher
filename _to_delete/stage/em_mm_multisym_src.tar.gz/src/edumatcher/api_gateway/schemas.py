"""Pydantic request and response schemas for the REST API."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from edumatcher.models.combo import ComboType
from edumatcher.models.order import OrderType, Side, SmpAction, TIF
from edumatcher.models.session import SessionState


class StrictModel(BaseModel):
    """Base model that rejects unknown JSON fields."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)


class ErrorDetail(StrictModel):
    code: str
    message: str
    field: str | None = None
    reject_code: str | None = None
    reason: str | None = None
    client_tag: str | None = None
    request_tag: str | None = None


class ErrorResponse(StrictModel):
    error: ErrorDetail


class OrderRequest(StrictModel):
    symbol: str = Field(min_length=1)
    side: Side
    order_type: OrderType
    quantity: int = Field(gt=0)
    tif: TIF = TIF.DAY
    price: float | None = None
    stop_price: float | None = None
    visible_qty: int | None = Field(default=None, gt=0)
    trail_offset: float | None = None
    # None means the client omitted smp_action -- the engine applies this
    # gateway's configured smp_action default in that case, distinct from an
    # explicit "smp_action": "NONE" (deliberately allow self-trades). See
    # SmpAction's docstring in models/order.py.
    smp_action: SmpAction | None = None
    client_tag: str | None = Field(default=None, max_length=64)

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()

    @model_validator(mode="after")
    def validate_by_order_type(self) -> "OrderRequest":
        order_type = OrderType(self.order_type)
        if order_type == OrderType.MARKET and (
            self.price is not None or self.stop_price is not None
        ):
            raise ValueError("MARKET forbids price and stop_price")
        if order_type in {OrderType.LIMIT, OrderType.FOK, OrderType.IOC}:
            if self.price is None:
                raise ValueError(f"{order_type.value} requires price")
            if self.stop_price is not None:
                raise ValueError(f"{order_type.value} forbids stop_price")
        if order_type == OrderType.STOP:
            if self.stop_price is None:
                raise ValueError("STOP requires stop_price")
            if self.price is not None:
                raise ValueError("STOP forbids price")
        if order_type == OrderType.STOP_LIMIT and (
            self.price is None or self.stop_price is None
        ):
            raise ValueError("STOP_LIMIT requires price and stop_price")
        if order_type == OrderType.ICEBERG:
            if self.price is None or self.visible_qty is None:
                raise ValueError("ICEBERG requires price and visible_qty")
            if self.visible_qty >= self.quantity:
                raise ValueError("ICEBERG visible_qty must be less than quantity")
        if order_type == OrderType.TRAILING_STOP:
            if self.trail_offset is None:
                raise ValueError("TRAILING_STOP requires trail_offset")
            if self.price is not None:
                raise ValueError("TRAILING_STOP forbids price")
        return self


class OrderAccepted(StrictModel):
    order_id: str
    client_tag: str | None = None
    status: str
    accepted: bool | None = None
    reject_code: str | None = None
    event: dict[str, Any] | None = None


class CancelAccepted(StrictModel):
    order_id: str
    request_tag: str | None = None
    status: str
    event: dict[str, Any] | None = None


class AmendRequest(StrictModel):
    price: float | None = None
    quantity: int | None = Field(default=None, gt=0)
    request_tag: str | None = Field(default=None, max_length=64)

    @model_validator(mode="after")
    def require_one_field(self) -> "AmendRequest":
        if self.price is None and self.quantity is None:
            raise ValueError("At least one of price or quantity is required")
        return self


class ReplaceResponse(StrictModel):
    cancelled_order_id: str
    replacement_order_id: str
    status: str


class OcoLegRequest(StrictModel):
    side: Side
    order_type: OrderType
    price: float | None = None
    stop_price: float | None = None
    trail_offset: float | None = None


class OcoRequest(StrictModel):
    oco_id: str = Field(min_length=1)
    symbol: str = Field(min_length=1)
    quantity: int = Field(gt=0)
    tif: TIF = TIF.DAY
    client_tag: str | None = Field(default=None, max_length=64)
    leg1: OcoLegRequest
    leg2: OcoLegRequest

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class ComboLegRequest(StrictModel):
    symbol: str = Field(min_length=1)
    side: Side
    order_type: OrderType = OrderType.LIMIT
    quantity: int = Field(gt=0)
    price: float | None = None
    stop_price: float | None = None

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class ComboRequest(StrictModel):
    combo_id: str = Field(min_length=1)
    combo_type: ComboType = ComboType.AON
    tif: TIF = TIF.DAY
    # None means the client omitted smp_action -- see OrderRequest.smp_action.
    smp_action: SmpAction | None = None
    client_tag: str | None = Field(default=None, max_length=64)
    legs: list[ComboLegRequest] = Field(min_length=2, max_length=10)


class QuoteRequest(StrictModel):
    symbol: str = Field(min_length=1)
    bid_price: float
    bid_qty: int = Field(gt=0)
    ask_price: float
    ask_qty: int = Field(gt=0)
    tif: TIF = TIF.DAY
    quote_id: str | None = None

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()

    @model_validator(mode="after")
    def validate_spread(self) -> "QuoteRequest":
        if self.bid_price >= self.ask_price:
            raise ValueError("bid_price must be lower than ask_price")
        return self


class MassCancelRequest(StrictModel):
    symbol: str | None = None

    @field_validator("symbol")
    @classmethod
    def uppercase_optional_symbol(cls, value: str | None) -> str | None:
        return None if value is None else value.upper()


class PendingIdResponse(StrictModel):
    id: str
    status: str
    event: dict[str, Any] | None = None


class HistoryQuery(StrictModel):
    symbol: str | None = None
    event_type: str | None = None
    date: str | None = None
    from_ts: str | None = None
    to_ts: str | None = None
    limit: int = Field(default=500, ge=1, le=5000)


class SessionTransitionRequest(StrictModel):
    to_state: SessionState


#: Bounds that mirror the `risk` spec's `max_len` on the fields these become.
#: They are load-bearing, not cosmetic: since 5.3a/5.3b the builders validate,
#: so an unbounded value here reaches a generated constructor and raises —
#: turning a client's bad input into a 500 where FastAPI would otherwise have
#: returned a 422 naming the offending field. Bound at the edge, where the
#: error can still say what was wrong.
_MAX_SYMBOL = 16
_MAX_GATEWAY_ID = 32
_MAX_CB_LEVEL = 32
_MAX_REASON = 256


class CircuitBreakerTriggerRequest(StrictModel):
    symbol: str = Field(min_length=1, max_length=_MAX_SYMBOL)
    level: str | None = Field(default=None, max_length=_MAX_CB_LEVEL)
    reason: str | None = Field(default=None, max_length=_MAX_REASON)

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class CircuitBreakerResumeRequest(StrictModel):
    symbol: str = Field(min_length=1, max_length=_MAX_SYMBOL)
    reason: str | None = Field(default=None, max_length=_MAX_REASON)

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class SymbolCancelRequest(StrictModel):
    symbol: str = Field(min_length=1, max_length=_MAX_SYMBOL)
    reason: str | None = Field(default=None, max_length=_MAX_REASON)

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class KillSwitchGatewayRequest(StrictModel):
    target_gateway_id: str = Field(min_length=1, max_length=_MAX_GATEWAY_ID)
    reason: str | None = Field(default=None, max_length=_MAX_REASON)

    @field_validator("target_gateway_id")
    @classmethod
    def uppercase_target(cls, value: str) -> str:
        return value.upper()


class KillSwitchGlobalRequest(StrictModel):
    reason: str | None = Field(default=None, max_length=_MAX_REASON)


class IndexRebalanceUpdate(StrictModel):
    symbol: str = Field(min_length=1)
    new_shares_outstanding: int = Field(gt=0)

    @field_validator("symbol")
    @classmethod
    def uppercase_symbol(cls, value: str) -> str:
        return value.upper()


class IndexRebalanceRequest(StrictModel):
    updates: list[IndexRebalanceUpdate] = Field(min_length=1)
    reason: str | None = None


MarketDataChannel = Literal["book", "trades", "depth", "auction"]

#: Venue-wide status channels. These are delivered to every market-data
#: subscriber regardless of what it asked for, because a halt or a session
#: transition changes the meaning of every other channel — a client showing a
#: stale book during a halt is showing something false. They are therefore not
#: subscribable, and the subscription ack reports them under ``always`` so the
#: behaviour is discoverable rather than surprising.
ALWAYS_ON_CHANNELS: tuple[str, ...] = ("session", "circuit_breaker")


class MarketDataSubscriptionItem(StrictModel):
    """One (symbols x channels) subscription rule.

    An empty or ``["*"]`` ``symbols`` list means every symbol. An empty
    ``channels`` list subscribes to nothing and is reported back as rejected
    rather than silently ignored.

    ``resume_from`` is an optional per-channel hint carrying the last ``seq``
    the client processed on that channel's topic for this item's symbol(s). It
    is honoured for ``trades`` (buffered prints after that ``seq`` are
    replayed); for the self-healing snapshot channels the current snapshot is
    sent instead. Absent means "just send me the current snapshot".
    """

    symbols: list[str] = Field(default_factory=list)
    channels: list[MarketDataChannel] = Field(default_factory=list)
    resume_from: dict[MarketDataChannel, int] | None = None


class MarketDataControl(StrictModel):
    """Market-data control frame.

    Four actions:

    * ``subscribe`` / ``unsubscribe`` — change the socket's active rule set.
    * ``snapshot`` — re-emit the current cached snapshot for the given
      symbols/channels without changing the subscription.
    * ``resume`` — replay one dropped stream from ``from_seq``. Names the
      topic either explicitly (``topic`` + optional ``symbol``) or, for
      ``subscribe``, via a per-item ``resume_from`` hint.

    Two subscription forms, both accepted (and unchanged):

    * **Flat** — ``symbols`` and ``channels`` at the top level (their cross
      product).
    * **Items** — a list of independent rules, the only way to express "book
      for everything, depth for one symbol".

    The flat form equals a single item, so an existing client needs no change.
    """

    action: Literal["subscribe", "unsubscribe", "snapshot", "resume"]
    symbols: list[str] = Field(default_factory=list)
    channels: list[MarketDataChannel] = Field(default_factory=list)
    items: list[MarketDataSubscriptionItem] = Field(default_factory=list)
    #: ``resume`` only: the engine topic to replay (e.g. ``"trade.executed"``)
    #: and the last sequence the client processed. When the topic is not itself
    #: symbol-qualified (``trade.executed``), the symbol is taken from the
    #: ``symbols`` list above — there is deliberately no singular ``symbol``
    #: field, so a ``symbol``/``symbols`` typo stays an error.
    topic: str | None = None
    from_seq: int | None = None

    def as_items(self) -> list[MarketDataSubscriptionItem]:
        """Normalise both forms to a list of items."""
        items = list(self.items)
        if self.symbols or self.channels:
            items.append(
                MarketDataSubscriptionItem(symbols=self.symbols, channels=self.channels)
            )
        return items
