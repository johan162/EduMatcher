"""
Additional Engine handler tests targeting the 232 uncovered statements.

Covers:
  - _handle_symbols_request
  - _handle_book_snapshot_request
  - _handle_amend (success/error paths)
  - _handle_cancel (success, not found, combo cascade, oco cascade)
  - _handle_session_transition (valid/invalid transitions)
  - _expire_tif
  - _run_uncross
  - _handle_combo_order / _validate_combo / _cascade_cancel_combo
  - _handle_combo_cancel
  - _handle_oco_order / _handle_oco_cancel / _check_oco_after_event
  - _handle_new_order session-state gating (closed, ATO, ATC, no-match types)
  - _flush_snapshots
  - _gateway_status
"""

from __future__ import annotations

from dataclasses import dataclass

import pytest


from edumatcher.engine.config_loader import (
    EngineConfig,
    FixGatewayConfig,
    SymbolConfig,
)
from edumatcher.engine.main import Engine
from edumatcher.models.message import decode
from edumatcher.models.order import Order, OrderType, Side, TIF
from edumatcher.models.session import SessionState

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------


@dataclass
class _FakeSock:
    sent: list[list[bytes]]
    closed: bool = False

    def send_multipart(self, frames: list[bytes]) -> None:
        self.sent.append(frames)

    def close(self) -> None:
        self.closed = True


def _make_engine(
    monkeypatch,
    tmp_path,
    symbols=("AAPL",),
    gateways=("GW01",),
    sessions_enabled: bool = False,
    snapshot_interval_sec: float = 0.5,
    quote_history_maxlen: int = 30,
    drop_copy_buffer_size: int = 10_000,
    recent_trades_maxlen: int = 20,
    depth_snapshot_tolerance_ticks: int = 100,
) -> tuple[Engine, _FakeSock]:
    pull_sock = _FakeSock(sent=[])
    pub_sock = _FakeSock(sent=[])

    cfg = EngineConfig(
        symbols={sym: SymbolConfig(name=sym) for sym in symbols},
        fix_gateways={
            gw: FixGatewayConfig(id=gw, description=f"{gw} trader") for gw in gateways
        },
        snapshot_interval_sec=snapshot_interval_sec,
        quote_history_maxlen=quote_history_maxlen,
        drop_copy_buffer_size=drop_copy_buffer_size,
        recent_trades_maxlen=recent_trades_maxlen,
        depth_snapshot_tolerance_ticks=depth_snapshot_tolerance_ticks,
        sessions_enabled=sessions_enabled,
    )

    monkeypatch.setattr("edumatcher.engine.main.make_puller", lambda _: pull_sock)
    monkeypatch.setattr("edumatcher.engine.main.make_publisher", lambda _: pub_sock)
    monkeypatch.setattr("edumatcher.engine.main.load_engine_config", lambda _: cfg)
    monkeypatch.setattr("edumatcher.engine.main.load_gtc_orders", lambda _: [])
    monkeypatch.setattr("edumatcher.engine.main.load_book_stats", lambda _: {})
    monkeypatch.setattr("edumatcher.engine.main.time.sleep", lambda *_: None)

    cfg_path = tmp_path / "engine_config.yaml"
    cfg_path.write_text("dummy: true\n")

    engine = Engine(config_path=str(cfg_path))
    return engine, pub_sock


def _connect(engine: Engine, gw: str = "GW01") -> None:
    engine._handle_gateway_connect({"gateway_id": gw})


def _make_order_payload(
    symbol="AAPL",
    side=Side.BUY,
    order_type=OrderType.LIMIT,
    qty=100,
    price=100.0,
    gateway_id="GW01",
    tif=TIF.DAY,
    stop_price=None,
    client_tag=None,
) -> dict:
    o = Order.create(
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=qty,
        gateway_id=gateway_id,
        tif=tif,
        price=price,
        stop_price=stop_price,
        client_tag=client_tag,
    )
    return o.to_dict()


# ---------------------------------------------------------------------------
# _handle_symbols_request
# ---------------------------------------------------------------------------


class TestHandleSymbolsRequest:
    def test_returns_known_symbols(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, symbols=("AAPL", "MSFT"))
        _connect(engine)
        # Create books
        engine._handle_new_order(_make_order_payload("AAPL"))
        engine._handle_new_order(_make_order_payload("MSFT", gateway_id="GW01"))
        pub_sock.sent.clear()
        engine._handle_symbols_request({"gateway_id": "GW01"})
        topic, msg = decode(pub_sock.sent[-1])
        assert topic == "system.symbols.GW01"
        by_symbol = {e["symbol"]: e for e in msg["symbols"]}
        assert set(by_symbol) == {"AAPL", "MSFT"}
        # The metadata travels inside the entry rather than in a parallel
        # `symbol_meta` map keyed by the same symbol, and the tick scale is the
        # integer exponent the engine holds rather than 10 ** -n of it.
        assert by_symbol["AAPL"]["tick_decimals"] == 2


# ---------------------------------------------------------------------------
# _handle_book_snapshot_request
# ---------------------------------------------------------------------------


class TestHandleBookSnapshotRequest:
    def test_known_symbol_publishes_snapshot(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(_make_order_payload())
        pub_sock.sent.clear()
        engine._handle_book_snapshot_request({"symbol": "aapl"})
        assert any(b"book.AAPL" in frames[0] for frames in pub_sock.sent)

    def test_unknown_symbol_sends_nothing(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        count = len(pub_sock.sent)
        engine._handle_book_snapshot_request({"symbol": "NONEXISTENT"})
        assert len(pub_sock.sent) == count


# ---------------------------------------------------------------------------
# _handle_amend
# ---------------------------------------------------------------------------


class TestHandleAmend:
    def test_amend_succeeds(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(_make_order_payload(qty=100, price=100.0))
        # find order id from ack
        _, ack = decode(pub_sock.sent[-1])
        order_id = ack.get("order_id") or _get_last_ack_id(pub_sock)
        pub_sock.sent.clear()
        engine._handle_amend(
            {
                "order_id": order_id,
                "gateway_id": "GW01",
                "qty": 80,
                "request_tag": "RT-AMD-OK",
            }
        )
        topic, msg = decode(pub_sock.sent[-1])
        assert "amended" in topic
        assert msg["qty"] == 80
        assert msg["request_tag"] == "RT-AMD-OK"

    def test_amend_requires_price_or_qty(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_amend(
            {"order_id": "x", "gateway_id": "GW01", "price": None, "qty": None}
        )
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_amend_unknown_order_rejected(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_amend({"order_id": "NONE", "gateway_id": "GW01", "qty": 50})
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_amend_unauthorized_gateway(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        engine._handle_amend({"order_id": "x", "gateway_id": "UNKNOWN", "qty": 50})
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_amend_unauthorized_gateway_carries_request_tag(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        engine._handle_amend(
            {
                "order_id": "x",
                "gateway_id": "UNKNOWN",
                "qty": 50,
                "request_tag": "RT-AMD-001",
            }
        )
        msg = _last_rejected_ack(pub_sock)
        assert msg["accepted"] is False
        assert msg["request_tag"] == "RT-AMD-001"


def _get_last_ack_id(pub_sock: _FakeSock) -> str:
    for frames in reversed(pub_sock.sent):
        topic, payload = decode(frames)
        if "ack" in topic and payload.get("accepted"):
            return str(payload.get("order_id", ""))
    return ""


def _last_rejected_ack(pub_sock: _FakeSock) -> dict:
    for frames in reversed(pub_sock.sent):
        topic, payload = decode(frames)
        if "order.ack" in topic and payload.get("accepted") is False:
            return payload
    raise AssertionError("no rejected order ack published")


# ---------------------------------------------------------------------------
# _handle_cancel
# ---------------------------------------------------------------------------


class TestHandleCancel:
    def test_cancel_existing_order(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(_make_order_payload())
        order_id = _get_last_ack_id(pub_sock)
        pub_sock.sent.clear()
        engine._handle_cancel(
            {
                "order_id": order_id,
                "gateway_id": "GW01",
                "request_tag": "RT-CXL-OK",
            }
        )
        topic, msg = decode(pub_sock.sent[-1])
        assert "cancelled" in topic
        assert msg["request_tag"] == "RT-CXL-OK"

    def test_cancel_nonexistent_order_rejected(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_cancel({"order_id": "NONE", "gateway_id": "GW01"})
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False
        assert msg.get("request_tag") is None

    def test_cancel_unauthorized_gateway(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        engine._handle_cancel({"order_id": "x", "gateway_id": "UNKNOWN"})
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_rejected_cancel_carries_code_and_order_tag(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(
            monkeypatch, tmp_path, gateways=("GW01", "GW02")
        )
        _connect(engine, "GW01")
        _connect(engine, "GW02")
        engine._handle_new_order(_make_order_payload(client_tag="T1-CANCEL"))
        order_id = _get_last_ack_id(pub_sock)
        pub_sock.sent.clear()

        engine._handle_cancel({"order_id": order_id, "gateway_id": "GW02"})
        msg = _last_rejected_ack(pub_sock)

        assert msg["reject_code"] == "NOT_OWNER"
        assert msg["client_tag"] == "T1-CANCEL"

    def test_rejected_cancel_carries_request_tag(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(
            monkeypatch, tmp_path, gateways=("GW01", "GW02")
        )
        _connect(engine, "GW01")
        _connect(engine, "GW02")
        engine._handle_new_order(_make_order_payload(client_tag="T1-CANCEL-REQ"))
        order_id = _get_last_ack_id(pub_sock)
        pub_sock.sent.clear()

        engine._handle_cancel(
            {
                "order_id": order_id,
                "gateway_id": "GW02",
                "request_tag": "RT-REQ-001",
            }
        )
        msg = _last_rejected_ack(pub_sock)

        assert msg["reject_code"] == "NOT_OWNER"
        assert msg["client_tag"] == "T1-CANCEL-REQ"
        assert msg["request_tag"] == "RT-REQ-001"


# ---------------------------------------------------------------------------
# _handle_session_transition
# ---------------------------------------------------------------------------


class TestSessionTransition:
    def test_transition_ignored_when_sessions_disabled(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path, sessions_enabled=False)
        engine._session_state = SessionState.CONTINUOUS
        engine._handle_session_transition({"to_state": "CLOSED"})
        assert engine._session_state == SessionState.CONTINUOUS

    def test_valid_transition_continuous_to_closing_auction(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        # CONTINUOUS → CLOSING_AUCTION is valid
        engine._session_state = SessionState.CONTINUOUS
        pub_sock.sent.clear()
        engine._handle_session_transition({"to_state": "CLOSING_AUCTION"})
        assert engine._session_state == SessionState.CLOSING_AUCTION
        topic, msg = decode(pub_sock.sent[-1])
        assert "session.state" in topic

    def test_invalid_transition_ignored(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        engine._session_state = SessionState.CONTINUOUS
        count = len(pub_sock.sent)
        engine._handle_session_transition({"to_state": "PRE_OPEN"})
        # No message published for invalid transition
        assert len(pub_sock.sent) == count

    def test_bad_state_value_ignored(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        count = len(pub_sock.sent)
        engine._handle_session_transition({"to_state": "GARBAGE"})
        assert len(pub_sock.sent) == count

    def test_pre_open_to_opening_auction(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        engine._session_state = SessionState.PRE_OPEN
        engine._handle_session_transition({"to_state": "OPENING_AUCTION"})
        assert engine._session_state == SessionState.OPENING_AUCTION

    def test_opening_auction_to_continuous_triggers_uncross(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        # Place crossing orders during OPENING_AUCTION so there's something to uncross
        engine._session_state = SessionState.OPENING_AUCTION
        engine._handle_new_order(_make_order_payload(side=Side.BUY, price=100))
        engine._handle_new_order(
            _make_order_payload(side=Side.SELL, price=100, gateway_id="GW01")
        )
        pub_sock.sent.clear()
        engine._handle_session_transition({"to_state": "CONTINUOUS"})
        assert engine._session_state == SessionState.CONTINUOUS

    def test_closing_auction_to_closed_expires_atc(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.CLOSING_AUCTION
        # Place an ATC order
        o = Order.create(
            symbol="AAPL",
            side=Side.BUY,
            order_type=OrderType.LIMIT,
            quantity=100,
            gateway_id="GW01",
            tif=TIF.ATC,
            price=100,
        )
        engine._handle_new_order(o.to_dict())
        pub_sock.sent.clear()
        engine._handle_session_transition({"to_state": "CLOSED"})
        # ATC orders should be expired
        expired_msgs = [decode(f) for f in pub_sock.sent if b"expired" in f[0]]
        assert len(expired_msgs) >= 1


# ---------------------------------------------------------------------------
# Session-state gating on new orders
# ---------------------------------------------------------------------------


class TestNewOrderSessionGating:
    def test_sessions_enabled_starts_closed_and_rejects_new_orders(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        assert engine._session_state == SessionState.CLOSED
        engine._handle_new_order(_make_order_payload())
        topic, msg = decode(pub_sock.sent[-1])
        assert "order.ack" in topic
        assert msg["accepted"] is False
        assert "closed" in msg["reason"].lower()

    def test_order_rejected_when_market_closed(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.CLOSED
        engine._handle_new_order(_make_order_payload())
        topic, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False
        assert "closed" in msg["reason"].lower()

    def test_ato_rejected_outside_opening_auction(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.CONTINUOUS
        payload = _make_order_payload(tif=TIF.ATO)
        engine._handle_new_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False
        assert "ATO" in msg["reason"]

    def test_atc_rejected_outside_closing_auction(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.CONTINUOUS
        payload = _make_order_payload(tif=TIF.ATC)
        engine._handle_new_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False
        assert "ATC" in msg["reason"]

    def test_market_order_rejected_in_pre_open(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.PRE_OPEN
        payload = _make_order_payload(order_type=OrderType.MARKET, price=None)
        engine._handle_new_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_fok_rejected_in_pre_open(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.PRE_OPEN
        payload = _make_order_payload(order_type=OrderType.FOK, price=100.0)
        engine._handle_new_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_ato_accepted_during_opening_auction(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.OPENING_AUCTION
        payload = _make_order_payload(tif=TIF.ATO)
        engine._handle_new_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is True

    @pytest.mark.parametrize(
        "setup,payload,code",
        [
            (
                lambda engine: None,
                _make_order_payload(gateway_id="UNKNOWN", client_tag="T1-GW"),
                "GATEWAY_NOT_CONFIGURED",
            ),
            (
                lambda engine: _connect(engine),
                _make_order_payload(symbol="MSFT", client_tag="T1-SYM"),
                "UNKNOWN_SYMBOL",
            ),
            (
                lambda engine: _connect(engine),
                _make_order_payload(qty=0, client_tag="T1-QTY"),
                "QTY_OUT_OF_RANGE",
            ),
            (
                lambda engine: _connect(engine),
                _make_order_payload(
                    order_type=OrderType.LIMIT, price=None, client_tag="T1-PX"
                ),
                "PRICE_OUT_OF_RANGE",
            ),
        ],
    )
    def test_rejected_new_order_carries_code_and_client_tag(
        self, monkeypatch, tmp_path, setup, payload, code
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        setup(engine)

        engine._handle_new_order(payload)
        msg = _last_rejected_ack(pub_sock)

        assert msg["reject_code"] == code
        assert msg["client_tag"] == payload["client_tag"]

    def test_insufficient_liquidity_reject_carries_code_and_client_tag(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(
            _make_order_payload(
                order_type=OrderType.FOK, price=100.0, client_tag="T1-FOK"
            )
        )

        msg = _last_rejected_ack(pub_sock)

        assert msg["reject_code"] == "INSUFFICIENT_LIQUIDITY"
        assert msg["client_tag"] == "T1-FOK"


# ---------------------------------------------------------------------------
# Trailing stop edge case in new order handler
# ---------------------------------------------------------------------------


class TestTrailingStopNewOrder:
    def test_trailing_stop_rejected_without_prior_price(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        o = Order.create(
            symbol="AAPL",
            side=Side.SELL,
            order_type=OrderType.TRAILING_STOP,
            quantity=100,
            gateway_id="GW01",
            tif=TIF.DAY,
            trail_offset=5,
        )
        engine._handle_new_order(o.to_dict())
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False
        assert "Trailing stop" in msg["reason"]

    def test_trailing_stop_accepted_with_last_trade_price(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        # Seed a last trade price
        engine._book("AAPL").last_trade_price = 100.0
        o = Order.create(
            symbol="AAPL",
            side=Side.SELL,
            order_type=OrderType.TRAILING_STOP,
            quantity=100,
            gateway_id="GW01",
            tif=TIF.DAY,
            trail_offset=5,
        )
        engine._handle_new_order(o.to_dict())
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is True


# ---------------------------------------------------------------------------
# Combo handlers
# ---------------------------------------------------------------------------


class TestComboHandlers:
    def _combo_payload(self, gateway_id: str = "GW01") -> dict:
        from edumatcher.models.combo import ComboLeg, ComboOrder, ComboType

        combo = ComboOrder.create(
            combo_id="C001",
            gateway_id=gateway_id,
            combo_type=ComboType.AON,
            tif=TIF.DAY,
            legs=[
                ComboLeg(
                    symbol="AAPL",
                    side=Side.BUY,
                    order_type=OrderType.LIMIT,
                    quantity=100,
                    price=100,
                ),
                ComboLeg(
                    symbol="MSFT",
                    side=Side.SELL,
                    order_type=OrderType.LIMIT,
                    quantity=50,
                    price=200,
                ),
            ],
        )
        return combo.to_dict()

    def test_combo_order_accepted(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, symbols=("AAPL", "MSFT"))
        _connect(engine)
        engine._handle_combo_order(self._combo_payload())
        topics = [decode(f)[0] for f in pub_sock.sent]
        assert any("combo.ack" in t for t in topics)

    def test_combo_order_rejected_gateway_not_connected(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, symbols=("AAPL", "MSFT"))
        engine._handle_combo_order(self._combo_payload())
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_combo_cancel_succeeds(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, symbols=("AAPL", "MSFT"))
        _connect(engine)
        engine._handle_combo_order(self._combo_payload())
        pub_sock.sent.clear()
        engine._handle_combo_cancel({"gateway_id": "GW01", "combo_id": "C001"})
        topics = [decode(f)[0] for f in pub_sock.sent]
        assert any("combo.status" in t for t in topics)

    def test_combo_cancel_not_found(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_combo_cancel({"gateway_id": "GW01", "combo_id": "NONE"})
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_validate_combo_too_few_legs(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path)
        from edumatcher.models.combo import ComboLeg, ComboOrder, ComboType

        combo = ComboOrder.create(
            combo_id="X",
            gateway_id="GW01",
            combo_type=ComboType.AON,
            tif=TIF.DAY,
            legs=[
                ComboLeg(
                    symbol="AAPL",
                    side=Side.BUY,
                    order_type=OrderType.LIMIT,
                    quantity=10,
                    price=100,
                ),
            ],
        )
        err = engine._validate_combo(combo)
        assert "2 legs" in err

    def test_validate_combo_duplicate_symbols(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path, symbols=("AAPL",))
        from edumatcher.models.combo import ComboLeg, ComboOrder, ComboType

        combo = ComboOrder.create(
            combo_id="X",
            gateway_id="GW01",
            combo_type=ComboType.AON,
            tif=TIF.DAY,
            legs=[
                ComboLeg(
                    symbol="AAPL",
                    side=Side.BUY,
                    order_type=OrderType.LIMIT,
                    quantity=10,
                    price=100,
                ),
                ComboLeg(
                    symbol="AAPL",
                    side=Side.SELL,
                    order_type=OrderType.LIMIT,
                    quantity=10,
                    price=101,
                ),
            ],
        )
        err = engine._validate_combo(combo)
        assert "Duplicate" in err


# ---------------------------------------------------------------------------
# OCO handlers
# ---------------------------------------------------------------------------


class TestOCOHandlers:
    def _oco_payload(self, gateway_id: str = "GW01") -> dict:
        return {
            "oco_id": "OCO001",
            "gateway_id": gateway_id,
            "symbol": "AAPL",
            "quantity": 100,
            "tif": "DAY",
            "leg1": {"side": "BUY", "order_type": "LIMIT", "price": 9500},
            "leg2": {"side": "BUY", "order_type": "STOP", "stop_price": 10500},
        }

    def test_oco_accepted(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_oco_order(self._oco_payload())
        topics = [decode(f)[0] for f in pub_sock.sent]
        assert any("oco.ack" in t for t in topics)

    def test_oco_rejected_gateway_not_connected(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        engine._handle_oco_order(self._oco_payload())
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_oco_rejected_bad_symbol(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        payload = self._oco_payload()
        payload["symbol"] = "ZZZZ"
        engine._handle_oco_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_oco_rejected_zero_qty(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        payload = self._oco_payload()
        payload["quantity"] = 0
        engine._handle_oco_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_oco_rejected_bad_leg_definition(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        payload = self._oco_payload()
        payload["leg1"] = {"side": "INVALID", "order_type": "LIMIT"}
        engine._handle_oco_order(payload)
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_oco_cancel_succeeds(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_oco_order(self._oco_payload())
        pub_sock.sent.clear()
        engine._handle_oco_cancel({"gateway_id": "GW01", "oco_id": "OCO001"})
        # Should have published cancelled messages
        topics = [decode(f)[0] for f in pub_sock.sent]
        assert any("cancelled" in t for t in topics)

    def test_oco_cancel_not_found(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_oco_cancel({"gateway_id": "GW01", "oco_id": "NONE"})
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False

    def test_oco_sibling_cancelled_when_leg_fills(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine, "GW01")
        if engine._allowed_fix_gateways and "GW02" in engine._allowed_fix_gateways:
            _connect(engine, "GW02")
        # Register OCO pair manually and simulate one leg getting filled
        engine._handle_oco_order(self._oco_payload())
        order_ids = engine._oco_groups.get("OCO001", [])
        assert len(order_ids) == 2

    def test_oco_market_closed_rejected(self, monkeypatch, tmp_path) -> None:
        engine, pub_sock = _make_engine(monkeypatch, tmp_path, sessions_enabled=True)
        _connect(engine)
        engine._session_state = SessionState.CLOSED
        engine._handle_oco_order(self._oco_payload())
        _, msg = decode(pub_sock.sent[-1])
        assert msg["accepted"] is False


# ---------------------------------------------------------------------------
# _flush_snapshots
# ---------------------------------------------------------------------------


class TestFlushSnapshots:
    def test_engine_uses_configured_snapshot_interval(
        self, monkeypatch, tmp_path
    ) -> None:
        engine, _ = _make_engine(
            monkeypatch,
            tmp_path,
            snapshot_interval_sec=1.25,
        )
        assert engine.snapshot_interval_sec == 1.25

    def test_engine_uses_configured_tuning_knobs(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(
            monkeypatch,
            tmp_path,
            quote_history_maxlen=60,
            drop_copy_buffer_size=5000,
            recent_trades_maxlen=50,
            depth_snapshot_tolerance_ticks=250,
        )
        assert engine.quote_history_maxlen == 60
        assert engine.drop_copy_buffer_size == 5000
        assert engine.recent_trades_maxlen == 50
        assert engine.depth_snapshot_tolerance_ticks == 250

    def test_flush_publishes_dirty_symbols(self, monkeypatch, tmp_path) -> None:
        import time as _time

        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(_make_order_payload())
        # Force the throttle window elapsed so flush always publishes.
        engine._last_snapshot["AAPL"] = (
            _time.monotonic() - engine.snapshot_interval_sec - 0.001
        )
        engine._dirty_symbols.add("AAPL")
        count_before = len(pub_sock.sent)
        engine._flush_snapshots()
        assert len(pub_sock.sent) > count_before

    def test_flush_throttles_rapid_updates(self, monkeypatch, tmp_path) -> None:
        import time as _time

        engine, pub_sock = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        engine._handle_new_order(_make_order_payload())
        # Set last snapshot to "just now" so throttle blocks
        engine._last_snapshot["AAPL"] = _time.monotonic()
        engine._dirty_symbols.add("AAPL")
        count_before = len(pub_sock.sent)
        engine._flush_snapshots()
        assert len(pub_sock.sent) == count_before

    def test_flush_respects_configured_interval(self, monkeypatch, tmp_path) -> None:
        import time as _time

        engine, pub_sock = _make_engine(
            monkeypatch,
            tmp_path,
            snapshot_interval_sec=2.0,
        )
        _connect(engine)
        engine._handle_new_order(_make_order_payload())
        engine._dirty_symbols.add("AAPL")

        # Only 1 second elapsed since last publish with a 2-second interval -> no publish.
        engine._last_snapshot["AAPL"] = _time.monotonic() - 1.0
        count_before = len(pub_sock.sent)
        engine._flush_snapshots()
        assert len(pub_sock.sent) == count_before


# ---------------------------------------------------------------------------
# _gateway_status
# ---------------------------------------------------------------------------


class TestGatewayStatus:
    def test_no_allowlist_always_ok(self, monkeypatch, tmp_path) -> None:
        pull_sock = _FakeSock(sent=[])
        pub_sock = _FakeSock(sent=[])
        monkeypatch.setattr("edumatcher.engine.main.make_puller", lambda _: pull_sock)
        monkeypatch.setattr("edumatcher.engine.main.make_publisher", lambda _: pub_sock)
        monkeypatch.setattr(
            "edumatcher.engine.main.load_engine_config",
            lambda _: (_ for _ in ()).throw(FileNotFoundError()),
        )
        monkeypatch.setattr(
            "edumatcher.engine.main._compiled_engine_config", lambda: None
        )
        monkeypatch.setattr(
            "edumatcher.engine.main.ENGINE_CONFIG_FILE",
            tmp_path / "missing" / "engine_config.yaml",
        )
        monkeypatch.setattr("edumatcher.engine.main.time.sleep", lambda *_: None)
        # Engine without config file → no allowlist
        engine = Engine(config_path=None)
        ok, reason = engine._gateway_status("ANY_GW")
        assert ok is True
        assert reason == ""

    def test_not_in_allowlist(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path)
        ok, reason = engine._gateway_status("UNKNOWN")
        assert ok is False
        assert "not configured" in reason

    def test_in_allowlist_but_not_connected(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path)
        ok, reason = engine._gateway_status("GW01")
        assert ok is False
        assert "not connected" in reason

    def test_connected_and_in_allowlist(self, monkeypatch, tmp_path) -> None:
        engine, _ = _make_engine(monkeypatch, tmp_path)
        _connect(engine)
        ok, reason = engine._gateway_status("GW01")
        assert ok is True
        assert reason == ""
