from __future__ import annotations

import select
import signal
import socket
import threading
import time
from collections.abc import Generator
from types import SimpleNamespace

import pytest

import edumatcher.md_gateway.gateway as gateway_mod
from edumatcher.md_gateway.client_session import ClientSession
from edumatcher.md_gateway.config import MarketDataGatewayConfig
from edumatcher.md_gateway.gateway import MarketDataGateway, _extract_ts
from edumatcher.md_gateway.protocol import parse_line


class _FakeSubscriber:
    def __init__(self, events: list[tuple[str, dict[str, object]]]) -> None:
        self._events = list(events)

    def poll(self, timeout: int = 0) -> bool:
        _ = timeout
        return bool(self._events)

    def recv_multipart(self) -> tuple[str, dict[str, object]]:
        return self._events.pop(0)

    def close(self) -> None:
        return None

    @property
    def closed(self) -> bool:
        return False


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


@pytest.fixture()
def unit_gateway() -> Generator[MarketDataGateway, None, None]:
    cfg = MarketDataGatewayConfig(
        bind_address="127.0.0.1",
        port=_free_port(),
        engine_pub_addr=f"tcp://127.0.0.1:{_free_port()}",
        heartbeat_interval_sec=1,
        idle_timeout_sec=1,
        replay_window_sec=5,
        max_client_queue=2,
    )
    gw = MarketDataGateway(cfg, known_symbols={"AAPL", "MSFT"})
    try:
        yield gw
    finally:
        gw.close()


def _make_session() -> tuple[ClientSession, socket.socket]:
    left, right = socket.socketpair()
    left.setblocking(False)
    right.setblocking(False)
    return ClientSession(sock=left, addr=("local", 0)), right


def test_run_single_iteration_main_thread(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(threading, "current_thread", lambda: SimpleNamespace())
    monkeypatch.setattr(threading, "main_thread", lambda: SimpleNamespace())
    monkeypatch.setattr(signal, "signal", lambda *_: None)
    monkeypatch.setattr(time, "sleep", lambda *_: None)

    def _accept_once() -> None:
        unit_gateway.stop()

    monkeypatch.setattr(unit_gateway, "_accept_new_clients", _accept_once)
    monkeypatch.setattr(unit_gateway, "_read_client_data", lambda: None)
    monkeypatch.setattr(unit_gateway, "_poll_engine_events", lambda: None)
    monkeypatch.setattr(unit_gateway, "_send_heartbeats_if_due", lambda: None)
    monkeypatch.setattr(unit_gateway, "_flush_client_writes", lambda: None)
    monkeypatch.setattr(unit_gateway, "_drop_idle_clients", lambda: None)

    unit_gateway.run()
    assert unit_gateway._server is None


def test_accept_new_clients(unit_gateway: MarketDataGateway) -> None:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", _free_port()))
    server.listen(5)
    server.setblocking(False)
    unit_gateway._server = server

    client = socket.create_connection(server.getsockname())
    client.setblocking(False)
    select.select([server], [], [], 2.0)
    unit_gateway._accept_new_clients()
    assert len(unit_gateway._clients) >= 1

    client.close()
    server.close()


def test_accept_new_clients_respects_max_connections(
    unit_gateway: MarketDataGateway,
) -> None:
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", _free_port()))
    server.listen(5)
    server.setblocking(False)
    unit_gateway._server = server
    unit_gateway.config = MarketDataGatewayConfig(
        enabled=unit_gateway.config.enabled,
        name=unit_gateway.config.name,
        bind_address=unit_gateway.config.bind_address,
        port=unit_gateway.config.port,
        engine_pub_addr=unit_gateway.config.engine_pub_addr,
        index_pub_addr=unit_gateway.config.index_pub_addr,
        heartbeat_interval_sec=unit_gateway.config.heartbeat_interval_sec,
        idle_timeout_sec=unit_gateway.config.idle_timeout_sec,
        replay_window_sec=unit_gateway.config.replay_window_sec,
        max_connections=1,
        max_messages_per_second=unit_gateway.config.max_messages_per_second,
        max_symbols_per_client=unit_gateway.config.max_symbols_per_client,
        max_client_queue=unit_gateway.config.max_client_queue,
        depth_levels=unit_gateway.config.depth_levels,
    )

    held, held_peer = _make_session()
    unit_gateway._clients[held.sock.fileno()] = held

    client = socket.create_connection(server.getsockname())
    client.settimeout(1.0)
    select.select([server], [], [], 2.0)
    unit_gateway._accept_new_clients()

    # Server-side map should still only contain the existing held session.
    assert len(unit_gateway._clients) == 1

    client.close()
    held_peer.close()
    server.close()


def test_accept_new_clients_handles_oserror(unit_gateway: MarketDataGateway) -> None:
    class _Server:
        def accept(self) -> tuple[socket.socket, tuple[str, int]]:
            raise OSError("too many open files")

        def close(self) -> None:
            return None

    unit_gateway._server = _Server()
    unit_gateway._accept_new_clients()


def test_read_client_data_disconnect_on_eof(unit_gateway: MarketDataGateway) -> None:
    session, peer = _make_session()
    unit_gateway._clients[session.sock.fileno()] = session
    peer.close()
    unit_gateway._read_client_data()
    assert session.sock.fileno() not in unit_gateway._clients


def test_read_client_data_oversize_line(unit_gateway: MarketDataGateway) -> None:
    session, peer = _make_session()
    unit_gateway._clients[session.sock.fileno()] = session
    session.in_buffer.extend(b"X" * 4090)
    peer.sendall(b"Y" * 20)
    unit_gateway._read_client_data()
    assert session.closing is True
    frame = parse_line(session.out_queue[0].decode("utf-8"))
    assert frame.fields["CODE"] == "BAD_MESSAGE"
    peer.close()


def test_drain_lines_overlong_with_newline(unit_gateway: MarketDataGateway) -> None:
    session, peer = _make_session()
    session.in_buffer.extend((b"X" * 5000) + b"\n")
    unit_gateway._drain_lines(session)
    assert session.closing is True
    peer.close()


def test_flush_client_writes_and_disconnect(unit_gateway: MarketDataGateway) -> None:
    session, peer = _make_session()
    session.out_queue.append(b"PONG\n")
    session.closing = True
    unit_gateway._clients[session.sock.fileno()] = session
    unit_gateway._flush_client_writes()
    assert session.sock.fileno() not in unit_gateway._clients
    peer.close()


def test_flush_writes_extend_idle_timeout(
    unit_gateway: MarketDataGateway,
) -> None:
    """A successful write is activity, so it renews the idle lease.

    This test previously asserted the opposite — that flushing does *not*
    extend the timeout — which contradicted the protocol's own "no inbound and
    no outbound traffic" rule and meant every purely passive consumer was
    disconnected on a fixed cycle no matter how healthy its socket was.
    """
    session, peer = _make_session()
    session.authenticated = True
    session.last_activity = time.monotonic() - 10
    session.out_queue.append(b"HB|TS=2026-01-01T00:00:00Z\n")
    unit_gateway._clients[session.sock.fileno()] = session

    unit_gateway._flush_client_writes()
    unit_gateway._drop_idle_clients()

    assert session.sock.fileno() in unit_gateway._clients
    peer.close()


def test_poll_engine_events_all_topics(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "book.aapl",
                {
                    "bids": [{"price": 100.1, "qty": 10}],
                    "asks": [{"price": 100.2, "qty": 11}],
                    "timestamp": 1.0,
                },
            ),
            (
                "trade.executed",
                {
                    "id": "000001-000000001",
                    "run_seq": 1,
                    "symbol": "AAPL",
                    "price": 100.2,
                    "quantity": 3,
                    "aggressor_side": "BUY",
                    "timestamp": 2.0,
                },
            ),
            (
                "session.state",
                {"state": "CONTINUOUS", "prev_state": "PRE_OPEN", "timestamp": 3.0},
            ),
            ("circuit_breaker.halt.aapl", {"timestamp": 4.0}),
            ("circuit_breaker.resume.aapl", {"timestamp": 5.0}),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str]] = []

    def _capture(
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        _ = (payload_fields, ts_seconds)
        seen.append((msg_type, ch, sym))

    monkeypatch.setattr(unit_gateway, "_emit_stream_event", _capture)
    unit_gateway._poll_engine_events()

    assert ("MD", "TOP", "AAPL") in seen
    assert ("TRADE", "TRADE", "AAPL") in seen
    assert ("STATE", "STATE", "*") in seen
    assert ("STATE", "STATE", "AAPL") in seen


def test_poll_engine_events_halt_emits_state_and_cb(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "circuit_breaker.halt.aapl",
                {
                    "symbol": "AAPL",
                    "trigger_price": 148.20,
                    "reference_price": 150.10,
                    "resume_at_ns": 1_784_560_800_000_000_000,
                    "halt_source": "CB",
                    "level": "L2",
                    "timestamp": 4.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str, dict[str, str]]] = []

    def _capture(
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        _ = ts_seconds
        seen.append((msg_type, ch, sym, payload_fields))

    monkeypatch.setattr(unit_gateway, "_emit_stream_event", _capture)
    unit_gateway._poll_engine_events()

    by_type = {(msg_type, ch): fields for msg_type, ch, _sym, fields in seen}
    # STATE keeps its existing, unchanged shape.
    assert by_type[("STATE", "STATE")] == {"SESSION": "HALTED", "PREV": "CONTINUOUS"}
    # CB carries the full detail STATE never has.
    cb_fields = by_type[("CB", "CB")]
    assert cb_fields["STATUS"] == "HALTED"
    assert cb_fields["LEVEL"] == "L2"
    assert cb_fields["TRIGGERPX"] == "148.2"
    assert cb_fields["REFPX"] == "150.1"
    assert cb_fields["SRC"] == "CB"
    assert "RESUMEAT" in cb_fields
    assert all(sym == "AAPL" for _, _, sym, _ in seen)


def test_poll_engine_events_admin_halt_omits_price_fields_on_cb(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "circuit_breaker.halt.tsla",
                {
                    "symbol": "TSLA",
                    "trigger_price": None,
                    "reference_price": None,
                    "resume_at_ns": None,
                    "halt_source": "ADMIN",
                    "level": "ADMIN_ALL",
                    "timestamp": 4.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str, dict[str, str]]] = []
    monkeypatch.setattr(
        unit_gateway,
        "_emit_stream_event",
        lambda msg_type, ch, sym, fields, ts: seen.append((msg_type, ch, sym, fields)),
    )
    unit_gateway._poll_engine_events()

    cb_fields = next(fields for mt, ch, _s, fields in seen if (mt, ch) == ("CB", "CB"))
    assert cb_fields["STATUS"] == "HALTED"
    assert cb_fields["LEVEL"] == "ADMIN_ALL"
    assert cb_fields["SRC"] == "ADMIN"
    assert "TRIGGERPX" not in cb_fields
    assert "REFPX" not in cb_fields
    assert "RESUMEAT" not in cb_fields


def test_poll_engine_events_resume_emits_state_and_cb(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "circuit_breaker.resume.aapl",
                {"symbol": "AAPL", "halt_source": "CB", "timestamp": 5.0},
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str, dict[str, str]]] = []
    monkeypatch.setattr(
        unit_gateway,
        "_emit_stream_event",
        lambda msg_type, ch, sym, fields, ts: seen.append((msg_type, ch, sym, fields)),
    )
    unit_gateway._poll_engine_events()

    by_type = {(msg_type, ch): fields for msg_type, ch, _sym, fields in seen}
    assert by_type[("STATE", "STATE")] == {"SESSION": "CONTINUOUS", "PREV": "HALTED"}
    assert by_type[("CB", "CB")] == {"STATUS": "ACTIVE", "SRC": "CB"}


def test_poll_engine_events_auction_result(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "auction.result.aapl",
                {
                    "symbol": "AAPL",
                    "eq_price": 150.10,
                    "eq_qty": 48200,
                    "trades_count": 37,
                    "imbalance_side": "BUY",
                    "imbalance_qty": 1400,
                    "timestamp": 6.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str, dict[str, str]]] = []
    monkeypatch.setattr(
        unit_gateway,
        "_emit_stream_event",
        lambda msg_type, ch, sym, fields, ts: seen.append((msg_type, ch, sym, fields)),
    )
    unit_gateway._poll_engine_events()

    assert len(seen) == 1
    msg_type, ch, sym, fields = seen[0]
    assert (msg_type, ch, sym) == ("AUCTION", "AUCTION", "AAPL")
    assert fields["EQPX"] == "150.1"
    assert fields["EQQTY"] == "48200"
    assert fields["TRADES"] == "37"
    assert fields["IMBSIDE"] == "BUY"
    assert fields["IMBQTY"] == "1400"


def test_poll_engine_events_auction_no_cross(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "auction.result.tsla",
                {
                    "symbol": "TSLA",
                    "eq_price": None,
                    "eq_qty": 0,
                    "trades_count": 0,
                    "imbalance_side": "",
                    "imbalance_qty": 0,
                    "timestamp": 6.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[dict[str, str]] = []
    monkeypatch.setattr(
        unit_gateway,
        "_emit_stream_event",
        lambda msg_type, ch, sym, fields, ts: seen.append(fields),
    )
    unit_gateway._poll_engine_events()

    assert len(seen) == 1
    fields = seen[0]
    assert "EQPX" not in fields
    assert "IMBSIDE" not in fields
    assert fields["EQQTY"] == "0"
    assert fields["TRADES"] == "0"
    assert fields["IMBQTY"] == "0"


def test_poll_index_events_emits_idx(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    unit_gateway._sub_sock.close()
    unit_gateway._index_sub.close()
    unit_gateway._sub_sock = _FakeSubscriber([])
    unit_gateway._index_sub = _FakeSubscriber(
        [
            (
                "index.update",
                {
                    "index_id": "EDU100",
                    "level": 1042.5,
                    "aggregate_cap": 123456789,
                    "session_state": "CONTINUOUS",
                    "day_open": 1030.0,
                    "day_high": 1050.0,
                    "day_low": 1025.0,
                    "timestamp": 10.0,
                },
            )
        ]
    )
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, str, str, dict[str, str]]] = []

    def _capture(
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        _ = ts_seconds
        seen.append((msg_type, ch, sym, payload_fields))

    monkeypatch.setattr(unit_gateway, "_emit_stream_event", _capture)

    unit_gateway._poll_engine_events()

    assert seen
    msg_type, ch, sym, fields = seen[0]
    assert msg_type == "IDX"
    assert ch == "INDEX"
    assert sym == "EDU100"
    assert fields["LEVEL"] == "1042.5"


def test_poll_engine_events_nonfatal_handler_exception(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            ("book.aapl", {"bids": [{"price": 100.0, "qty": 1}], "asks": []}),
            (
                "trade.executed",
                {
                    "id": "000001-000000001",
                    "run_seq": 1,
                    "symbol": "AAPL",
                    "price": 100.2,
                    "quantity": 3,
                    "aggressor_side": "BUY",
                    "timestamp": 2.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)
    monkeypatch.setattr(
        unit_gateway._normaliser,
        "normalise_book",
        lambda _sym, _payload: (_ for _ in ()).throw(RuntimeError("boom")),
    )

    seen: list[tuple[str, str, str]] = []

    def _capture(
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        _ = (payload_fields, ts_seconds)
        seen.append((msg_type, ch, sym))

    monkeypatch.setattr(unit_gateway, "_emit_stream_event", _capture)

    unit_gateway._poll_engine_events()

    assert ("TRADE", "TRADE", "AAPL") in seen


def test_poll_engine_events_logs_decode_error(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = _FakeSubscriber(
        [
            (
                "book.aapl",
                {
                    "bids": [{"price": 100.0, "qty": 1}],
                    "asks": [{"price": 100.1, "qty": 1}],
                },
            )
        ]
    )

    monkeypatch.setattr(
        gateway_mod,
        "decode",
        lambda _payload: (_ for _ in ()).throw(ValueError("bad decode")),
    )

    caplog.set_level("WARNING")
    unit_gateway._poll_engine_events()

    assert "decode error on engine SUB event" in caplog.text


def test_poll_index_events_logs_decode_error(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    unit_gateway._sub_sock.close()
    unit_gateway._index_sub.close()
    unit_gateway._sub_sock = _FakeSubscriber([])
    unit_gateway._index_sub = _FakeSubscriber(
        [
            (
                "index.update",
                {"index_id": "EDU100", "level": 1000.0},
            )
        ]
    )

    monkeypatch.setattr(
        gateway_mod,
        "decode",
        lambda _payload: (_ for _ in ()).throw(ValueError("bad decode")),
    )

    caplog.set_level("WARNING")
    unit_gateway._poll_engine_events()

    assert "decode error on index SUB event" in caplog.text


def test_drop_idle_clients(unit_gateway: MarketDataGateway) -> None:
    auth_session, auth_peer = _make_session()
    auth_session.authenticated = True
    auth_session.last_activity = time.monotonic() - 10

    new_session, new_peer = _make_session()
    new_session.authenticated = False
    new_session.last_activity = time.monotonic() - 10
    new_session.connected_at = time.monotonic() - 10

    unit_gateway._clients[auth_session.sock.fileno()] = auth_session
    unit_gateway._clients[new_session.sock.fileno()] = new_session

    unit_gateway._drop_idle_clients()
    assert not unit_gateway._clients

    auth_peer.close()
    new_peer.close()


def test_emit_stream_event_skips_closing_clients(
    unit_gateway: MarketDataGateway,
) -> None:
    session, peer = _make_session()
    session.authenticated = True
    session.closing = True
    session.subscriptions.add(("TOP", "AAPL"))
    unit_gateway._clients[session.sock.fileno()] = session
    unit_gateway._subs.set_for_client(session.sock.fileno(), session.subscriptions)

    unit_gateway._emit_stream_event(
        "MD",
        "TOP",
        "AAPL",
        {"BID_PX": "100.0", "BID_QTY": "1", "ASK_PX": "100.1", "ASK_QTY": "1"},
        time.time(),
    )

    assert not session.out_queue
    peer.close()


def test_drop_idle_clients_uses_connect_age_for_pre_auth(
    unit_gateway: MarketDataGateway,
) -> None:
    sess, peer = _make_session()
    sess.authenticated = False
    sess.connected_at = time.monotonic() - 10
    sess.last_activity = time.monotonic()
    unit_gateway._clients[sess.sock.fileno()] = sess

    unit_gateway._drop_idle_clients()

    assert sess.sock.fileno() not in unit_gateway._clients
    peer.close()


def test_queue_raw_marks_slow_client_on_full_queue(
    unit_gateway: MarketDataGateway,
) -> None:
    sess, peer = _make_session()
    unit_gateway.config = MarketDataGatewayConfig(
        enabled=unit_gateway.config.enabled,
        name=unit_gateway.config.name,
        bind_address=unit_gateway.config.bind_address,
        port=unit_gateway.config.port,
        engine_pub_addr=unit_gateway.config.engine_pub_addr,
        index_pub_addr=unit_gateway.config.index_pub_addr,
        heartbeat_interval_sec=unit_gateway.config.heartbeat_interval_sec,
        idle_timeout_sec=unit_gateway.config.idle_timeout_sec,
        replay_window_sec=unit_gateway.config.replay_window_sec,
        max_connections=unit_gateway.config.max_connections,
        max_messages_per_second=unit_gateway.config.max_messages_per_second,
        max_symbols_per_client=unit_gateway.config.max_symbols_per_client,
        max_client_queue=1,
        depth_levels=unit_gateway.config.depth_levels,
    )

    sess.out_queue.append(b"A\n")
    unit_gateway._queue_raw(sess, b"B\n", is_market_data=True)

    assert sess.closing is True
    assert len(sess.out_queue) == 0
    peer.close()


def test_poll_engine_events_respects_budget(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            (
                "book.aapl",
                {
                    "bids": [{"price": 100.1, "qty": 10}],
                    "asks": [{"price": 100.2, "qty": 11}],
                    "timestamp": 1.0,
                },
            ),
            (
                "book.msft",
                {
                    "bids": [{"price": 100.1, "qty": 10}],
                    "asks": [{"price": 100.2, "qty": 11}],
                    "timestamp": 1.0,
                },
            ),
            (
                "book.goog",
                {
                    "bids": [{"price": 100.1, "qty": 10}],
                    "asks": [{"price": 100.2, "qty": 11}],
                    "timestamp": 1.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)
    monkeypatch.setattr(gateway_mod, "_MAX_ENGINE_EVENTS_PER_LOOP", 2)

    seen: list[str] = []

    def _capture(
        msg_type: str,
        ch: str,
        sym: str,
        payload_fields: dict[str, str],
        ts_seconds: float,
    ) -> None:
        _ = (msg_type, ch, payload_fields, ts_seconds)
        seen.append(sym)

    monkeypatch.setattr(unit_gateway, "_emit_stream_event", _capture)

    unit_gateway._poll_engine_events()

    assert len(seen) == 4
    assert set(seen) == {"AAPL", "MSFT"}


def test_extract_ts_fallback_and_parse_csv(unit_gateway: MarketDataGateway) -> None:
    assert _extract_ts({"timestamp": "2.5"}) == 2.5
    assert isinstance(_extract_ts({"timestamp": object()}), float)
    assert isinstance(_extract_ts({}), float)
    assert unit_gateway._parse_csv_upper(" aapl, msft ") == ["AAPL", "MSFT"]


def test_session_transition_is_repeated_for_every_known_symbol(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A SUB naming a symbol must still learn the exchange opened or closed.

    Subscriptions match on ``sub_sym == "*" or sub_sym == sym``, and an
    exchange transition is published against ``SYM=*``. A client watching one
    instrument therefore saw its halts and resumes but never the session
    around them.
    """
    fake = _FakeSubscriber(
        [
            ("session.state", {"state": "CONTINUOUS", "timestamp": 1.0}),
            (
                "session.state",
                {
                    "state": "CLOSING_AUCTION",
                    "prev_state": "CONTINUOUS",
                    "timestamp": 2.0,
                },
            ),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)

    seen: list[tuple[str, dict[str, str]]] = []
    monkeypatch.setattr(
        unit_gateway,
        "_emit_stream_event",
        lambda msg_type, ch, sym, fields, ts: seen.append((sym, fields)),
    )
    unit_gateway._poll_engine_events()

    per_symbol = {sym: fields for sym, fields in seen if sym != "*"}
    assert per_symbol["AAPL"] == {"SESSION": "CLOSING_AUCTION", "PREV": "CONTINUOUS"}
    assert per_symbol["MSFT"] == {"SESSION": "CLOSING_AUCTION", "PREV": "CONTINUOUS"}
    # The wildcard line still goes out for clients that subscribe with SYM=*.
    assert ("*", {"SESSION": "CLOSING_AUCTION", "PREV": "CONTINUOUS"}) in seen


def test_session_transition_leaves_a_halted_symbol_halted(
    unit_gateway: MarketDataGateway,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeSubscriber(
        [
            ("session.state", {"state": "CONTINUOUS", "timestamp": 1.0}),
            (
                "circuit_breaker.halt.aapl",
                {"symbol": "AAPL", "level": "L2", "timestamp": 2.0},
            ),
            ("session.state", {"state": "CLOSING_AUCTION", "timestamp": 3.0}),
        ]
    )
    unit_gateway._sub_sock.close()
    unit_gateway._sub_sock = fake
    monkeypatch.setattr(gateway_mod, "decode", lambda payload: payload)
    monkeypatch.setattr(
        unit_gateway, "_emit_stream_event", lambda *args, **kwargs: None
    )
    unit_gateway._poll_engine_events()

    # The halt outlives the phase it began in; only an explicit resume ends it.
    snapshot = unit_gateway._normaliser.state_snapshot_fields("AAPL")
    assert snapshot == {"SESSION": "HALTED"}
