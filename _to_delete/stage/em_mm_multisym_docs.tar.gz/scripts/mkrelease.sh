#!/bin/bash
# Release Script
# Description: Automates the release process for EduMatcher.
# Assumes:
# 1. mkbld.sh has been run and all tests are passing with >80% coverage.
# 2. The version number in pyproject.toml has been updated to the new release version.
# 3. The changelog has been updated with the new version and release notes.
#
# Usage: ./scripts/mkrelease.sh [major|minor|patch] [--dry-run] [--help]
#
# Example: ./scripts/mkrelease.sh minor
# Example: ./scripts/mkrelease.sh minor --dry-run
# Example: ./scripts/mkrelease.sh --help

set -euo pipefail  # Exit on any error or uninitialized variable

# Color codes

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# =====================================
# CONFIGURATION
# =====================================

# Assumes GITHUB_USER is available in the environment for gh CLI authentication
# Check that GITHUB_USER is set
if [[ -z "${GITHUB_USER:-}" ]]; then
    echo -e "${RED}Error: GITHUB_USER environment variable is not set. Please set it to your GitHub username for authentication with the gh CLI.${NC}" >&2
    exit 1
fi

declare SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
declare PROGRAMNAME="edumatcher"
declare PROGRAMNAME_PRETTY="EduMatcher"
declare COVERAGE="80"

# =====================================
# Functions to print colored output
# =====================================
print_step() {
    echo -e "${BLUE}==>${NC} ${1}"
}

print_step_colored() {
    echo -e "${BLUE}==> ${1}${NC}"
}

print_sub_step() {
    echo -e "${BLUE}  ->${1}${NC}"
}

print_success() {
    echo -e "${GREEN}✓${NC} ${1}"
}

print_success_colored() {
    echo -e "${GREEN}✓ ${1}${NC}"
}

print_error() {
    echo -e "${RED}✗${NC} ${1}" >&2
}

print_error_colored() {
    echo -e "${RED}❌ ${1}${NC}" >&2
}
# Alternate non-colored glyph for error: ✗

print_warning() {
    echo -e "${YELLOW}⚠${NC} ${1}"
}

print_warning_colored() {
    echo -e "${YELLOW}⚠ ${1}${NC}"
}

# =====================================
# Help function
# =====================================
show_help() {
    cat << EOF
🚀 ${PROGRAMNAME_PRETTY} Release Script

DESCRIPTION:
    Automated release script for ${PROGRAMNAME} with comprehensive quality gates.
    Performs validation, testing, versioning, and git operations for releases.

USAGE:
    $0 [major|minor|patch] [options]

ARGUMENTS:
    release-type    Type of release (default: minor)
                    • major   - Breaking changes, incompatible API changes
                    • minor   - New features, backwards compatible  
                    • patch   - Bug fixes, backwards compatible

OPTIONS:
    --dry-run       Preview all commands without executing them
                    Shows exactly what would be done without making changes
                    
    --help, -h      Show this help message and exit

EXAMPLES:
    # Show help
    $0 --help
    
    # Preview a minor release (recommended first step)
    $0 minor --dry-run
    
    # Execute a minor release
    $0 minor
    
    # Create a patch release with preview
    $0 patch --dry-run
    $0 patch

    # Create a major release
    $0 major --dry-run
    $0 major

QUALITY GATES:
    The script enforces comprehensive quality controls:
    ✓ Repository state validation (clean working directory)
    ✓ Test suite execution (>90% coverage requirement)
    ✓ Static analysis and code formatting checks
    ✓ Integration testing with all example networks
    ✓ Package building and validation via twine
    ✓ Semver compliance and duplicate version prevention
    ✓ Version consistency across all project files

WORKFLOW:
    1. Pre-release validation (repository state, version format, changelog presence)
    2. Comprehensive testing (unit tests, integration, static analysis)
    3. Release preparation (version updates, release assets)
    4. Release execution (git commit, merge, tag, push)
    5. Post-release cleanup (sync branches, clean artifacts)

REQUIREMENTS:
    • Must be run from project root directory
    • Must be on 'develop' branch with clean working directory
    • Requires: git, python, poetry, gh
    • Requires an existing CHANGELOG.md entry for the planned version
    • Requires Poetry dev dependencies installed (run: poetry install)

SAFETY:
    • Use --dry-run first to preview all operations
    • Script validates all conditions before making changes
    • Fails fast on any error to prevent partial releases
    • All git operations are atomic and reversible

For more information, see docs/developer_guide.md
EOF
}

# Get VERSION from pyproject.toml
VERSION="$(poetry version --short)"
print_step_colored "Detected version: ${VERSION}"

# Parse arguments
RELEASE_TYPE="minor"
DRY_RUN=false

for arg in "$@"; do
    case $arg in
        --help|-h)
            show_help
            exit 0
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        -*)
            print_error_colored "Unknown option: $arg"
            echo "Usage: $0 [major|minor|patch] [--dry-run] [--help]"
            echo "Run '$0 --help' for detailed information"
            exit 1
            ;;
        *)
            RELEASE_TYPE="$arg"
            shift
            ;;
    esac
done

VERSION="${VERSION/-rc/rc}"

# Function to execute command or print it in dry-run mode
run_command() {
    local cmd="$1"
    local description="${2:-}"
    
     if [ "$DRY_RUN" = "true" ]; then
        echo -e "${YELLOW}[DRY-RUN]${NC} Would execute: ${cmd}"
    else
        print_sub_step "$description"
        echo "Executing: $cmd"
        if eval "$cmd"; then
            print_success "$description completed!"
        else
            print_error_colored "$description failed! Aborting."
            exit 1
        fi
    fi
}

# Conditional execution for commands that need special dry-run handling
check_condition() {
    local condition="$1"
    local error_msg="$2"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        echo "  [DRY-RUN] Would check: $condition"
        echo "  [DRY-RUN] Would fail with: $error_msg (if condition false)"
        return 0  # Don't actually fail in dry-run
    else
        if ! eval "$condition"; then
            print_error_colored "$error_msg"
            exit 1
        fi
    fi
}

if [[ "$DRY_RUN" == "true" ]]; then
    print_warning_colored "🔍 DRY RUN MODE - No commands will be executed"
    echo "🚀 Would start ${PROGRAMNAME_PRETTY} v$VERSION release process..."
    echo "📋 Release type: $RELEASE_TYPE"
else
    echo "🚀 Starting ${PROGRAMNAME_PRETTY} v$VERSION release process..."
    echo "📋 Release type: $RELEASE_TYPE"
fi

# =====================================
# PHASE 1: PRE-RELEASE VALIDATION
# =====================================

print_step_colored ""
print_step_colored "🔍 PHASE 1: PRE-RELEASE VALIDATION"
print_step_colored ""

# 1.1: Check if we're in the root directory (pyproject.toml must exist)
run_command "test -f pyproject.toml" "Build script must be run from project root."

# 1.2: Ensure Poetry is available and a Poetry environment exists
if [ "$DRY_RUN" = false ]; then
    if ! command -v poetry >/dev/null 2>&1; then
        print_error_colored "Poetry is required but was not found in PATH."
        exit 2
    fi

    if poetry env info --path >/dev/null 2>&1; then
        echo "Using Poetry environment: $(poetry env info --path)"
    else
        print_error_colored "No Poetry environment found. Run 'poetry install' first."
        exit 2
    fi

    for required_command in pytest mypy black twine; do
        if ! poetry run "$required_command" --version >/dev/null 2>&1; then
            print_error_colored "Required Poetry command '$required_command' is unavailable. Run 'poetry install'."
            exit 2
        fi
    done
else
    echo "  [DRY-RUN] Would verify Poetry is available, a Poetry environment exists, and dev tools are installed"
fi

# 1.3: Verify we're on develop and it's clean
check_condition '[[ $(git symbolic-ref --short HEAD) == "develop" ]]' "Must be on develop branch"
check_condition '[[ -z $(git status --porcelain) ]]' "Working directory must be clean"

if [[ "$DRY_RUN" == "false" && -n $(git status --porcelain) ]]; then
    git status --short
    exit 1
fi

# 1.4: Verify that the local develop branch is up-to-date with the remote
check_condition '[[ $(git rev-parse HEAD) == $(git rev-parse @{u}) ]]' "Local develop branch is not up-to-date with remote"

# 1.5: Validate version format (Poetry / PEP 440 compatible)
check_condition '[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(rc[1-9][0-9]?)?$ ]]' "Version must follow semver format (x.y.z or x.y.zrcNN)"

# 1.6: Check if version already exists
check_condition '! git tag | grep -q "v${VERSION}\$"' "Tag v$VERSION already exists"

# 1.7: Check if CHANGELOG entry exists for the planned version
print_sub_step "Verifying CHANGELOG.md contains an entry for v$VERSION..."
if [[ ! -f CHANGELOG.md ]]; then
    print_error_colored "CHANGELOG.md not found. Run ./scripts/mkchlogentry.sh $VERSION $RELEASE_TYPE first."
    exit 1
fi
if ! grep -Eq "^## \[v${VERSION}\] - [0-9]{4}-[0-9]{2}-[0-9]{2}$" CHANGELOG.md; then
    print_error_colored "No CHANGELOG.md entry found for v$VERSION"
    echo "Run: ./scripts/mkchlogentry.sh $VERSION $RELEASE_TYPE to manually update the changelog, or"
    echo "    use the /changelog-entry skill in copilot to automatically generate the entries"
    exit 1
fi
print_success "Found CHANGELOG entry for v$VERSION"

# 1.8: Confirm the Python artifacts for this version were built (validated already by mkbld.sh)
check_condition '[[ -n $(ls dist/edumatcher-${VERSION}*.whl 2>/dev/null) && -n $(ls dist/edumatcher-${VERSION}*.tar.gz 2>/dev/null) ]]' "Built artifacts for v$VERSION not found in dist/ -- run ./scripts/mkbld.sh first"


# =====================================
# PHASE 2: RELEASE EXECUTION
# =====================================
print_step_colored ""
print_step_colored "🎯 PHASE 2: RELEASE EXECUTION"
print_step_colored ""

# 2.1: Commit version updates
# run_command "git add pyproject.toml CHANGELOG.md README.md docs/user-guide/template*.tex" "Staging release files..."
# run_command "git commit -m \"chore(release): prepare $VERSION

# - Update version to $VERSION
# - Update changelog with release notes
# - All tests passing with >80% coverage
# - Package build validation complete\"" "Committing release preparation..."

# 2.2: Merge to main branch and create release commit
run_command "git checkout main" "Switching to main branch..."
run_command "git pull origin main" "Pulling latest main..."

# Squash merge develop into main
run_command "git merge --squash develop" "Squashing develop changes..."
run_command "git commit -m \"release: $VERSION

Summary of changes:
- All features and fixes from develop branch
- Comprehensive test coverage (>${COVERAGE}%)
- Full integration testing completed
- Package build validation successful
- Static analysis passed

See CHANGELOG.md for detailed changes.\"" "Creating release commit on main..."


# 2.3: Create annotated release tag
if [[ "$DRY_RUN" == "true" ]]; then
    echo "  [DRY-RUN] Would create annotated tag $VERSION..."
    echo "  [DRY-RUN] Tag message would include release type, date, and QA checklist"
else
    echo "  ✓ Creating release tag..."
    CHANGELOG_DATE=$(date +%Y-%m-%d)
    git tag -a "v$VERSION" -m "Release tag v$VERSION

Release Type: $RELEASE_TYPE
Release Date: $CHANGELOG_DATE

Quality Assurance:
✓ Full test suite passed (>80% coverage)
✓ All example networks validated  
✓ CLI and REPL functionality verified
✓ Package build and validation complete
✓ Static analysis passed
✓ Integration tests passed

Changelog: See CHANGELOG.md for detailed changes"
fi

# 2.4: Push main branch and tags
MAIN_RELEASE_SHA="$(git rev-parse main)"
run_command "git push origin main" "Pushing main branch..."
run_command "git push origin \"v$VERSION\"" "Pushing release tag..."

# =====================================
# PHASE 3: POST-RELEASE CLEANUP
# =====================================

print_step_colored ""
print_step_colored "🧹 PHASE 3: POST-RELEASE CLEANUP AND MERGE BACK TO DEVELOP"
print_step_colored ""

# 3.1: Return to develop and merge back release changes
run_command "git checkout develop" "Switching back to develop..."

# 3.2: Merge main into develop to reconcile squash merge
if [[ "$DRY_RUN" == "true" ]]; then
    echo "  [DRY-RUN] Would merge main into develop with --no-ff"
    echo "  [DRY-RUN] This reconciles the squashed commits on main"
else
    echo "  ✓ Merging main into develop to sync branches..."
    
    # Use --no-ff to create explicit merge commit
    git merge --no-ff -m "chore: sync develop with main after release v$VERSION" main

    if [[ $? -ne 0 ]]; then
        print_error_colored "Failed to merge main into develop"
        echo ""
        echo "This indicates merge conflicts. To resolve:"
        echo "  1. git status  # See conflicting files"
        echo "  2. Edit files to resolve conflicts"
        echo "  3. git add <resolved-files>"
        echo "  4. git commit -m \"chore: resolve merge conflicts after release v$VERSION\""
        echo "  5. git push origin develop"
        echo ""
        exit 1
    fi
    
    print_success "develop synced with main"
fi

# =====================================
# PHASE 4: PUSH DEVELOP AND WAIT FOR CI
# =====================================

print_step_colored ""
print_step_colored " ⌛ PHASE 4: PUSH DEVELOP AND WAIT FOR CI"
print_step_colored ""

# 4.1: Push synced develop branch
# ci.yml only runs on pushes to main (plus pull requests), so this push does
# not trigger a workflow -- develop is kept in sync, nothing to wait for here.
run_command "git push origin develop" "Pushing updated develop..."

echo -e "${BLUE}🕐${NC} Waiting for CI on main (v$VERSION, ${MAIN_RELEASE_SHA:0:7})..."
echo ""

if [[ "$DRY_RUN" == "false" ]]; then
    # Match the run triggered by the 2.4 push to main by commit SHA rather than
    # trusting "the latest run" -- ci.yml can also be running a PR check at the
    # same time, and a bare `gh run watch` has no way to tell them apart.
    RUN_ID=""
    for _ in $(seq 1 30); do
        RUN_ID=$(gh run list --workflow ci.yml --branch main --limit 20 \
                    --json databaseId,headSha \
                    --jq "[.[] | select(.headSha == \"$MAIN_RELEASE_SHA\")] | .[0].databaseId" \
                    2>/dev/null || true)
        [[ -n "$RUN_ID" && "$RUN_ID" != "null" ]] && break
        sleep 5
    done

    if [[ -z "$RUN_ID" || "$RUN_ID" == "null" ]]; then
        print_error "No ci.yml run appeared for v$VERSION (${MAIN_RELEASE_SHA:0:7}) on main."
        echo "Check: gh run list --workflow ci.yml --branch main"
        exit 1
    fi

    print_sub_step "Watching run $RUN_ID"
    if gh run watch "$RUN_ID" --exit-status; then
        print_success "CI workflows completed successfully!"
    else
        print_error "CI workflows failed!"
        echo "View logs: gh run view $RUN_ID --log-failed"
        exit 1
    fi
else
    echo "  [DRY-RUN] Would locate and watch the ci.yml run for main @ ${MAIN_RELEASE_SHA:0:7}"
fi

# =====================================
# PHASE 5: RELEASE SUMMARY
# =====================================

echo ""
if [[ "$DRY_RUN" == "true" ]]; then
    print_step_colored ""
    print_step_colored "🔍 PHASE 5: DRY RUN RELEASE SUMMARY"
    print_step_colored ""
    echo "📋 Commands that would be executed:"
    echo "   → All validation checks (repository state, version format, etc.)"
    echo "   → Full test suite with coverage requirements"
    echo "   → Static analysis and code formatting checks"
    echo "   → Integration testing with example networks"
    echo "   → Package building and validation"
    echo "   → Version number updates in multiple files"
    echo "   → Changelog generation and user editing"
    echo "   → Git operations: commit, merge, tag, push"
    echo "   → Post-release cleanup"
    echo ""
    echo "🚀 To execute for real:"
    echo "   $0 $VERSION $RELEASE_TYPE"
else
    print_step_colored ""
    print_step_colored "✅ PHASE 5: RELEASE SUMMARY"
    print_step_colored ""
    print_success_colored "🎉 ${PROGRAMNAME_PRETTY} v${VERSION} released successfully!"
    echo ""
    echo "📊 Release Summary:"
    echo "   Version:     $VERSION"
    echo "   Type:        $RELEASE_TYPE"
    echo "   Date:        $(date +%Y-%m-%d)"
    echo "   Branch:      main"
    echo "   Tag:         v$VERSION"
    echo ""
    echo "📦 Artifacts:"
    echo "   - $(ls dist)"
    echo ""
    echo "📊 Branch Status:"
    echo "   GitHub will show develop as 'ahead' of main - this is expected!"
    echo "   • develop preserves detailed commit history"
    echo "   • main uses squash merges (one commit per release)"
    echo "   • Code content is identical between branches"
    echo ""
    echo "   Verify with: git diff main develop"
    echo ""
    echo "🚀 Next Steps:"
    echo "   1. Verify release tag on GitHub"
    echo "   2. Run 'scripts/mkghrelease.sh' to create GitHub release (which will also upload packages to PyPI)"
    echo "   3. Announce the release!"
    echo ""
    echo "📋 Quality Metrics Achieved:"
    echo "   ✓ Test Coverage: >${COVERAGE}%"
    echo "   ✓ All Example Projects: Validated"
    echo "   ✓ Package Build: Successful" 
    echo "   ✓ Static Analysis: Passed"
    echo "   ✓ Integration & Unit Tests: Passed"
    echo ""    
    print_success_colored "Thank you for contributing to ${PROGRAMNAME_PRETTY}! 🎉"
fi

echo ""
exit 0
# End of script