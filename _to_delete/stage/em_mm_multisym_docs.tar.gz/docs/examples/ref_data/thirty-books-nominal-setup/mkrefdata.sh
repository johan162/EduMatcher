#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"

SEED=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --seed)
      if [[ $# -lt 2 ]]; then
        echo "Error: --seed requires an integer argument" >&2
        exit 1
      fi
      SEED="$2"
      shift 2
      ;;
    --seed=*)
      SEED="${1#*=}"
      shift
      ;;
    -h|--help)
      echo "Usage: $0 [--seed <integer>]"
      exit 0
      ;;
    *)
      echo "Error: unknown argument: $1" >&2
      echo "Usage: $0 [--seed <integer>]" >&2
      exit 1
      ;;
  esac
done

if [[ -n "$SEED" && ! "$SEED" =~ ^-?[0-9]+$ ]]; then
  echo "Error: --seed must be an integer" >&2
  exit 1
fi

SEED_ARGS=()
if [[ -n "$SEED" ]]; then
  SEED_ARGS=(--seed "$SEED")
fi

# Guarantee a deterministic seed so both generation passes produce identical
# MM quote prices, keeping the combo leg prices consistent with the book seeds.
if [[ -z "$SEED" ]]; then
  SEED=$(( RANDOM * 32768 + RANDOM ))
  echo "[INFO] Auto-generated seed $SEED — re-run with --seed $SEED for identical output." >&2
fi
SEED_ARGS=(--seed "$SEED")


if command -v pm-config-gen >/dev/null 2>&1; then
  CONFIG_GEN=(pm-config-gen)
elif command -v poetry >/dev/null 2>&1; then
  CONFIG_GEN=(poetry run pm-config-gen)
else
  echo "Error: neither pm-config-gen nor poetry is available in PATH" >&2
  exit 1
fi

SYMBOLS=(AAPL MSFT TSLA AMZN GOOGL META NVDA NFLX INTC ORCL IBM ADBE CRM QCOM AMD AVGO TXN NOW SHOP UBER PYPL SQ BABA SONY SAP ASML CSCO MU BKNG TSM)
GATEWAYS=(
  "TRADER01:TRADER:CANCEL_ALL:Student desk 1"
  "TRADER02:TRADER:CANCEL_ALL:Student desk 2"
  "OPS01:ADMIN:LEAVE_ALL:Instructor console"
)
MM_GATEWAYS=("MM01:MARKET_MAKER:CANCEL_QUOTES_ONLY:Market maker")
GATEWAYS+=("${MM_GATEWAYS[@]}")

OUTSTANDING_ARGS=(
  --outstanding-shares AAPL:15400000000
  --outstanding-shares MSFT:7430000000
  --outstanding-shares TSLA:3200000000
  --outstanding-shares AMZN:10600000000
  --outstanding-shares GOOGL:12200000000
  --outstanding-shares META:2560000000
  --outstanding-shares NVDA:24600000000
  --outstanding-shares NFLX:430000000
  --outstanding-shares INTC:4300000000
  --outstanding-shares ORCL:2800000000
  --outstanding-shares IBM:910000000
  --outstanding-shares ADBE:460000000
  --outstanding-shares CRM:970000000
  --outstanding-shares QCOM:1690000000
  --outstanding-shares AMD:1620000000
  --outstanding-shares AVGO:4700000000
  --outstanding-shares TXN:910000000
  --outstanding-shares NOW:205000000
  --outstanding-shares SHOP:1320000000
  --outstanding-shares UBER:2130000000
  --outstanding-shares PYPL:1080000000
  --outstanding-shares SQ:600000000
  --outstanding-shares BABA:2200000000
  --outstanding-shares SONY:1240000000
  --outstanding-shares SAP:1150000000
  --outstanding-shares ASML:415000000
  --outstanding-shares CSCO:4060000000
  --outstanding-shares MU:1100000000
  --outstanding-shares BKNG:44000000
  --outstanding-shares TSM:5180000000
)

COMMON_ARGS=(
  --symbols "${SYMBOLS[@]}"
  --gateways "${GATEWAYS[@]}"
  --seed-mm-mid-range 20:300
  --seed-last-prices-from-mm
  --output engine_config.yaml
  --force
  --comment-default-config-fields
  "${SEED_ARGS[@]}"
  "${OUTSTANDING_ARGS[@]}"
  --api-gateway-instance desk:TRADER01,TRADER02,MM01,OPS01:8080
  --api-gateway-instance dashboards::8081
  --api-gateway-readonly-key
)
"${CONFIG_GEN[@]}" "${COMMON_ARGS[@]}" \
  --sessions-enabled \
  --post-trade-gateway \
  --post-trade-bind-address 0.0.0.0 \
  --post-trade-port 5580 \
  --post-trade-replay-retention-sec 3600 \
  --post-trade-heartbeat-interval-sec 1 \
  --post-trade-idle-timeout-sec 10 \
  --post-trade-max-client-queue 5000 \
  --post-trade-allowed-roles CLEARING DROP_COPY AUDIT \
  --market-data-gateway \
  --market-data-enabled \
  --market-data-name md-gwy01 \
  --market-data-bind-address 0.0.0.0 \
  --market-data-port 5570 \
  --market-data-heartbeat-interval-sec 1 \
  --market-data-idle-timeout-sec 5 \
  --market-data-replay-window-sec 30 \
  --market-data-max-symbols-per-client 200 \
  --market-data-max-client-queue 10000

echo "Generated $(pwd)/engine_config.yaml"
